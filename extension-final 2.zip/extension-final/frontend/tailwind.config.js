/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // Indian Tricolor Theme
        saffron: {
          50: '#FFF7ED',
          100: '#FFEDD5',
          200: '#FED7AA',
          300: '#FDBA74',
          400: '#FB923C',
          500: '#FF9933', // Primary Saffron
          600: '#EA580C',
          700: '#C2410C',
        },
        igreen: {
          50: '#F0FDF4',
          100: '#DCFCE7',
          200: '#BBF7D0',
          300: '#86EFAC',
          400: '#4ADE80',
          500: '#138808', // Indian Green
          600: '#16A34A',
          700: '#15803D',
        },
        navy: {
          50: '#EEF2FF',
          100: '#E0E7FF',
          200: '#C7D2FE',
          300: '#A5B4FC',
          400: '#818CF8',
          500: '#000080', // Navy Blue (Ashoka Chakra)
          600: '#4F46E5',
          700: '#4338CA',
        },
        cream: {
          50: '#FFFBF5',
          100: '#FFF8ED',
          200: '#FFF1DB',
        },
        // Semantic colors
        hot: { DEFAULT: '#EF4444', bg: '#FEF2F2' },
        warm: { DEFAULT: '#F59E0B', bg: '#FFFBEB' },
        cool: { DEFAULT: '#3B82F6', bg: '#EFF6FF' },
      },
      fontFamily: {
        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
        mono: ['JetBrains Mono', 'SF Mono', 'Consolas', 'monospace'],
      },
      boxShadow: {
        'glow-saffron': '0 4px 20px rgba(255, 153, 51, 0.25)',
        'glow-green': '0 4px 20px rgba(19, 136, 8, 0.25)',
      },
    },
  },
  plugins: [],
};
