// ── User & Auth ──────────────────────────────────────
export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'seller';
  sellerId: string;
  active: boolean;
}

export interface AuthState {
  token: string | null;
  user: User | null;
}

// ── Seller ───────────────────────────────────────────
export interface KeywordCategories {
  category: string[];  // renamed from 'product' → matches IndiaMART category field
  city: string[];
  value: string[];
}

export interface Seller {
  _id?: string;
  sellerId: string;
  userId?: string;
  extensionId?: string;
  name: string;
  active: boolean;
  keywords: string[];
  keywordCategories: KeywordCategories;
  createdAt?: string;
  updatedAt?: string;
}

// ── Lead ─────────────────────────────────────────────
export interface LeadLocation {
  city: string;
  state: string;
  full: string;
}

export interface OrderValue {
  min: number;
  max: number;
  display: string;
}

export interface LeadStatus {
  clicked: boolean;
  clickedAt: string | null;
  keywordMatched: string;
  clickAttempted: 'Y' | 'N' | '';
}

export interface Lead {
  _id: string;
  leadId: string;
  sellerId: string;
  title: string;
  timestamp: string;
  location: LeadLocation;
  category: string;
  detectedCategory: string;
  quantity: string;
  orderValue: OrderValue | null;
  requirementType: string;
  buyer: {
    memberSince: string;
    businessType: string;
    engagement: { requirements: number; calls: number; replies: number };
  };
  score: number;
  status: LeadStatus;
  capturedAt: string;
  capturePhase: string;
}

// ── Stats ────────────────────────────────────────────
export interface Stats {
  total: number;
  clicked: number;
  today: number;
  hot: number;
  warm: number;
  cool: number;
}

// ── Heartbeat ────────────────────────────────────────
export interface Heartbeat {
  sellerId: string;
  extensionId: string;
  phase: string;
  lastPing: string;
  isAlive: boolean;
  secondsSinceLastPing: number | null;
  pingCount: number;
  tabUrl: string;
  chromeFlags: string;
}

// ── API Responses ────────────────────────────────────
export interface PaginatedLeads {
  success: boolean;
  data: Lead[];
  total: number;
  page: number;
  limit: number;
  pages: number;
}
