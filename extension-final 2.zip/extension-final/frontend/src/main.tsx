import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import { AuthProvider } from './context/AuthContext';
import { SellerProvider } from './context/SellerContext';
import { ToastProvider } from './components/ui/Toast';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AuthProvider>
      <SellerProvider>
        <ToastProvider>
          <App />
        </ToastProvider>
      </SellerProvider>
    </AuthProvider>
  </StrictMode>
);
