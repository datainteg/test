import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import type { Seller } from '@/types';
import { getSellers } from '@/services/api';
import { useAuth } from './AuthContext';

interface SellerCtx {
  sellers: Seller[];
  currentSellerId: string | null;
  setCurrentSellerId: (id: string | null) => void;
  currentSeller: Seller | undefined;
  refresh: () => Promise<void>;
}

const SellerContext = createContext<SellerCtx>({
  sellers: [], currentSellerId: null, setCurrentSellerId: () => {},
  currentSeller: undefined, refresh: async () => {},
});

export function SellerProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [sellers, setSellers] = useState<Seller[]>([]);
  const [currentSellerId, setCurrentSellerId] = useState<string | null>(null);

  const userId = user?.id;
  const userRole = user?.role;

  const refresh = useCallback(async () => {
    if (!userId) return;
    try {
      const d = await getSellers();
      const fetched: Seller[] = d.sellers || [];
      setSellers(fetched);

      // Auto-select: seller-role users with exactly one seller should have it pre-selected
      // Don't override if user already made a selection
      setCurrentSellerId(prev => {
        if (prev) return prev; // keep existing selection
        if (userRole === 'seller' && fetched.length === 1) return fetched[0].sellerId;
        return null;
      });
    } catch {}
  }, [userId, userRole]);

  useEffect(() => { refresh(); }, [refresh]);

  const currentSeller = sellers.find(s => s.sellerId === currentSellerId);

  return (
    <SellerContext.Provider value={{ sellers, currentSellerId, setCurrentSellerId, currentSeller, refresh }}>
      {children}
    </SellerContext.Provider>
  );
}

export const useSellers = () => useContext(SellerContext);
