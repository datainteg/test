import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { User } from '@/types';
import { login as apiLogin, getMe } from '@/services/api';

interface AuthCtx {
  token: string | null;
  user: User | null;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<string | null>;
  logout: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthCtx>({
  token: null, user: null, isAdmin: false,
  login: async () => null, logout: () => {}, loading: true,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(() => {
    try {
      const stored = localStorage.getItem('lm_auth');
      if (stored) {
        const d = JSON.parse(stored);
        return d.token || null;
      }
    } catch {}
    return null;
  });
  
  const [user, setUser] = useState<User | null>(() => {
    try {
      const stored = localStorage.getItem('lm_auth');
      if (stored) {
        const d = JSON.parse(stored);
        return d.user || null;
      }
    } catch {}
    return null;
  });
  
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const stored = localStorage.getItem('lm_auth');
      if (stored) {
        try {
          const d = JSON.parse(stored);
          if (d.token) {
            try {
              // Validate token with server
              const res = await getMe();

              // 1. Success: Server returned the user
              if (res && res.user) {
                setToken(d.token);
                setUser(res.user);
                localStorage.setItem('lm_auth', JSON.stringify({ token: d.token, user: res.user }));
              } 
              // 2. Explicit Rejection: Server explicitly says the token is invalid/expired
              else if (res && res.success === false && res.error) {
                console.warn('Session expired:', res.error);
                localStorage.removeItem('lm_auth');
                setToken(null);
                setUser(null);
              }
              // 3. Network Blip: Server didn't respond correctly, but didn't explicitly reject
              else {
                console.warn('Could not validate session cleanly. Keeping user logged in locally.');
              }
            } catch (err: any) {
              // If we get a hard 401 Unauthorized, we log out. Otherwise, we keep the session active.
              if (err?.message?.includes('401') || err?.message?.includes('Unauthorized')) {
                localStorage.removeItem('lm_auth');
                setToken(null);
                setUser(null);
              } else {
                console.warn('Network error during validation. Keeping existing session.');
              }
            }
          } else {
            localStorage.removeItem('lm_auth');
            setToken(null);
            setUser(null);
          }
        } catch {
          console.error('Corrupted auth data. Logging out.');
          localStorage.removeItem('lm_auth');
          setToken(null);
          setUser(null);
        }
      }
      setLoading(false);
    })();
  }, []);

  const login = async (email: string, password: string): Promise<string | null> => {
    try {
      const d = await apiLogin(email, password);
      if (!d.success) return d.error || 'Login failed';
      setToken(d.token);
      setUser(d.user);
      localStorage.setItem('lm_auth', JSON.stringify({ token: d.token, user: d.user }));
      return null;
    } catch (e) {
      return 'Network error. Please try again.';
    }
  };

  const logout = () => {
    setToken(null); 
    setUser(null);
    localStorage.removeItem('lm_auth');
    localStorage.removeItem('lm_current_page'); // Clears cached page state too
  };

  return (
    <AuthContext.Provider value={{ token, user, isAdmin: user?.role === 'admin', login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);