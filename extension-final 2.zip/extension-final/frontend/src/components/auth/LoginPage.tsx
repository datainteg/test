import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { checkHealth } from '@/services/api';
import StatusDot from '@/components/ui/StatusDot';
import { FiMail, FiLock, FiLogIn } from 'react-icons/fi';

export default function LoginPage() {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [online, setOnline] = useState(false);

  useEffect(() => { checkHealth().then(setOnline); }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) { setError('Enter email and password'); return; }
    setLoading(true); setError('');
    const err = await login(email, password);
    if (err) { setError(err); setLoading(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-cream-50 via-white to-igreen-50/30 p-4">
      {/* Tiranga Top Bar */}
      <div className="fixed top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-saffron-500 via-white to-igreen-500" />

      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-saffron-400 to-saffron-600 rounded-2xl flex items-center justify-center shadow-glow-saffron">
            <span className="text-4xl">🎯</span>
          </div>
          <h1 className="text-2xl font-bold text-navy-500">Extension Dashboard</h1>
          <p className="text-slate-500 text-sm mt-1">Chrome Extension Lead Manager</p>
        </div>

        {/* Login Card */}
        <div className="bg-white border border-saffron-100 rounded-2xl shadow-lg p-6 sm:p-8">
          <h2 className="text-lg font-semibold text-slate-800 mb-6 text-center">Sign In</h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
                <span>⚠️</span> {error}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1.5">Email</label>
              <div className="relative">
                <FiMail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="email" value={email} onChange={e => setEmail(e.target.value)}
                  placeholder="you@company.com" autoComplete="email"
                  className="w-full pl-10 pr-4 py-2.5 border border-saffron-200 rounded-lg text-sm focus:outline-none focus:border-saffron-400 focus:ring-2 focus:ring-saffron-100"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1.5">Password</label>
              <div className="relative">
                <FiLock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="password" value={password} onChange={e => setPassword(e.target.value)}
                  placeholder="Your password" autoComplete="current-password"
                  className="w-full pl-10 pr-4 py-2.5 border border-saffron-200 rounded-lg text-sm focus:outline-none focus:border-saffron-400 focus:ring-2 focus:ring-saffron-100"
                />
              </div>
            </div>

            <button
              type="submit" disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-saffron-500 to-saffron-600 hover:from-saffron-600 hover:to-saffron-700 text-white font-semibold rounded-lg text-sm disabled:opacity-50 transition-all shadow-glow-saffron"
            >
              <FiLogIn className="w-4 h-4" />
              {loading ? 'Signing in…' : 'Sign In'}
            </button>
          </form>

          <div className="flex items-center justify-center gap-2 mt-6 text-xs text-slate-400">
            <StatusDot online={online} />
            {online ? 'Server online' : 'Server offline'}
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-xs text-slate-400 mt-6">
          Extension Dashboard v10.0 • Tiranga Edition
        </p>
      </div>
    </div>
  );
}
