import { useState, useEffect, useCallback } from 'react';
import { 
  FiDownload, FiTrash2, FiFilter, FiX, FiChevronLeft, FiChevronRight, 
  FiMapPin, FiClock, FiTarget, FiCheckSquare, FiSquare, FiSettings,
  FiAlertTriangle, FiRefreshCw
} from 'react-icons/fi';
import type { Lead } from '@/types';
import { getLeads, exportLeads, clearLeadsWithFilters, deleteLeads, deleteLead, getCategories } from '@/services/api';
import { useSellers } from '@/context/SellerContext';
import { useToast } from '@/components/ui/Toast';
import { ScoreBadge } from '@/components/ui/Badge';
import Badge from '@/components/ui/Badge';
import Modal from '@/components/ui/Modal';

const toIST = (iso: string) =>
  new Date(iso).toLocaleString('en-IN', {
    timeZone: 'Asia/Kolkata',
    day: '2-digit', month: '2-digit', year: '2-digit',
    hour: '2-digit', minute: '2-digit', hour12: true,
  });

function cleanCity(city?: string): string {
  if (!city) return '—';
  return city
    .replace(/Click here.*$/i, '')
    .replace(/View.*BuyLeads.*$/i, '')
    .replace(/BuyLeads.*$/i, '')
    .replace(/Shortlist.*$/i, '')
    .replace(/[^A-Za-z\s]/g, '')
    .replace(/\s+/g, ' ')
    .trim() || '—';
}

const RETENTION_OPTIONS = [
  { value: 0, label: 'All Time' },
  { value: 7, label: '7 Days' },
  { value: 14, label: '14 Days' },
  { value: 30, label: '30 Days' },
  { value: 60, label: '60 Days' },
  { value: 90, label: '90 Days' },
];

export default function LeadsPage() {
  const { currentSellerId } = useSellers();
  const { toast } = useToast();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [categories, setCategories] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [loading, setLoading] = useState(true);

  // Selection state
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [selectMode, setSelectMode] = useState(false);

  // Smart Clear Modal
  const [showClearModal, setShowClearModal] = useState(false);
  const [clearOptions, setClearOptions] = useState({
    olderThanDays: 30,
    status: 'all' as 'contacted' | 'not_contacted' | 'all',
    maxScore: 100,
    clearSelected: false,
  });
  const [clearing, setClearing] = useState(false);

  // Filters
  const [clicked, setClicked] = useState('');
  const [city, setCity] = useState('');
  const [minScore, setMinScore] = useState('');
  const [category, setCategory] = useState('');
  const [appliedFilters, setAppliedFilters] = useState({ clicked: '', city: '', minScore: '', category: '' });

  const load = useCallback(async () => {
    setLoading(true);
    const params: Record<string, string> = { page: String(page), limit: '25', sort: 'capturedAt', order: 'desc' };
    if (currentSellerId) params.sellerId = currentSellerId;
    if (appliedFilters.clicked) params.clicked = appliedFilters.clicked;
    if (appliedFilters.city) params.city = appliedFilters.city;
    if (appliedFilters.minScore) params.minScore = appliedFilters.minScore;
    if (appliedFilters.category) params.category = appliedFilters.category;
    try {
      const d = await getLeads(params);
      if (d.success) { 
        setLeads(d.data || []); 
        setTotalPages(d.pages || 1);
        setTotalCount(d.total || 0);
      }
    } catch {}
    setLoading(false);
  }, [page, currentSellerId, appliedFilters]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    (async () => {
      try {
        const d = await getCategories(currentSellerId || undefined);
        if (d.success) setCategories(d.categories || []);
      } catch {}
    })();
  }, [currentSellerId]);

  // Clear selection when page changes
  useEffect(() => {
    setSelectedIds(new Set());
  }, [page, currentSellerId]);

  const handleExport = async () => {
    try {
      const blob = await exportLeads(currentSellerId || undefined);
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `leadmagnet_export_${Date.now()}.csv`;
      document.body.appendChild(a); a.click(); a.remove();
      toast('Export downloaded', 'success');
    } catch { toast('Export failed', 'error'); }
  };

  const handleSmartClear = async () => {
    setClearing(true);
    try {
      const options: any = {
        sellerId: currentSellerId || undefined,
      };

      if (clearOptions.clearSelected && selectedIds.size > 0) {
        // Delete selected leads only
        options.selectedIds = Array.from(selectedIds);
      } else {
        // Apply smart filters
        if (clearOptions.olderThanDays > 0) {
          options.olderThanDays = clearOptions.olderThanDays;
        }
        if (clearOptions.status !== 'all') {
          options.status = clearOptions.status;
        }
        if (clearOptions.maxScore < 100) {
          options.maxScore = clearOptions.maxScore;
        }
      }

      const d = await clearLeadsWithFilters(options);
      if (d.success) {
        toast(`Cleared ${d.deleted || 0} leads`, 'success');
        setShowClearModal(false);
        setSelectedIds(new Set());
        setSelectMode(false);
        load();
      } else {
        toast(d.error || 'Clear failed', 'error');
      }
    } catch (e) {
      toast('Clear failed', 'error');
    }
    setClearing(false);
  };

  const handleDeleteSelected = async () => {
    if (selectedIds.size === 0) return;
    
    if (!confirm(`Delete ${selectedIds.size} selected lead(s)? This cannot be undone.`)) return;
    
    try {
      const d = await deleteLeads(Array.from(selectedIds));
      if (d.success) {
        toast(`Deleted ${selectedIds.size} leads`, 'success');
        setSelectedIds(new Set());
        load();
      } else {
        toast(d.error || 'Delete failed', 'error');
      }
    } catch {
      toast('Delete failed', 'error');
    }
  };

  const handleDeleteSingle = async (leadId: string, title: string) => {
    if (!confirm(`Delete lead "${title}"?`)) return;
    try {
      const d = await deleteLead(leadId);
      if (d.success) {
        toast('Lead deleted', 'success');
        load();
      } else {
        toast(d.error || 'Delete failed', 'error');
      }
    } catch {
      toast('Delete failed', 'error');
    }
  };

  const toggleSelect = (id: string) => {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setSelectedIds(newSet);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === leads.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(leads.map(l => l._id)));
    }
  };

  const applyFilters = () => {
    setPage(1);
    setAppliedFilters({ clicked, city, minScore, category });
    setShowFilters(false);
  };

  const clearFilters = () => {
    setClicked(''); setCity(''); setMinScore(''); setCategory('');
    setAppliedFilters({ clicked: '', city: '', minScore: '', category: '' });
    setPage(1);
  };

  const hasFilters = clicked || city || minScore || category;
  const allSelected = leads.length > 0 && selectedIds.size === leads.length;

  return (
    <div className="space-y-4">

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-saffron-400 to-saffron-500 flex items-center justify-center">
            <FiTarget className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-navy-500">All Leads</h1>
            <p className="text-sm text-slate-500">
              {totalCount.toLocaleString()} total • Page {page} of {totalPages}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <button 
            onClick={() => setSelectMode(!selectMode)}
            className={`flex items-center gap-1.5 text-sm font-medium px-3 py-2 border rounded-lg transition-colors ${
              selectMode ? 'bg-navy-500 text-white border-navy-500' : 'text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <FiCheckSquare size={14} /> Select
          </button>
          <button onClick={() => setShowFilters(v => !v)}
            className={`flex items-center gap-1.5 text-sm font-medium px-3 py-2 border rounded-lg transition-colors ${
              showFilters ? 'bg-saffron-500 text-white border-saffron-500' : 'text-slate-600 border-saffron-200 hover:bg-saffron-50'
            }`}
          >
            <FiFilter size={14} /> Filters
          </button>
          <button onClick={handleExport}
            className="flex items-center gap-1.5 text-sm font-medium text-igreen-600 px-3 py-2 bg-igreen-50 border border-igreen-200 rounded-lg hover:bg-igreen-100">
            <FiDownload size={14} /> Export
          </button>
          <button onClick={() => setShowClearModal(true)}
            className="flex items-center gap-1.5 text-sm font-medium text-red-500 px-3 py-2 bg-red-50 border border-red-200 rounded-lg hover:bg-red-100">
            <FiSettings size={14} /> Smart Clear
          </button>
        </div>
      </div>

      {/* Selection Bar */}
      {selectMode && (
        <div className="bg-navy-50 border border-navy-200 rounded-xl p-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={toggleSelectAll} className="flex items-center gap-2 text-sm font-medium text-navy-700">
              {allSelected ? <FiCheckSquare size={16} /> : <FiSquare size={16} />}
              {allSelected ? 'Deselect All' : 'Select All'}
            </button>
            <span className="text-sm text-navy-600">
              {selectedIds.size} selected
            </span>
          </div>
          <div className="flex gap-2">
            {selectedIds.size > 0 && (
              <>
                <button 
                  onClick={() => { setClearOptions({ ...clearOptions, clearSelected: true }); setShowClearModal(true); }}
                  className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-amber-600 bg-amber-50 border border-amber-200 rounded-lg hover:bg-amber-100"
                >
                  <FiTrash2 size={12} /> Clear Selected
                </button>
                <button 
                  onClick={handleDeleteSelected}
                  className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-red-500 bg-red-50 border border-red-200 rounded-lg hover:bg-red-100"
                >
                  <FiTrash2 size={12} /> Delete Selected
                </button>
              </>
            )}
            <button 
              onClick={() => { setSelectMode(false); setSelectedIds(new Set()); }}
              className="px-3 py-1.5 text-xs font-medium text-slate-500 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Filters Panel */}
      {showFilters && (
        <div className="bg-white border border-saffron-100 rounded-xl p-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <select value={clicked} onChange={e => setClicked(e.target.value)}
              className="text-sm px-3 py-2 border border-saffron-200 rounded-lg bg-white focus:outline-none focus:border-saffron-400">
              <option value="">All Status</option>
              <option value="true">Contacted</option>
              <option value="false">Not Contacted</option>
            </select>
            <input value={city} onChange={e => setCity(e.target.value)} placeholder="City…"
              className="text-sm px-3 py-2 border border-saffron-200 rounded-lg focus:outline-none focus:border-saffron-400" />
            <input value={minScore} onChange={e => setMinScore(e.target.value)} placeholder="Min score" type="number" min={0} max={100}
              className="text-sm px-3 py-2 border border-saffron-200 rounded-lg focus:outline-none focus:border-saffron-400" />
            <select value={category} onChange={e => setCategory(e.target.value)}
              className="text-sm px-3 py-2 border border-saffron-200 rounded-lg bg-white focus:outline-none focus:border-saffron-400">
              <option value="">All Categories</option>
              {categories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div className="flex gap-2 mt-3">
            <button onClick={applyFilters}
              className="px-4 py-2 text-sm font-semibold text-white bg-saffron-500 rounded-lg hover:bg-saffron-600">
              Apply Filters
            </button>
            {hasFilters && (
              <button onClick={clearFilters}
                className="flex items-center gap-1 px-3 py-2 text-sm text-red-500 bg-red-50 border border-red-200 rounded-lg hover:bg-red-100">
                <FiX size={14} /> Clear
              </button>
            )}
          </div>
        </div>
      )}

      {/* Leads Table/Cards */}
      <div className="bg-white border border-saffron-100 rounded-xl overflow-hidden">

        {/* Mobile Cards */}
        <div className="sm:hidden divide-y divide-saffron-50">
          {loading ? (
            <div className="text-center py-10 text-slate-400 text-sm">Loading...</div>
          ) : leads.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-sm">No leads found</div>
          ) : leads.map(l => (
            <div key={l._id} className={`px-4 py-3 ${selectedIds.has(l._id) ? 'bg-navy-50' : 'hover:bg-cream-50'}`}>
              <div className="flex items-start gap-2 justify-between">
                {selectMode && (
                  <button onClick={() => toggleSelect(l._id)} className="mt-0.5 text-navy-500">
                    {selectedIds.has(l._id) ? <FiCheckSquare size={18} /> : <FiSquare size={18} />}
                  </button>
                )}
                <div className="font-medium text-sm text-slate-800 truncate flex-1">{l.title || '—'}</div>
                <ScoreBadge score={l.score} />
              </div>
              <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500">
                <span className="flex items-center gap-1"><FiMapPin size={12} /> {cleanCity(l.location?.city)}</span>
                <span>🏷️ {l.detectedCategory || l.category || '—'}</span>
                {l.orderValue?.display && <span>💰 {l.orderValue.display}</span>}
              </div>
              <div className="mt-2 flex items-center gap-2">
                {l.status?.clicked ? <Badge variant="success">Contacted</Badge> : <Badge variant="muted">New</Badge>}
                <span className="text-[10px] text-slate-400 ml-auto flex items-center gap-1">
                  <FiClock size={10} /> {l.capturedAt ? toIST(l.capturedAt) : '—'}
                </span>
                {!selectMode && (
                  <button 
                    onClick={() => handleDeleteSingle(l._id, l.title || 'Untitled')}
                    className="p-1 text-red-400 hover:text-red-600"
                  >
                    <FiTrash2 size={14} />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Desktop Table */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-cream-50 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {selectMode && (
                  <th className="px-4 py-3 w-10">
                    <button onClick={toggleSelectAll} className="text-navy-500">
                      {allSelected ? <FiCheckSquare size={16} /> : <FiSquare size={16} />}
                    </button>
                  </th>
                )}
                <th className="px-4 py-3">Title</th>
                <th className="px-4 py-3">City</th>
                <th className="px-4 py-3 hidden md:table-cell">Category</th>
                <th className="px-4 py-3">Score</th>
                <th className="px-4 py-3 hidden lg:table-cell">Order Value</th>
                <th className="px-4 py-3">Contacted</th>
                <th className="px-4 py-3">Captured (IST)</th>
                <th className="px-4 py-3 w-10"></th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={selectMode ? 10 : 9} className="text-center py-10 text-slate-400">Loading...</td></tr>
              ) : leads.length === 0 ? (
                <tr><td colSpan={selectMode ? 10 : 9} className="text-center py-10 text-slate-400">No leads found</td></tr>
              ) : leads.map(l => (
                <tr 
                  key={l._id} 
                  className={`border-t border-saffron-50 ${selectedIds.has(l._id) ? 'bg-navy-50' : 'hover:bg-cream-50'}`}
                >
                  {selectMode && (
                    <td className="px-4 py-3">
                      <button onClick={() => toggleSelect(l._id)} className="text-navy-500">
                        {selectedIds.has(l._id) ? <FiCheckSquare size={16} /> : <FiSquare size={16} />}
                      </button>
                    </td>
                  )}
                  <td className="px-4 py-3 max-w-[180px] truncate font-medium text-slate-800" title={l.title}>{l.title || '—'}</td>
                  <td className="px-4 py-3 text-slate-500">{cleanCity(l.location?.city)}</td>
                  <td className="px-4 py-3 text-xs hidden md:table-cell">{l.detectedCategory || l.category || '—'}</td>
                  <td className="px-4 py-3"><ScoreBadge score={l.score} /></td>
                  <td className="px-4 py-3 hidden lg:table-cell text-xs">{l.orderValue?.display || '—'}</td>
                  <td className="px-4 py-3">
                    {l.status?.clicked ? <Badge variant="success">Yes</Badge> : <Badge variant="muted">No</Badge>}
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-400 font-mono">
                    {l.capturedAt ? toIST(l.capturedAt) : '—'}
                  </td>
                  <td className="px-4 py-3">
                    {!selectMode && (
                      <button 
                        onClick={() => handleDeleteSingle(l._id, l.title || 'Untitled')}
                        className="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded"
                        title="Delete"
                      >
                        <FiTrash2 size={14} />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="px-4 py-3 border-t border-saffron-100 flex items-center justify-between bg-cream-50">
            <span className="text-sm text-slate-500">Page {page} of {totalPages}</span>
            <div className="flex gap-2">
              <button disabled={page <= 1} onClick={() => setPage(p => p - 1)}
                className="flex items-center gap-1 px-3 py-1.5 text-sm border border-saffron-200 rounded-lg disabled:opacity-40 hover:bg-saffron-100">
                <FiChevronLeft size={14} /> Prev
              </button>
              <button disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}
                className="flex items-center gap-1 px-3 py-1.5 text-sm border border-saffron-200 rounded-lg disabled:opacity-40 hover:bg-saffron-100">
                Next <FiChevronRight size={14} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Smart Clear Modal */}
      <Modal 
        open={showClearModal} 
        onClose={() => { setShowClearModal(false); setClearOptions({ ...clearOptions, clearSelected: false }); }} 
        title="Smart Clear Leads"
        footer={
          <button 
            onClick={handleSmartClear}
            disabled={clearing}
            className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white text-sm font-semibold rounded-lg hover:bg-red-600 disabled:opacity-50"
          >
            {clearing ? <FiRefreshCw className="w-4 h-4 animate-spin" /> : <FiTrash2 className="w-4 h-4" />}
            {clearing ? 'Clearing...' : 'Clear Leads'}
          </button>
        }
      >
        <div className="space-y-4">
          {clearOptions.clearSelected && selectedIds.size > 0 ? (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-center">
              <FiAlertTriangle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
              <p className="text-sm text-amber-800">
                You are about to delete <strong>{selectedIds.size}</strong> selected lead(s).
              </p>
            </div>
          ) : (
            <>
              {/* Retention Period */}
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-2">
                  🗓️ Retention Period
                </label>
                <p className="text-xs text-slate-400 mb-2">Clear leads older than selected period</p>
                <div className="grid grid-cols-3 gap-2">
                  {RETENTION_OPTIONS.map(opt => (
                    <button
                      key={opt.value}
                      onClick={() => setClearOptions({ ...clearOptions, olderThanDays: opt.value })}
                      className={`px-3 py-2 text-sm font-medium rounded-lg border transition-colors ${
                        clearOptions.olderThanDays === opt.value
                          ? 'bg-saffron-500 text-white border-saffron-500'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Status Filter */}
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-2">
                  📋 Lead Status
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { value: 'all', label: 'All' },
                    { value: 'contacted', label: 'Contacted' },
                    { value: 'not_contacted', label: 'Not Contacted' },
                  ].map(opt => (
                    <button
                      key={opt.value}
                      onClick={() => setClearOptions({ ...clearOptions, status: opt.value as any })}
                      className={`px-3 py-2 text-sm font-medium rounded-lg border transition-colors ${
                        clearOptions.status === opt.value
                          ? 'bg-igreen-500 text-white border-igreen-500'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Max Score */}
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-2">
                  🎯 Max Score (clear leads with score ≤)
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={clearOptions.maxScore}
                    onChange={e => setClearOptions({ ...clearOptions, maxScore: Number(e.target.value) })}
                    className="flex-1 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-saffron-500"
                  />
                  <span className={`w-12 text-center text-sm font-bold ${
                    clearOptions.maxScore >= 60 ? 'text-red-500' : 
                    clearOptions.maxScore >= 25 ? 'text-amber-500' : 'text-cyan-500'
                  }`}>
                    {clearOptions.maxScore}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  {clearOptions.maxScore === 100 ? 'All scores' : `Only leads with score ≤ ${clearOptions.maxScore}`}
                </p>
              </div>
            </>
          )}

          {/* Warning */}
          <div className="bg-red-50 border border-red-200 rounded-lg p-3">
            <p className="text-xs text-red-600">
              ⚠️ This action cannot be undone. Cleared leads will be permanently deleted.
            </p>
          </div>
        </div>
      </Modal>
    </div>
  );
}