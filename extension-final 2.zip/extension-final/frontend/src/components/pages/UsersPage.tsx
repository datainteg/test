import { useState, useEffect, useCallback } from 'react';
import { FiPlus, FiTrash2, FiToggleLeft, FiToggleRight, FiUsers, FiRefreshCw, FiAlertTriangle, FiSearch } from 'react-icons/fi';
import { getUsers, createUser, updateUser, deleteUser } from '@/services/api';
import { useToast } from '@/components/ui/Toast';
import { useSellers } from '@/context/SellerContext';
import Modal from '@/components/ui/Modal';
import Badge from '@/components/ui/Badge';

interface UserRow {
  _id: string; name: string; email: string;
  role: string; sellerId: string; active: boolean;
  seller?: { name: string; sellerId: string } | null;
  createdAt?: string; lastLogin?: string; loginCount?: number;
}

const toIST = (iso: string) =>
  new Date(iso).toLocaleString('en-IN', {
    timeZone: 'Asia/Kolkata', dateStyle: 'short', timeStyle: 'short',
  });

export default function UsersPage() {
  const { toast } = useToast();
  const { sellers } = useSellers();
  const [users, setUsers] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [open, setOpen] = useState(false);
  const [deleteModal, setDeleteModal] = useState<UserRow | null>(null);
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState('seller');

  const load = useCallback(async () => {
    setLoading(true);
    try { const d = await getUsers(); if (d.success) setUsers(d.users || []); } catch {}
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const filteredUsers = users.filter(u => {
    if (!search) return true;
    const q = search.toLowerCase();
    return u.name?.toLowerCase().includes(q) || u.email.toLowerCase().includes(q);
  });

  const handleCreate = async () => {
    if (!email || !pw) { toast('Email and password required', 'error'); return; }
    if (pw.length < 6) { toast('Password min 6 characters', 'error'); return; }
    const d = await createUser({ email, password: pw, name, role });
    if (d.success) { toast('User created', 'success'); setOpen(false); setEmail(''); setPw(''); setName(''); load(); }
    else toast(d.error || 'Failed', 'error');
  };

  const handleToggle = async (userId: string, currentActive: boolean) => {
    const d = await updateUser(userId, { active: !currentActive });
    if (d.success) { toast(currentActive ? 'User disabled' : 'User enabled', 'success'); load(); }
    else toast(d.error || 'Failed', 'error');
  };

  const handleDelete = async () => {
    if (!deleteModal) return;
    const d = await deleteUser(deleteModal._id);
    if (d.success) { toast('User deleted', 'success'); setDeleteModal(null); load(); }
    else toast(d.error || 'Failed', 'error');
  };

  return (
    <div className="space-y-4">

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-saffron-400 to-saffron-500 flex items-center justify-center">
            <FiUsers className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-navy-500">User Management</h1>
            <p className="text-sm text-slate-500">{filteredUsers.length} of {users.length} users</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button onClick={load} disabled={loading} className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-saffron-600 bg-saffron-50 border border-saffron-200 rounded-lg hover:bg-saffron-100">
            <FiRefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Refresh
          </button>
          <button onClick={() => setOpen(true)} className="flex items-center gap-1.5 px-3 py-2 text-sm font-semibold text-white bg-saffron-500 rounded-lg hover:bg-saffron-600">
            <FiPlus size={14} /> Add User
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white border border-saffron-100 rounded-xl p-4">
        <div className="relative max-w-sm">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search users..."
            className="w-full pl-10 pr-4 py-2 text-sm border border-saffron-200 rounded-lg focus:outline-none focus:border-saffron-400"
          />
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white border border-saffron-100 rounded-xl overflow-hidden">
        {/* Mobile Cards */}
        <div className="sm:hidden divide-y divide-saffron-50">
          {loading ? (
            <div className="text-center py-10 text-slate-400 text-sm">Loading...</div>
          ) : filteredUsers.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-sm">No users found</div>
          ) : filteredUsers.map(u => {
            const isActive = u.active !== false;
            return (
              <div key={u._id} className="px-4 py-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="font-semibold text-slate-800 text-sm truncate">{u.name || u.email}</div>
                    <div className="text-xs text-slate-400 truncate">{u.email}</div>
                  </div>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <Badge variant={u.role === 'admin' ? 'accent' : 'muted'}>{u.role}</Badge>
                    <Badge variant={isActive ? 'success' : 'danger'}>{isActive ? 'On' : 'Off'}</Badge>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <button onClick={() => handleToggle(u._id, isActive)}
                    className={`flex-1 flex items-center justify-center gap-1 text-xs font-medium py-2 rounded-lg border ${isActive ? 'text-amber-600 border-amber-200 bg-amber-50' : 'text-igreen-600 border-igreen-200 bg-igreen-50'}`}>
                    {isActive ? <FiToggleRight size={14} /> : <FiToggleLeft size={14} />}
                    {isActive ? 'Disable' : 'Enable'}
                  </button>
                  <button onClick={() => setDeleteModal(u)}
                    className="flex-1 flex items-center justify-center gap-1 text-xs font-medium py-2 rounded-lg border text-red-500 border-red-200 bg-red-50">
                    <FiTrash2 size={13} /> Delete
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Desktop Table */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-cream-50 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Email</th>
                <th className="px-4 py-3">Role</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 hidden md:table-cell">Last Login</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="text-center py-10 text-slate-400">Loading...</td></tr>
              ) : filteredUsers.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-10 text-slate-400">No users found</td></tr>
              ) : filteredUsers.map(u => {
                const isActive = u.active !== false;
                return (
                  <tr key={u._id} className="border-t border-saffron-50 hover:bg-cream-50">
                    <td className="px-4 py-3 font-semibold text-slate-800">{u.name || '—'}</td>
                    <td className="px-4 py-3 text-slate-500 text-xs">{u.email}</td>
                    <td className="px-4 py-3"><Badge variant={u.role === 'admin' ? 'accent' : 'muted'}>{u.role}</Badge></td>
                    <td className="px-4 py-3"><Badge variant={isActive ? 'success' : 'danger'}>{isActive ? 'Active' : 'Disabled'}</Badge></td>
                    <td className="px-4 py-3 text-xs text-slate-400 hidden md:table-cell">{u.lastLogin ? toIST(u.lastLogin) : 'Never'}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-2">
                        <button onClick={() => handleToggle(u._id, isActive)}
                          className={`flex items-center gap-1 text-xs font-medium px-2 py-1.5 rounded-lg border ${isActive ? 'text-amber-600 border-amber-200 bg-amber-50' : 'text-igreen-600 border-igreen-200 bg-igreen-50'}`}>
                          {isActive ? <FiToggleRight size={13} /> : <FiToggleLeft size={13} />}
                          {isActive ? 'Disable' : 'Enable'}
                        </button>
                        <button onClick={() => setDeleteModal(u)}
                          className="flex items-center gap-1 text-xs font-medium px-2 py-1.5 rounded-lg border text-red-500 border-red-200 bg-red-50">
                          <FiTrash2 size={13} /> Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Modal */}
      <Modal open={open} onClose={() => setOpen(false)} title="Create New User" footer={
        <button onClick={handleCreate} className="px-4 py-2 bg-saffron-500 text-white text-sm font-semibold rounded-lg hover:bg-saffron-600">Create User</button>
      }>
        <div className="space-y-4">
          <div><label className="block text-sm font-medium text-slate-600 mb-1">Email *</label>
            <input value={email} onChange={e => setEmail(e.target.value)} type="email" placeholder="user@example.com"
              className="w-full px-3 py-2 border border-saffron-200 rounded-lg text-sm focus:outline-none focus:border-saffron-400" /></div>
          <div><label className="block text-sm font-medium text-slate-600 mb-1">Password *</label>
            <input value={pw} onChange={e => setPw(e.target.value)} type="password" placeholder="Min 6 characters"
              className="w-full px-3 py-2 border border-saffron-200 rounded-lg text-sm focus:outline-none focus:border-saffron-400" /></div>
          <div><label className="block text-sm font-medium text-slate-600 mb-1">Name</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="Full name"
              className="w-full px-3 py-2 border border-saffron-200 rounded-lg text-sm focus:outline-none focus:border-saffron-400" /></div>
          <div><label className="block text-sm font-medium text-slate-600 mb-1">Role</label>
            <select value={role} onChange={e => setRole(e.target.value)} className="w-full px-3 py-2 border border-saffron-200 rounded-lg text-sm bg-white">
              <option value="seller">Seller</option><option value="admin">Admin</option>
            </select></div>
        </div>
      </Modal>

      {/* Delete Modal */}
      <Modal open={!!deleteModal} onClose={() => setDeleteModal(null)} title="Delete User" footer={
        <div className="flex gap-3">
          <button onClick={() => setDeleteModal(null)} className="px-4 py-2 text-sm font-medium text-slate-600 bg-slate-100 rounded-lg">Cancel</button>
          <button onClick={handleDelete} className="px-4 py-2 text-sm font-semibold text-white bg-red-500 rounded-lg">Delete</button>
        </div>
      }>
        <div className="text-center py-4">
          <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-red-100 flex items-center justify-center">
            <FiAlertTriangle className="w-7 h-7 text-red-500" />
          </div>
          <p className="text-slate-600">Delete <strong>{deleteModal?.name || deleteModal?.email}</strong>?</p>
        </div>
      </Modal>
    </div>
  );
}
