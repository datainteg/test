import { useState, useMemo } from 'react';
import { FiPlus, FiX, FiChevronDown, FiKey, FiTag, FiMapPin, FiDollarSign } from 'react-icons/fi';
import { useSellers } from '@/context/SellerContext';
import { addKeyword, removeKeyword } from '@/services/api';
import { useToast } from '@/components/ui/Toast';

const groups = [
  { key: 'category' as const, label: 'Category Keywords', icon: FiTag, desc: 'IndiaMART category names', color: 'saffron' },
  { key: 'city' as const, label: 'City Keywords', icon: FiMapPin, desc: 'Target cities, states', color: 'igreen' },
  { key: 'value' as const, label: 'Value Keywords', icon: FiDollarSign, desc: 'Prices, budgets', color: 'navy' },
];

const tagStyle = {
  category: 'bg-saffron-50 text-saffron-700 border-saffron-200',
  city: 'bg-igreen-50 text-igreen-700 border-igreen-200',
  value: 'bg-navy-50 text-navy-700 border-navy-200',
};

const headerStyle = {
  category: 'bg-saffron-50 border-saffron-200 text-saffron-700',
  city: 'bg-igreen-50 border-igreen-200 text-igreen-700',
  value: 'bg-navy-50 border-navy-200 text-navy-700',
};

function arr(v: any): string[] {
  return Array.isArray(v) ? v : [];
}

export default function KeywordsPage() {
  const { sellers, refresh } = useSellers();
  const { toast } = useToast();

  const [selectedSellerId, setSelectedSellerId] = useState('');
  const [kw, setKw] = useState('');
  const [cat, setCat] = useState<'category' | 'city' | 'value'>('category');

  const selectedSeller = useMemo(
    () => sellers.find(s => s.sellerId === selectedSellerId),
    [sellers, selectedSellerId]
  );

  const cats = {
    category: arr(selectedSeller?.keywordCategories?.category),
    city: arr(selectedSeller?.keywordCategories?.city),
    value: arr(selectedSeller?.keywordCategories?.value),
  };

  const totalKw = arr(selectedSeller?.keywords).length;

  const handleAdd = async () => {
    if (!kw.trim()) return toast('Enter a keyword', 'error');
    if (!selectedSellerId) return toast('Select a seller first', 'error');

    const sanitized = kw.replace(/<[^>]*>/g, '').replace(/[<>"'`]/g, '').trim().toLowerCase().substring(0, 100);
    if (!sanitized) return toast('Invalid keyword', 'error');

    try {
      const d = await addKeyword(selectedSellerId, sanitized, cat);
      if (d.success) { toast('Keyword added', 'success'); setKw(''); refresh(); }
      else toast(d.error || 'Failed', 'error');
    } catch (e) {
      toast('Error: ' + (e instanceof Error ? e.message : 'Unknown'), 'error');
    }
  };

  const handleRemove = async (keyword: string) => {
    if (!selectedSellerId) return;
    try {
      const d = await removeKeyword(selectedSellerId, keyword);
      if (d.success) { toast('Removed', 'success'); refresh(); }
      else toast(d.error || 'Failed', 'error');
    } catch (e) {
      toast('Error: ' + (e instanceof Error ? e.message : 'Unknown'), 'error');
    }
  };

  return (
    <div className="space-y-6">

      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-saffron-400 to-saffron-500 flex items-center justify-center">
          <FiKey className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="text-lg font-bold text-navy-500">Keywords</h1>
          <p className="text-sm text-slate-500">Manage auto-click keywords by seller</p>
        </div>
      </div>

      {/* Seller Selector */}
      <div className="bg-white border border-saffron-100 rounded-xl p-4">
        <label className="block text-xs font-semibold text-slate-500 uppercase mb-2">Select Seller</label>
        <div className="relative">
          <select
            value={selectedSellerId}
            onChange={e => setSelectedSellerId(e.target.value)}
            className="w-full px-3 py-2.5 border border-saffron-200 rounded-lg text-sm bg-white appearance-none pr-10 focus:outline-none focus:border-saffron-400"
          >
            <option value="">— Choose a seller —</option>
            {sellers.map(s => (
              <option key={s.sellerId} value={s.sellerId}>
                {s.name || 'Unnamed'} ({s.sellerId}) — {arr(s.keywords).length} keywords
              </option>
            ))}
          </select>
          <FiChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
        </div>

        {selectedSeller && (
          <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-slate-500">
            <span className="font-semibold text-slate-800">{selectedSeller.name}</span>
            <span className="px-2 py-0.5 rounded-full bg-slate-100">{totalKw} keywords</span>
            <span className={`px-2 py-0.5 rounded-full ${selectedSeller.active !== false ? 'bg-igreen-50 text-igreen-600' : 'bg-red-50 text-red-500'}`}>
              {selectedSeller.active !== false ? 'Active' : 'Disabled'}
            </span>
          </div>
        )}
      </div>

      {/* Add Keyword Form */}
      <div className="bg-white border border-saffron-100 rounded-xl p-4">
        <div className="flex items-center gap-2 mb-4">
          <FiPlus className="w-4 h-4 text-saffron-500" />
          <h3 className="font-semibold text-slate-800">Add Keyword</h3>
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            value={kw}
            onChange={e => setKw(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleAdd()}
            placeholder={selectedSellerId ? 'Enter keyword…' : 'Select a seller first'}
            disabled={!selectedSellerId}
            className="flex-1 px-3 py-2.5 border border-saffron-200 rounded-lg text-sm focus:outline-none focus:border-saffron-400 disabled:opacity-50 disabled:bg-slate-50"
          />
          <select
            value={cat}
            onChange={e => setCat(e.target.value as any)}
            disabled={!selectedSellerId}
            className="px-3 py-2.5 border border-saffron-200 rounded-lg text-sm bg-white disabled:opacity-50"
          >
            <option value="category">🏷️ Category</option>
            <option value="city">📍 City</option>
            <option value="value">💰 Value</option>
          </select>
          <button
            onClick={handleAdd}
            disabled={!selectedSellerId}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-saffron-500 text-white font-semibold rounded-lg hover:bg-saffron-600 disabled:opacity-50"
          >
            <FiPlus size={16} /> Add
          </button>
        </div>
        <p className="text-xs text-slate-400 mt-2">Press Enter to add quickly</p>
      </div>

      {/* Keywords by Category */}
      {!selectedSellerId ? (
        <div className="text-center py-12 text-slate-400 bg-white border border-saffron-100 rounded-xl">
          Select a seller above to manage keywords
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-3">
          {groups.map(g => {
            const kws = arr(cats[g.key]);
            const Icon = g.icon;
            return (
              <div key={g.key} className="bg-white border border-saffron-100 rounded-xl overflow-hidden">
                <div className={`px-4 py-3 border-b ${headerStyle[g.key]}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Icon className="w-4 h-4" />
                      <span className="font-semibold text-sm">{g.label}</span>
                    </div>
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-white/50">{kws.length}</span>
                  </div>
                </div>
                <div className="p-4">
                  {kws.length === 0 ? (
                    <p className="text-sm text-slate-400 text-center py-4">No {g.key} keywords</p>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {kws.map(k => (
                        <span key={k} className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium border ${tagStyle[g.key]}`}>
                          {k}
                          <button onClick={() => handleRemove(k)} className="hover:bg-black/10 rounded p-0.5">
                            <FiX size={12} />
                          </button>
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
