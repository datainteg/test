import { useState } from 'react';
import { 
  FiMail, FiBook, FiMessageCircle, FiChevronDown, FiExternalLink, 
  FiSearch, FiLifeBuoy, FiArrowRight 
} from 'react-icons/fi';

const faqs = [
  {
    q: "How does the Lead Capture extension work?",
    a: "The extension runs in the background of your browser. When you visit supported B2B portals, it automatically extracts relevant lead data based on your configured keywords and syncs it directly to this dashboard."
  },
  {
    q: "Why is my extension showing as 'Offline'?",
    a: "This usually means the browser with the extension is closed, or the extension has been paused. Open your browser, ensure the extension is enabled, and check the Heartbeat page to verify the connection."
  },
  {
    q: "How is the Lead Score calculated?",
    a: "Lead scores (0-100) are calculated based on keyword matching, location relevance, and the completeness of the profile data. A score above 60 is 'Hot'."
  },
  {
    q: "Can I export my leads to another CRM?",
    a: "Yes! Go to the Leads page, apply any filters you need, and click 'Export CSV' to download your data for import into tools like Salesforce or HubSpot."
  }
];

export default function HelpSupportPage() {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-10">
      
      {/* ── Premium Hero Section ── */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-600 via-indigo-700 to-navy-800 px-8 py-12 sm:px-12 sm:py-16 shadow-lg text-white">
        <div className="absolute top-0 right-0 -mt-20 -mr-20 w-80 h-80 bg-white opacity-5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-60 h-60 bg-indigo-400 opacity-10 rounded-full blur-2xl pointer-events-none" />
        
        <div className="relative z-10 max-w-2xl">
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4 flex items-center gap-3">
            <FiLifeBuoy className="text-indigo-300" /> How can we help?
          </h1>
          <p className="text-indigo-100 text-lg mb-8 max-w-xl">
            Search our knowledge base, read our guides, or get in touch with our support team to resolve your issues fast.
          </p>
          
          <div className="relative max-w-lg">
            <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search for articles, guides, or FAQs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3.5 bg-white text-slate-800 rounded-xl shadow-sm focus:outline-none focus:ring-4 focus:ring-indigo-500/30 font-medium placeholder:text-slate-400 transition-all"
            />
          </div>
        </div>
      </div>

      {/* ── Quick Contact Cards ── */}
      <div className="grid sm:grid-cols-3 gap-5">
        <a href="mailto:support@mlaics.com" className="bg-white border border-slate-200 rounded-xl p-6 hover:-translate-y-1 hover:shadow-xl hover:border-indigo-300 transition-all duration-300 group">
          <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center mb-5 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
            <FiMail className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-800 mb-2">Email Support</h3>
          <p className="text-sm text-slate-500 mb-4 leading-relaxed">Get in touch with our technical team directly. We typically reply within 24 hours.</p>
          <span className="text-sm font-semibold text-indigo-600 flex items-center gap-1 group-hover:gap-2 transition-all">
            support@mlaics.com <FiArrowRight />
          </span>
        </a>

        <div onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'docs' }))} className="bg-white border border-slate-200 rounded-xl p-6 hover:-translate-y-1 hover:shadow-xl hover:border-emerald-300 transition-all duration-300 group cursor-pointer">
          <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center mb-5 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
            <FiBook className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-800 mb-2">Documentation</h3>
          <p className="text-sm text-slate-500 mb-4 leading-relaxed">Read detailed guides on setting up the extension, keywords, and managing sellers.</p>
          <span className="text-sm font-semibold text-emerald-600 flex items-center gap-1 group-hover:gap-2 transition-all">
            Read the Docs <FiArrowRight />
          </span>
        </div>

        <a href="#" className="bg-white border border-slate-200 rounded-xl p-6 hover:-translate-y-1 hover:shadow-xl hover:border-amber-300 transition-all duration-300 group cursor-pointer">
          <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center mb-5 group-hover:bg-amber-500 group-hover:text-white transition-colors">
            <FiMessageCircle className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-800 mb-2">Community</h3>
          <p className="text-sm text-slate-500 mb-4 leading-relaxed">Join other users on Discord to share strategies and lead capture tips.</p>
          <span className="text-sm font-semibold text-amber-600 flex items-center gap-1 group-hover:gap-2 transition-all">
            Join Discord <FiExternalLink />
          </span>
        </a>
      </div>

      {/* ── FAQ Section ── */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
        <div className="px-8 py-6 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-800">Frequently Asked Questions</h2>
            <p className="text-sm text-slate-500 mt-1">Quick answers to common issues.</p>
          </div>
        </div>
        <div className="divide-y divide-slate-100">
          {faqs.map((faq, idx) => (
            <div key={idx} className="px-8 py-5 hover:bg-slate-50/50 transition-colors">
              <button 
                onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                className="w-full flex items-center justify-between text-left focus:outline-none group"
              >
                <span className={`font-semibold text-[15px] transition-colors ${openFaq === idx ? 'text-indigo-600' : 'text-slate-700 group-hover:text-indigo-600'}`}>
                  {faq.q}
                </span>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${openFaq === idx ? 'bg-indigo-50 text-indigo-600' : 'bg-slate-100 text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-500'}`}>
                  <FiChevronDown className={`w-4 h-4 transition-transform duration-300 ${openFaq === idx ? 'rotate-180' : ''}`} />
                </div>
              </button>
              
              <div className={`overflow-hidden transition-all duration-300 ease-in-out ${openFaq === idx ? 'max-h-40 mt-4 opacity-100' : 'max-h-0 opacity-0'}`}>
                <p className="text-slate-600 leading-relaxed pr-12">
                  {faq.a}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
      
    </div>
  );
}