import { useState, useEffect } from 'react';
import { 
  FiChrome, FiGrid, FiTarget, FiShoppingBag, FiKey, FiActivity, 
  FiChevronRight, FiChevronLeft, FiInfo, FiAlertTriangle 
} from 'react-icons/fi';

type DocSection = 'extension' | 'overview' | 'leads' | 'sellers' | 'keywords' | 'heartbeat';

const menuItems: { id: DocSection; label: string; icon: any }[] = [
  { id: 'extension', label: 'Chrome Extension', icon: FiChrome },
  { id: 'overview',  label: 'Overview Dashboard', icon: FiGrid },
  { id: 'leads',     label: 'Managing Leads', icon: FiTarget },
  { id: 'sellers',   label: 'Sellers (Agents)', icon: FiShoppingBag },
  { id: 'keywords',  label: 'Keywords Config', icon: FiKey },
  { id: 'heartbeat', label: 'Heartbeat Monitor', icon: FiActivity },
];

export default function DocumentationPage() {
  const [activeSection, setActiveSection] = useState<DocSection>('extension');

  // Auto-scroll to top when section changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeSection]);

  const currentIndex = menuItems.findIndex(item => item.id === activeSection);
  const prevItem = currentIndex > 0 ? menuItems[currentIndex - 1] : null;
  const nextItem = currentIndex < menuItems.length - 1 ? menuItems[currentIndex + 1] : null;

  return (
    <div className="max-w-6xl mx-auto flex flex-col lg:flex-row gap-8 pb-12">
      
      {/* ── Left Navigation Sidebar ── */}
      <div className="w-full lg:w-64 flex-shrink-0">
        <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-4 lg:sticky lg:top-20">
          <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-4 px-3">Documentation Guide</h3>
          <nav className="space-y-1.5">
            {menuItems.map(item => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-indigo-50 text-indigo-700 shadow-sm border border-indigo-100'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 border border-transparent'
                  }`}
                >
                  <item.icon className={isActive ? 'text-indigo-600' : 'text-slate-400'} size={18} />
                  {item.label}
                  {isActive && <FiChevronRight className="ml-auto w-4 h-4 opacity-50" />}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* ── Main Content Area ── */}
      <div className="flex-1 bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col min-h-[600px]">
        
        <div className="p-8 sm:p-10 flex-1">
          {activeSection === 'extension' && (
            <div className="space-y-6 animate-fade-in">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-wider mb-2">
                <FiChrome /> Getting Started
              </div>
              <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Activate the Chrome Extension</h1>
              <p className="text-lg text-slate-600 leading-relaxed max-w-3xl">
                The Lead Magnet Chrome Extension is the engine of this platform. It runs quietly in the background of your browser, automatically capturing highly targeted leads.
              </p>
              
              <hr className="border-slate-100 my-8" />

              <h3 className="text-xl font-bold text-slate-800 mb-6">Step-by-Step Installation</h3>
              
              <div className="space-y-6">
                {[
                  { title: "Pin the Extension", desc: 'Click the puzzle piece icon 🧩 in the top right of Chrome and click the "Pin" icon next to Lead Magnet so it is always visible in your toolbar.' },
                  { title: "Get your Seller ID", desc: 'Navigate to the "Sellers" page in this dashboard. Copy your unique Seller ID (this links the browser to your account).' },
                  { title: "Login & Connect", desc: 'Click the Lead Magnet icon in your Chrome toolbar. Paste your Seller ID into the input field and click the Connect button.' },
                  { title: "Start Capturing", desc: 'Turn the main toggle switch to ON. Navigate to your target B2B portal. The extension will now silently extract and sync leads.' }
                ].map((step, i) => (
                  <div key={i} className="flex gap-4 p-5 bg-slate-50 border border-slate-100 rounded-xl">
                    <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                      {i + 1}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-800 text-base">{step.title}</h4>
                      <p className="text-slate-600 mt-1 leading-relaxed">{step.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-8 flex gap-3 p-5 bg-amber-50 border border-amber-200 rounded-xl text-amber-900">
                <FiAlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5 text-amber-600" />
                <div>
                  <h4 className="font-bold text-amber-800">Browser Must Remain Open</h4>
                  <p className="text-sm mt-1 text-amber-700/80">The extension requires your browser to be open to capture leads. If you completely close Chrome, the capturing process will pause until you reopen it.</p>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'overview' && (
            <div className="space-y-6 animate-fade-in">
              <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Overview Dashboard</h1>
              <p className="text-lg text-slate-600 leading-relaxed">
                The Overview page is your high-level command center. It gives you an instant snapshot of your lead generation health.
              </p>
              <div className="grid sm:grid-cols-2 gap-4 mt-8">
                <div className="p-5 bg-slate-50 rounded-xl border border-slate-100">
                  <h4 className="font-bold text-slate-800">Stat Cards</h4>
                  <p className="text-sm text-slate-600 mt-2 leading-relaxed">View total leads, hot leads (score &gt; 80), and your capture rate at a single glance.</p>
                </div>
                <div className="p-5 bg-slate-50 rounded-xl border border-slate-100">
                  <h4 className="font-bold text-slate-800">Lead Trend</h4>
                  <p className="text-sm text-slate-600 mt-2 leading-relaxed">A 7-day trend area chart showing your capture activity. Spikes indicate highly successful targeting.</p>
                </div>
                <div className="p-5 bg-slate-50 rounded-xl border border-slate-100">
                  <h4 className="font-bold text-slate-800">Extension Health</h4>
                  <p className="text-sm text-slate-600 mt-2 leading-relaxed">Instantly verify if your connected extensions are online and actively sending heartbeats.</p>
                </div>
                <div className="p-5 bg-slate-50 rounded-xl border border-slate-100">
                  <h4 className="font-bold text-slate-800">Insights</h4>
                  <p className="text-sm text-slate-600 mt-2 leading-relaxed">AI-generated quick insights showing your top performing cities and peak capture times.</p>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'leads' && (
            <div className="space-y-6 animate-fade-in">
              <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Managing Leads</h1>
              <p className="text-lg text-slate-600 leading-relaxed">
                The Leads page is your primary database. It contains every lead captured by the extension, complete with scoring and status tracking.
              </p>
              
              <div className="mt-8 space-y-4">
                <div className="flex gap-4 p-5 bg-white border border-slate-200 shadow-sm rounded-xl">
                  <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                    <FiTarget size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800">Advanced Filtering</h4>
                    <p className="text-sm text-slate-600 mt-1">Use the top bar to search by category, filter by 'Contacted' status, or set a minimum score to only isolate your hottest prospects.</p>
                  </div>
                </div>

                <div className="flex gap-4 p-5 bg-white border border-slate-200 shadow-sm rounded-xl">
                  <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-lg flex items-center justify-center flex-shrink-0">
                    <FiGrid size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800">CSV Exporting</h4>
                    <p className="text-sm text-slate-600 mt-1">Click the "Export CSV" button to download your currently filtered view. This is perfectly formatted for importing into Salesforce, Apollo, or HubSpot.</p>
                  </div>
                </div>

                <div className="flex gap-4 p-5 bg-white border border-slate-200 shadow-sm rounded-xl">
                  <div className="w-10 h-10 bg-red-50 text-red-600 rounded-lg flex items-center justify-center flex-shrink-0">
                    <FiTarget size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800">Smart Clear</h4>
                    <p className="text-sm text-slate-600 mt-1">Keep your database fast and relevant. Use the Smart Clear tool to automatically delete leads older than 30 days, or wipe out low-scoring leads in bulk.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Fallback for other sections just to keep it clean */}
          {['sellers', 'keywords', 'heartbeat'].includes(activeSection) && (
            <div className="space-y-6 animate-fade-in flex flex-col items-center justify-center h-full text-center py-20">
              <div className="w-20 h-20 bg-indigo-50 text-indigo-500 rounded-full flex items-center justify-center mb-4">
                {activeSection === 'sellers' && <FiShoppingBag size={32} />}
                {activeSection === 'keywords' && <FiKey size={32} />}
                {activeSection === 'heartbeat' && <FiActivity size={32} />}
              </div>
              <h1 className="text-3xl font-extrabold text-slate-900 capitalize">{activeSection}</h1>
              <p className="text-lg text-slate-500 max-w-md">
                Detailed documentation for this module is currently being updated. Please check the overview page or contact support for immediate assistance.
              </p>
            </div>
          )}

        </div>

        {/* ── Bottom Pagination Bar ── */}
        <div className="px-8 py-5 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          {prevItem ? (
            <button 
              onClick={() => setActiveSection(prevItem.id)}
              className="flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-indigo-600 transition-colors"
            >
              <FiChevronLeft size={16} /> Previous: {prevItem.label}
            </button>
          ) : <div />} {/* Empty div to keep Next button on the right */}

          {nextItem && (
            <button 
              onClick={() => setActiveSection(nextItem.id)}
              className="flex items-center gap-2 text-sm font-semibold text-indigo-600 hover:text-indigo-700 transition-colors bg-indigo-50 hover:bg-indigo-100 px-4 py-2 rounded-lg"
            >
              Next: {nextItem.label} <FiChevronRight size={16} />
            </button>
          )}
        </div>

      </div>
    </div>
  );
}