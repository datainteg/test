import { useState } from 'react';
import { FiPlus, FiTrash2, FiToggleLeft, FiToggleRight, FiShoppingBag, FiRefreshCw, FiCopy, FiAlertTriangle, FiEdit2 } from 'react-icons/fi';
import { useSellers } from '@/context/SellerContext';
import { createSeller, updateSeller, deleteSeller } from '@/services/api';
import { useToast } from '@/components/ui/Toast';
import Modal from '@/components/ui/Modal';
import Badge from '@/components/ui/Badge';

const toIST = (iso: string) =>
  new Date(iso).toLocaleDateString('en-IN', {
    timeZone: 'Asia/Kolkata',
    day: '2-digit',
    month: '2-digit',
    year: '2-digit',
  });

export default function SellersPage() {
  const { sellers, refresh } = useSellers();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [editModal, setEditModal] = useState<{ sellerId: string; name: string } | null>(null);
  const [deleteModal, setDeleteModal] = useState<{ sellerId: string; name: string } | null>(null);
  const [name, setName] = useState('');
  const [customId, setCustomId] = useState('');
  const [editName, setEditName] = useState('');

  const handleRefresh = async () => {
    setLoading(true);
    await refresh();
    setLoading(false);
  };

  const handleCreate = async () => {
    if (!name.trim()) { toast('Seller name required', 'error'); return; }
    const d = await createSeller(name, customId || undefined);
    if (d.success) { toast('Seller created', 'success'); setOpen(false); setName(''); setCustomId(''); refresh(); }
    else toast(d.error || 'Failed', 'error');
  };

  const handleToggle = async (sellerId: string, currentActive: boolean) => {
    const d = await updateSeller(sellerId, { active: !currentActive });
    if (d.success) { toast(currentActive ? 'Seller disabled' : 'Seller enabled', 'success'); refresh(); }
    else toast(d.error || 'Failed', 'error');
  };

  const handleEdit = async () => {
    if (!editModal || !editName.trim()) return;
    const d = await updateSeller(editModal.sellerId, { name: editName });
    if (d.success) { toast('Seller updated', 'success'); setEditModal(null); refresh(); }
    else toast(d.error || 'Failed', 'error');
  };

  const handleDelete = async () => {
    if (!deleteModal) return;
    const d = await deleteSeller(deleteModal.sellerId);
    if (d.success) { toast('Seller deleted', 'success'); setDeleteModal(null); refresh(); }
    else toast(d.error || 'Failed', 'error');
  };

  const openEditModal = (sellerId: string, currentName: string) => {
    setEditName(currentName);
    setEditModal({ sellerId, name: currentName });
  };

  return (
    <div className="space-y-4">

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-saffron-400 to-saffron-500 flex items-center justify-center">
            <FiShoppingBag className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-navy-500">Seller Profiles</h1>
            <p className="text-sm text-slate-500">{sellers.length} seller{sellers.length !== 1 ? 's' : ''} registered</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={handleRefresh} 
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-saffron-600 bg-saffron-50 border border-saffron-200 rounded-lg hover:bg-saffron-100"
          >
            <FiRefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Refresh
          </button>
          <button 
            onClick={() => setOpen(true)} 
            className="flex items-center gap-1.5 px-3 py-2 text-sm font-semibold text-white bg-saffron-500 rounded-lg hover:bg-saffron-600"
          >
            <FiPlus size={14} /> Add Seller
          </button>
        </div>
      </div>

      {/* Sellers Table */}
      <div className="bg-white border border-saffron-100 rounded-xl overflow-hidden">

        {/* Mobile Cards */}
        <div className="sm:hidden divide-y divide-saffron-50">
          {sellers.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-sm">No sellers yet. Create one to get started.</div>
          ) : sellers.map(s => {
            const isActive = s.active !== false;
            const cats = s.keywordCategories || { category: [], city: [], value: [] };
            const totalKw = (cats.category?.length || 0) + (cats.city?.length || 0) + (cats.value?.length || 0);
            return (
              <div key={s.sellerId} className="px-4 py-3">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <h3 className="font-semibold text-slate-800">{s.name || 'Unnamed'}</h3>
                    <code className="text-[10px] text-slate-400 font-mono">{s.sellerId}</code>
                  </div>
                  <Badge variant={isActive ? 'success' : 'danger'}>{isActive ? 'Active' : 'Off'}</Badge>
                </div>
                <div className="flex flex-wrap gap-2 mb-3 text-xs">
                  <span className="px-2 py-0.5 bg-slate-100 rounded text-slate-600">{totalKw} keywords</span>
                  {s.extensionId && <span className="px-2 py-0.5 bg-igreen-50 text-igreen-600 rounded">Extension linked</span>}
                </div>
                <div className="flex gap-2">
                  <button onClick={() => handleToggle(s.sellerId, isActive)}
                    className={`flex-1 flex items-center justify-center gap-1 py-2 text-xs font-medium rounded-lg border ${isActive ? 'text-amber-600 border-amber-200 bg-amber-50' : 'text-igreen-600 border-igreen-200 bg-igreen-50'}`}>
                    {isActive ? <FiToggleRight size={14} /> : <FiToggleLeft size={14} />}
                    {isActive ? 'Disable' : 'Enable'}
                  </button>
                  <button onClick={() => openEditModal(s.sellerId, s.name || '')}
                    className="py-2 px-3 text-xs font-medium text-slate-600 bg-slate-50 border border-slate-200 rounded-lg">
                    <FiEdit2 size={13} />
                  </button>
                  <button onClick={() => setDeleteModal({ sellerId: s.sellerId, name: s.name || s.sellerId })}
                    className="py-2 px-3 text-xs font-medium text-red-500 bg-red-50 border border-red-200 rounded-lg">
                    <FiTrash2 size={13} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Desktop Table */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-cream-50 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Seller ID</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Keywords</th>
                <th className="px-4 py-3 hidden lg:table-cell">Extension</th>
                <th className="px-4 py-3 hidden md:table-cell">Created</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {sellers.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-12 text-slate-400">No sellers yet. Create one to get started.</td></tr>
              ) : sellers.map(s => {
                const isActive = s.active !== false;
                const cats = s.keywordCategories || { category: [], city: [], value: [] };
                return (
                  <tr key={s.sellerId} className="border-t border-saffron-50 hover:bg-cream-50">
                    <td className="px-4 py-3">
                      <div className="font-semibold text-slate-800">{s.name || 'Unnamed'}</div>
                    </td>
                    <td className="px-4 py-3">
                      <code className="text-xs text-slate-500 bg-slate-100 px-2 py-0.5 rounded font-mono">{s.sellerId}</code>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant={isActive ? 'success' : 'danger'}>{isActive ? 'Active' : 'Disabled'}</Badge>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {cats.category?.length > 0 && (
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-saffron-50 text-saffron-600 border border-saffron-200">
                            {cats.category.length} cat
                          </span>
                        )}
                        {cats.city?.length > 0 && (
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-igreen-50 text-igreen-600 border border-igreen-200">
                            {cats.city.length} city
                          </span>
                        )}
                        {cats.value?.length > 0 && (
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-50 text-amber-600 border border-amber-200">
                            {cats.value.length} val
                          </span>
                        )}
                        {(s.keywords || []).length === 0 && <span className="text-xs text-slate-300">None</span>}
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell">
                      {s.extensionId ? (
                        <span className="text-[10px] font-mono text-igreen-600 bg-igreen-50 px-2 py-0.5 rounded">
                          {s.extensionId.substring(0, 12)}…
                        </span>
                      ) : (
                        <span className="text-xs text-slate-300">Not linked</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-400 hidden md:table-cell">
                      {s.createdAt ? toIST(s.createdAt) : '—'}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <button 
                          onClick={() => handleToggle(s.sellerId, isActive)}
                          title={isActive ? 'Disable' : 'Enable'}
                          className={`p-1.5 rounded-lg border transition-colors ${isActive ? 'text-amber-600 border-amber-200 bg-amber-50 hover:bg-amber-100' : 'text-igreen-600 border-igreen-200 bg-igreen-50 hover:bg-igreen-100'}`}
                        >
                          {isActive ? <FiToggleRight size={14} /> : <FiToggleLeft size={14} />}
                        </button>
                        <button 
                          onClick={() => openEditModal(s.sellerId, s.name || '')}
                          title="Edit"
                          className="p-1.5 rounded-lg border text-slate-600 border-slate-200 bg-slate-50 hover:bg-slate-100"
                        >
                          <FiEdit2 size={14} />
                        </button>
                        <button 
                          onClick={() => setDeleteModal({ sellerId: s.sellerId, name: s.name || s.sellerId })}
                          title="Delete"
                          className="p-1.5 rounded-lg border text-red-500 border-red-200 bg-red-50 hover:bg-red-100"
                        >
                          <FiTrash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Modal */}
      <Modal open={open} onClose={() => setOpen(false)} title="Create New Seller" footer={
        <button onClick={handleCreate} className="px-4 py-2 bg-saffron-500 text-white text-sm font-semibold rounded-lg hover:bg-saffron-600">
          Create Seller
        </button>
      }>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-600 mb-1">Seller Name *</label>
            <input 
              value={name} 
              onChange={e => setName(e.target.value)} 
              placeholder="e.g. My Store"
              className="w-full px-3 py-2 border border-saffron-200 rounded-lg text-sm focus:outline-none focus:border-saffron-400 focus:ring-2 focus:ring-saffron-100" 
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-600 mb-1">Custom ID (optional)</label>
            <input 
              value={customId} 
              onChange={e => setCustomId(e.target.value)} 
              placeholder="Auto-generated if empty"
              className="w-full px-3 py-2 border border-saffron-200 rounded-lg text-sm focus:outline-none focus:border-saffron-400 focus:ring-2 focus:ring-saffron-100" 
            />
            <p className="text-xs text-slate-400 mt-1">Use lowercase letters, numbers, hyphens only</p>
          </div>
        </div>
      </Modal>

      {/* Edit Modal */}
      <Modal open={!!editModal} onClose={() => setEditModal(null)} title="Edit Seller" footer={
        <button onClick={handleEdit} className="px-4 py-2 bg-saffron-500 text-white text-sm font-semibold rounded-lg hover:bg-saffron-600">
          Save Changes
        </button>
      }>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-600 mb-1">Seller Name</label>
            <input 
              value={editName} 
              onChange={e => setEditName(e.target.value)} 
              placeholder="Seller name"
              className="w-full px-3 py-2 border border-saffron-200 rounded-lg text-sm focus:outline-none focus:border-saffron-400 focus:ring-2 focus:ring-saffron-100" 
            />
          </div>
          <p className="text-xs text-slate-400">Seller ID: <code className="bg-slate-100 px-1 rounded">{editModal?.sellerId}</code></p>
        </div>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal open={!!deleteModal} onClose={() => setDeleteModal(null)} title="Delete Seller" footer={
        <button onClick={handleDelete} className="px-4 py-2 text-sm font-semibold text-white bg-red-500 rounded-lg hover:bg-red-600">
          Delete Permanently
        </button>
      }>
        <div className="text-center py-4">
          <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-red-100 flex items-center justify-center">
            <FiAlertTriangle className="w-7 h-7 text-red-500" />
          </div>
          <p className="text-slate-600 mb-2">Delete <strong>"{deleteModal?.name}"</strong>?</p>
          <p className="text-xs text-red-500">⚠️ This will permanently delete ALL leads and data for this seller.</p>
        </div>
      </Modal>
    </div>
  );
}