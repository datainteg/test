import { useState, useEffect, useCallback } from 'react';
import { FiRefreshCw, FiWifi, FiWifiOff, FiActivity, FiMonitor, FiCheckCircle, FiAlertCircle, FiClock, FiHelpCircle } from 'react-icons/fi';
import type { Heartbeat } from '@/types';
import { getHeartbeats } from '@/services/api';

const toIST = (iso: string) =>
  new Date(iso).toLocaleTimeString('en-IN', {
    timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true,
  });

export default function HeartbeatPage() {
  const [heartbeats, setHeartbeats] = useState<Heartbeat[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try { const d = await getHeartbeats(); if (d.success) setHeartbeats(d.heartbeats || []); } catch {}
    setLoading(false);
  }, []);

  useEffect(() => { load(); const t = setInterval(load, 15000); return () => clearInterval(t); }, [load]);

  const aliveCount = heartbeats.filter(h => h.isAlive).length;
  const deadCount = heartbeats.length - aliveCount;

  return (
    <div className="space-y-6">

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-saffron-400 to-saffron-500 flex items-center justify-center">
            <FiActivity className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-navy-500">Extension Heartbeat</h1>
            <p className="text-sm text-slate-500">Monitor connected Chrome extensions</p>
          </div>
        </div>
        <button onClick={load} disabled={loading} className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-saffron-600 bg-saffron-50 border border-saffron-200 rounded-lg hover:bg-saffron-100">
          <FiRefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Refresh
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white border border-saffron-100 rounded-xl p-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-9 h-9 rounded-lg bg-navy-100 flex items-center justify-center">
              <FiMonitor className="w-4 h-4 text-navy-600" />
            </div>
            <span className="text-xs text-slate-500">Total</span>
          </div>
          <div className="text-2xl font-bold text-navy-600">{heartbeats.length}</div>
        </div>
        <div className="bg-white border border-saffron-100 rounded-xl p-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-9 h-9 rounded-lg bg-igreen-100 flex items-center justify-center">
              <FiCheckCircle className="w-4 h-4 text-igreen-600" />
            </div>
            <span className="text-xs text-slate-500">Alive</span>
          </div>
          <div className="text-2xl font-bold text-igreen-600">{aliveCount}</div>
        </div>
        <div className="bg-white border border-saffron-100 rounded-xl p-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-9 h-9 rounded-lg bg-red-100 flex items-center justify-center">
              <FiAlertCircle className="w-4 h-4 text-red-500" />
            </div>
            <span className="text-xs text-slate-500">Dead</span>
          </div>
          <div className="text-2xl font-bold text-red-500">{deadCount}</div>
        </div>
      </div>

      {/* Heartbeats Table */}
      <div className="bg-white border border-saffron-100 rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-saffron-100 bg-cream-50">
          <h3 className="font-semibold text-slate-800 flex items-center gap-2">
            <FiActivity className="w-4 h-4 text-saffron-500" /> Active Extensions
          </h3>
        </div>

        {/* Mobile Cards */}
        <div className="sm:hidden divide-y divide-saffron-50">
          {loading ? (
            <div className="text-center py-10 text-slate-400 text-sm">Loading...</div>
          ) : heartbeats.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-sm">No heartbeat data</div>
          ) : heartbeats.map(hb => (
            <div key={hb.sellerId} className="px-4 py-3">
              <div className="flex items-center justify-between gap-2">
                <code className="text-xs text-slate-600 font-mono truncate flex-1">{hb.sellerId}</code>
                <div className={`flex items-center gap-1 text-xs font-semibold ${hb.isAlive ? 'text-igreen-600' : 'text-red-500'}`}>
                  {hb.isAlive ? <FiWifi size={13} /> : <FiWifiOff size={13} />}
                  {hb.isAlive ? 'Alive' : 'Dead'}
                </div>
              </div>
              <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-slate-400">
                <span>Phase: <span className="text-slate-600 font-medium">{hb.phase || '—'}</span></span>
                <span>Pings: <span className="text-slate-600 font-medium">{hb.pingCount || 0}</span></span>
                {hb.lastPing && (
                  <span className="flex items-center gap-1">
                    <FiClock size={10} /> {toIST(hb.lastPing)}
                    {hb.secondsSinceLastPing != null && <span className="text-slate-300">({hb.secondsSinceLastPing}s ago)</span>}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Desktop Table */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-cream-50 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <th className="px-4 py-3">Seller</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Phase</th>
                <th className="px-4 py-3">Last Ping (IST)</th>
                <th className="px-4 py-3 hidden md:table-cell">Pings</th>
                <th className="px-4 py-3 hidden lg:table-cell">Tab URL</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="text-center py-10 text-slate-400">Loading...</td></tr>
              ) : heartbeats.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-10 text-slate-400">No heartbeat data</td></tr>
              ) : heartbeats.map(hb => (
                <tr key={hb.sellerId} className="border-t border-saffron-50 hover:bg-cream-50">
                  <td className="px-4 py-3 font-mono text-xs">{hb.sellerId}</td>
                  <td className="px-4 py-3">
                    <span className={`flex items-center gap-1.5 font-semibold text-xs ${hb.isAlive ? 'text-igreen-600' : 'text-red-500'}`}>
                      {hb.isAlive ? <FiWifi size={12} /> : <FiWifiOff size={12} />}
                      {hb.isAlive ? 'Alive' : 'Dead'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-500">{hb.phase || '—'}</td>
                  <td className="px-4 py-3 text-xs text-slate-500">
                    {hb.lastPing ? toIST(hb.lastPing) : '—'}
                    {hb.secondsSinceLastPing != null && <span className="text-slate-300 ml-1">({hb.secondsSinceLastPing}s ago)</span>}
                  </td>
                  <td className="px-4 py-3 text-xs hidden md:table-cell">{hb.pingCount || 0}</td>
                  <td className="px-4 py-3 text-xs text-slate-400 max-w-[200px] truncate hidden lg:table-cell" title={hb.tabUrl}>{hb.tabUrl || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Troubleshooting Info */}
      <div className="bg-navy-50 border border-navy-200 rounded-xl p-4">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-lg bg-navy-100 flex items-center justify-center flex-shrink-0">
            <FiHelpCircle className="w-4 h-4 text-navy-600" />
          </div>
          <div>
            <h3 className="font-semibold text-navy-700 text-sm mb-1">Troubleshooting</h3>
            <ul className="text-xs text-navy-600 space-y-1">
              <li>• Extension pings every 30 seconds. "Dead" = no ping for 90+ seconds.</li>
              <li>• Ensure extension is enabled in Chrome settings.</li>
              <li>• Make sure you're logged in at seller.indiamart.com.</li>
              <li>• Refresh the Buy Leads page to restart the extension.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
