import { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  FiUsers, FiTrendingUp, FiTarget, FiBarChart2, FiRefreshCw, 
  FiMapPin, FiClock, FiActivity, FiZap, FiTag, 
  FiWifi, FiWifiOff, FiChrome, FiAlertTriangle
} from 'react-icons/fi';
import type { Stats, Lead, Seller } from '@/types';
import { getStats, getLeads, getHeartbeats } from '@/services/api';
import { useSellers } from '@/context/SellerContext';
import { ScoreBadge } from '@/components/ui/Badge';
import Badge from '@/components/ui/Badge';

// ── Types ──────────────────────────────────────────────────
type TimeFrame = '1H' | '6H' | '12H' | '1D' | '7D' | '30D';

interface TrendPoint {
  label: string;
  count: number;
  timestamp: number;
}

// ── Stat Cards Config ──────────────────────────────────────
const statCards = [
  { key: 'total',       label: 'Total Leads',   icon: FiUsers,       gradient: 'from-saffron-400 to-saffron-500', text: 'text-saffron-600' },
  { key: 'hot',         label: 'Hot Leads',     icon: FiTrendingUp,  gradient: 'from-red-400 to-red-500',         text: 'text-red-500' },
  { key: 'captureRate', label: 'Capture Rate',  icon: FiTarget,      gradient: 'from-igreen-400 to-igreen-500',   text: 'text-igreen-600', suffix: '%' },
  { key: 'avgScore',    label: 'Avg Score',     icon: FiBarChart2,   gradient: 'from-navy-400 to-navy-500',       text: 'text-navy-600' },
];

const timeFrameOptions: { value: TimeFrame; label: string }[] = [
  { value: '1H', label: '1H' },
  { value: '6H', label: '6H' },
  { value: '12H', label: '12H' },
  { value: '1D', label: '1D' },
  { value: '7D', label: '7D' },
  { value: '30D', label: '30D' },
];

// ── Helper Functions ───────────────────────────────────────
function cleanCity(city?: string): string {
  if (!city) return '—';
  return city
    .replace(/Click here.*$/i, '')
    .replace(/View.*BuyLeads.*$/i, '')
    .replace(/BuyLeads.*$/i, '')
    .replace(/Shortlist.*$/i, '')
    .replace(/[^A-Za-z\s]/g, '')
    .replace(/\s+/g, ' ')
    .trim() || '—';
}

function timeAgo(iso: string): string {
  const now = new Date();
  const date = new Date(iso);
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  
  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays}d ago`;
}

function toIST(iso: string): string {
  return new Date(iso).toLocaleString('en-IN', {
    timeZone: 'Asia/Kolkata',
    dateStyle: 'short',
    timeStyle: 'short',
  });
}

// ── Calculate Trend Data ───────────────────────────────────
function calculateTrendData(leads: Lead[], timeFrame: TimeFrame): TrendPoint[] {
  const now = Date.now();
  const points: TrendPoint[] = [];
  
  // Define time ranges based on timeframe
  let bucketCount: number;
  let bucketSizeMs: number;
  let formatLabel: (date: Date) => string;
  
  switch (timeFrame) {
    case '1H':
      bucketCount = 12; // 5-min buckets
      bucketSizeMs = 5 * 60 * 1000;
      formatLabel = (d) => d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'Asia/Kolkata' });
      break;
    case '6H':
      bucketCount = 12; // 30-min buckets
      bucketSizeMs = 30 * 60 * 1000;
      formatLabel = (d) => d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'Asia/Kolkata' });
      break;
    case '12H':
      bucketCount = 12; // 1-hour buckets
      bucketSizeMs = 60 * 60 * 1000;
      formatLabel = (d) => d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'Asia/Kolkata' });
      break;
    case '1D':
      bucketCount = 24; // 1-hour buckets
      bucketSizeMs = 60 * 60 * 1000;
      formatLabel = (d) => d.toLocaleTimeString('en-IN', { hour: '2-digit', hour12: false, timeZone: 'Asia/Kolkata' }) + 'h';
      break;
    case '7D':
      bucketCount = 7; // 1-day buckets
      bucketSizeMs = 24 * 60 * 60 * 1000;
      formatLabel = (d) => d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', timeZone: 'Asia/Kolkata' });
      break;
    case '30D':
      bucketCount = 30; // 1-day buckets
      bucketSizeMs = 24 * 60 * 60 * 1000;
      formatLabel = (d) => d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', timeZone: 'Asia/Kolkata' });
      break;
    default:
      bucketCount = 24;
      bucketSizeMs = 60 * 60 * 1000;
      formatLabel = (d) => d.toLocaleTimeString('en-IN', { hour: '2-digit', hour12: false, timeZone: 'Asia/Kolkata' }) + 'h';
  }
  
  // Parse all lead timestamps once
  const leadTimes = leads
    .map(lead => {
      if (!lead.capturedAt) return null;
      const t = new Date(lead.capturedAt).getTime();
      return isNaN(t) ? null : t;
    })
    .filter((t): t is number => t !== null);
  
  // Create buckets from oldest to newest
  const totalTimeSpan = bucketCount * bucketSizeMs;
  const startTime = now - totalTimeSpan;
  
  for (let i = 0; i < bucketCount; i++) {
    const bucketStart = startTime + (i * bucketSizeMs);
    const bucketEnd = bucketStart + bucketSizeMs;
    
    const count = leadTimes.filter(t => t >= bucketStart && t < bucketEnd).length;
    
    // Use bucket midpoint for label
    const bucketMid = new Date(bucketStart + bucketSizeMs / 2);
    
    points.push({
      label: formatLabel(bucketMid),
      count,
      timestamp: bucketEnd,
    });
  }
  
  return points;
}

// ── Trend Chart Component (Line/Area Chart) ────────────────
function TrendChart({ data, timeFrame }: { data: TrendPoint[]; timeFrame: TimeFrame }) {
  const maxCount = Math.max(...data.map(d => d.count), 1);
  const totalInPeriod = data.reduce((sum, d) => sum + d.count, 0);
  
  // Chart dimensions
  const chartWidth = 100; // percentage
  const chartHeight = 160;
  const paddingTop = 20;
  const paddingBottom = 5;
  const effectiveHeight = chartHeight - paddingTop - paddingBottom;
  
  // Calculate Y-axis scale (round up to nice number)
  const yAxisMax = Math.ceil(maxCount * 1.1 / 10) * 10 || 10;
  const yAxisSteps = 4;
  const yAxisLabels = Array.from({ length: yAxisSteps + 1 }, (_, i) => 
    Math.round((yAxisMax / yAxisSteps) * (yAxisSteps - i))
  );
  
  // Generate SVG path points
  const points = data.map((d, i) => {
    const x = (i / (data.length - 1)) * 100;
    const y = paddingTop + effectiveHeight - (d.count / yAxisMax) * effectiveHeight;
    return { x, y, count: d.count, label: d.label };
  });
  
  // Create line path
  const linePath = points.map((p, i) => 
    `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`
  ).join(' ');
  
  // Create area path (line + close to bottom)
  const areaPath = `${linePath} L ${points[points.length - 1]?.x || 0} ${chartHeight - paddingBottom} L 0 ${chartHeight - paddingBottom} Z`;
  
  // Show fewer X-axis labels
  const showEveryNth = data.length > 12 ? Math.ceil(data.length / 6) : data.length > 6 ? 2 : 1;
  
  // Find peak point
  const peakIndex = data.findIndex(d => d.count === maxCount);
  const peakPoint = points[peakIndex];

  return (
    <div className="space-y-2">
      {/* Chart with Y-axis */}
      <div className="flex">
        {/* Y-axis labels */}
        <div className="flex flex-col justify-between text-[10px] text-slate-400 pr-2" style={{ height: `${chartHeight}px`, paddingTop: `${paddingTop}px`, paddingBottom: `${paddingBottom}px` }}>
          {yAxisLabels.map((val, i) => (
            <span key={i} className="text-right w-8 leading-none">{val}</span>
          ))}
        </div>
        
        {/* Chart area */}
        <div className="flex-1 relative" style={{ height: `${chartHeight}px` }}>
          {/* Grid lines */}
          <div className="absolute inset-0 flex flex-col justify-between pointer-events-none" style={{ paddingTop: `${paddingTop}px`, paddingBottom: `${paddingBottom}px` }}>
            {yAxisLabels.map((_, i) => (
              <div key={i} className="border-t border-slate-100 w-full" />
            ))}
          </div>
          
          {/* SVG Chart */}
          <svg 
            viewBox={`0 0 100 ${chartHeight}`} 
            preserveAspectRatio="none"
            className="w-full h-full"
          >
            {/* Gradient definition */}
            <defs>
              <linearGradient id="areaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#FF9933" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#FF9933" stopOpacity="0.05" />
              </linearGradient>
              <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#FF9933" />
                <stop offset="100%" stopColor="#e07800" />
              </linearGradient>
            </defs>
            
            {/* Area fill */}
            <path
              d={areaPath}
              fill="url(#areaGradient)"
              className="transition-all duration-500"
            />
            
            {/* Main line */}
            <path
              d={linePath}
              fill="none"
              stroke="url(#lineGradient)"
              strokeWidth="0.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="transition-all duration-500"
            />
            
            {/* Data points */}
            {points.map((p, i) => (
              <g key={i} className="group">
                {/* Hover area */}
                <rect
                  x={p.x - (50 / data.length)}
                  y={0}
                  width={100 / data.length}
                  height={chartHeight}
                  fill="transparent"
                  className="cursor-crosshair"
                />
                {/* Point dot */}
                {p.count > 0 && (
                  <circle
                    cx={p.x}
                    cy={p.y}
                    r="1"
                    fill="#FF9933"
                    className="transition-all duration-200 group-hover:r-[1.5]"
                  />
                )}
              </g>
            ))}
            
            {/* Peak marker */}
            {peakPoint && maxCount > 0 && (
              <>
                <circle
                  cx={peakPoint.x}
                  cy={peakPoint.y}
                  r="1.5"
                  fill="#FF9933"
                  stroke="white"
                  strokeWidth="0.5"
                />
              </>
            )}
          </svg>
          
          {/* Hover tooltips - rendered outside SVG for better styling */}
          <div className="absolute inset-0 flex" style={{ paddingTop: `${paddingTop}px` }}>
            {points.map((p, i) => (
              <div 
                key={i} 
                className="flex-1 group relative"
              >
                {/* Vertical hover line */}
                <div className="absolute inset-y-0 left-1/2 w-px bg-saffron-300 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
                
                {/* Tooltip */}
                <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-1 hidden group-hover:block z-20 pointer-events-none">
                  <div className="bg-slate-800 text-white text-[10px] px-2 py-1 rounded shadow-lg whitespace-nowrap">
                    <div className="font-bold text-saffron-300">{p.count} leads</div>
                    <div className="text-slate-300">{data[i]?.label}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* X-axis labels */}
      <div className="flex pl-10">
        {data.map((d, i) => (
          <div key={i} className="flex-1 text-center">
            {i % showEveryNth === 0 || i === data.length - 1 ? (
              <span className="text-[10px] text-slate-400">{d.label}</span>
            ) : null}
          </div>
        ))}
      </div>
      
      {/* Summary */}
      <div className="flex items-center justify-between pt-3 border-t border-slate-100">
        <div className="flex items-center gap-4">
          <span className="text-xs text-slate-500">
            Total: <span className="font-bold text-slate-700">{totalInPeriod}</span>
          </span>
          <span className="text-xs text-slate-500">
            Peak: <span className="font-bold text-saffron-600">{maxCount}</span>
          </span>
          <span className="text-xs text-slate-500">
            Avg: <span className="font-bold text-slate-700">{Math.round(totalInPeriod / data.length)}</span>
          </span>
        </div>
        <div className="flex items-center gap-1 text-[10px]">
          <span className="w-3 h-[2px] bg-saffron-500 rounded" />
          <span className="text-slate-400">Leads captured</span>
        </div>
      </div>
    </div>
  );
}

// ── Keyword Performance Component ──────────────────────────
function KeywordPerformance({ sellers }: { sellers: Seller[] }) {
  const keywordCounts: Record<string, { count: number; type: 'category' | 'city' | 'value' }> = {};
  
  sellers.forEach(s => {
    const cats = s.keywordCategories || { category: [], city: [], value: [] };
    cats.category?.forEach(k => {
      keywordCounts[k] = { count: (keywordCounts[k]?.count || 0) + 1, type: 'category' };
    });
    cats.city?.forEach(k => {
      keywordCounts[k] = { count: (keywordCounts[k]?.count || 0) + 1, type: 'city' };
    });
    cats.value?.forEach(k => {
      keywordCounts[k] = { count: (keywordCounts[k]?.count || 0) + 1, type: 'value' };
    });
  });

  const topKeywords = Object.entries(keywordCounts)
    .sort((a, b) => b[1].count - a[1].count)
    .slice(0, 8);

  const typeColors = {
    category: 'bg-saffron-100 text-saffron-700 border-saffron-200',
    city: 'bg-igreen-100 text-igreen-700 border-igreen-200',
    value: 'bg-amber-100 text-amber-700 border-amber-200',
  };

  if (topKeywords.length === 0) {
    return (
      <div className="text-center py-6 text-slate-400 text-sm">
        <FiTag className="w-8 h-8 mx-auto mb-2 text-slate-200" />
        No keywords configured
      </div>
    );
  }

  return (
    <div className="flex flex-wrap gap-2">
      {topKeywords.map(([keyword, data]) => (
        <span 
          key={keyword}
          className={`px-3 py-1.5 text-xs font-medium rounded-full border ${typeColors[data.type]}`}
        >
          {keyword}
          <span className="ml-1 opacity-60">×{data.count}</span>
        </span>
      ))}
    </div>
  );
}

// ── Extension Status Component ─────────────────────────────
function ExtensionStatus({ heartbeats, loading }: { heartbeats: any[]; loading: boolean }) {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-6">
        <div className="w-6 h-6 rounded-full border-2 border-saffron-200 border-t-saffron-500 animate-spin" />
      </div>
    );
  }

  const getLastSeen = (h: any): Date | null => {
    const dateStr = h.lastHeartbeat || h.lastPing || h.updatedAt || h.createdAt;
    if (!dateStr) return null;
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? null : d;
  };

  const processedHeartbeats = heartbeats.map(h => {
    const lastSeen = getLastSeen(h);
    const diffMins = lastSeen ? (Date.now() - lastSeen.getTime()) / 60000 : Infinity;
    return { ...h, lastSeen, isAlive: diffMins < 5 };
  });

  const alive = processedHeartbeats.filter(h => h.isAlive);
  const dead = processedHeartbeats.filter(h => !h.isAlive);

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-igreen-500 animate-pulse" />
          <span className="text-sm font-medium text-slate-700">{alive.length} Active</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-red-400" />
          <span className="text-sm font-medium text-slate-700">{dead.length} Inactive</span>
        </div>
      </div>

      {heartbeats.length === 0 ? (
        <div className="text-center py-4 text-slate-400 text-sm">
          <FiChrome className="w-8 h-8 mx-auto mb-2 text-slate-200" />
          No extensions connected
        </div>
      ) : (
        <div className="space-y-2 max-h-40 overflow-y-auto">
          {processedHeartbeats.slice(0, 5).map((h, idx) => (
            <div 
              key={h._id || h.extensionId || idx}
              className={`flex items-center justify-between p-2 rounded-lg border ${
                h.isAlive ? 'bg-igreen-50 border-igreen-100' : 'bg-red-50 border-red-100'
              }`}
            >
              <div className="flex items-center gap-2">
                {h.isAlive ? (
                  <FiWifi className="w-4 h-4 text-igreen-500" />
                ) : (
                  <FiWifiOff className="w-4 h-4 text-red-400" />
                )}
                <div>
                  <p className="text-xs font-medium text-slate-700">
                    {h.sellerName || h.sellerId || 'Unknown'}
                  </p>
                  {h.extensionId && (
                    <p className="text-[10px] text-slate-400 font-mono">
                      {h.extensionId.substring(0, 16)}...
                    </p>
                  )}
                </div>
              </div>
              <span className={`text-[10px] ${h.isAlive ? 'text-igreen-600' : 'text-red-500'}`}>
                {h.lastSeen ? timeAgo(h.lastSeen.toISOString()) : 'Unknown'}
              </span>
            </div>
          ))}
        </div>
      )}

      {dead.length > 0 && (
        <div className="flex items-start gap-2 p-2 bg-amber-50 border border-amber-200 rounded-lg">
          <FiAlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700">
            {dead.length} extension{dead.length > 1 ? 's' : ''} stopped sending heartbeats.
          </p>
        </div>
      )}
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────
export default function OverviewPage() {
  const { currentSellerId, sellers } = useSellers();
  const [stats, setStats] = useState<Stats & { avgScore?: number; captureRate?: number }>({ 
    total: 0, clicked: 0, today: 0, hot: 0, warm: 0, cool: 0, avgScore: 0, captureRate: 0 
  });
  const [allLeads, setAllLeads] = useState<Lead[]>([]);
  const [heartbeats, setHeartbeats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [timeFrame, setTimeFrame] = useState<TimeFrame>('1D');

  // Calculate trend data based on timeframe
  const trendData = useMemo(() => {
    return calculateTrendData(allLeads, timeFrame);
  }, [allLeads, timeFrame]);

  // Get recent 10 leads for table
  const recentLeads = useMemo(() => {
    return [...allLeads]
      .sort((a, b) => new Date(b.capturedAt).getTime() - new Date(a.capturedAt).getTime())
      .slice(0, 10);
  }, [allLeads]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params: Record<string, string> = { limit: '500', sort: 'capturedAt', order: 'desc' };
      if (currentSellerId) params.sellerId = currentSellerId;
      
      // Fetch more leads for better trend data (last 30 days worth)
      const [statsRes, leadsRes, heartbeatsRes] = await Promise.all([
        getStats(currentSellerId || undefined),
        getLeads(params),
        getHeartbeats(currentSellerId || undefined).catch(() => ({ success: true, heartbeats: [] })),
      ]);
      
      if (statsRes.success) {
        const leads = leadsRes.success ? leadsRes.data || [] : [];
        const avgScore = leads.length > 0 
          ? Math.round(leads.reduce((sum: number, l: Lead) => sum + (l.score || 0), 0) / leads.length)
          : 0;
        const captureRate = statsRes.stats.total > 0 
          ? Math.round((statsRes.stats.clicked / statsRes.stats.total) * 100)
          : 0;
        
        setStats({ ...statsRes.stats, avgScore, captureRate });
      }
      
      if (leadsRes.success) {
        setAllLeads(leadsRes.data || []);
      }

      if (heartbeatsRes.success) {
        setHeartbeats(heartbeatsRes.heartbeats || []);
      }
      
      setLastUpdated(new Date());
    } catch (e) {
      console.error('Failed to load overview:', e);
    }
    setLoading(false);
  }, [currentSellerId]);

  useEffect(() => { 
    load(); 
    const t = setInterval(load, 30000); 
    return () => clearInterval(t); 
  }, [load]);

  // Live mode: refresh every 10 seconds when 1H is selected
  useEffect(() => {
    if (timeFrame === '1H') {
      const liveInterval = setInterval(load, 10000);
      return () => clearInterval(liveInterval);
    }
  }, [timeFrame, load]);

  return (
    <div className="space-y-6">

      {/* ── Stat Cards ───────────────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map(c => {
          const Icon = c.icon;
          const val = stats[c.key as keyof typeof stats] ?? 0;
          return (
            <div 
              key={c.key} 
              className="bg-white border border-saffron-100 rounded-xl p-4 hover:shadow-md hover:scale-[1.02] transition-all"
            >
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${c.gradient} flex items-center justify-center text-white shadow-sm`}>
                  <Icon className="w-5 h-5" />
                </div>
                {loading && (
                  <div className="w-4 h-4 rounded-full border-2 border-saffron-200 border-t-saffron-500 animate-spin" />
                )}
              </div>
              <div className={`text-2xl font-bold font-mono ${c.text}`}>
                {loading ? '—' : `${val.toLocaleString()}${c.suffix || ''}`}
              </div>
              <div className="text-xs text-slate-500 mt-1">{c.label}</div>
            </div>
          );
        })}
      </div>

      {/* ── Lead Trend Chart ─────────────────────────────── */}
      <div className="bg-white border border-saffron-100 rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-saffron-100 flex items-center justify-between bg-cream-50">
          <div className="flex items-center gap-2">
            <FiActivity className="w-5 h-5 text-saffron-500" />
            <h3 className="font-semibold text-slate-800">Lead Trend</h3>
            {timeFrame === '1H' && (
              <span className="flex items-center gap-1 text-xs text-igreen-600 bg-igreen-50 px-2 py-0.5 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-igreen-500 animate-pulse" />
                LIVE
              </span>
            )}
          </div>
          
          {/* Timeframe Selector */}
          <div className="flex items-center gap-1 bg-slate-100 rounded-lg p-0.5">
            {timeFrameOptions.map(opt => (
              <button
                key={opt.value}
                onClick={() => setTimeFrame(opt.value)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                  timeFrame === opt.value
                    ? 'bg-saffron-500 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-800'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
        
        <div className="p-4">
          {loading && allLeads.length === 0 ? (
            <div className="h-40 flex items-center justify-center">
              <div className="w-6 h-6 rounded-full border-2 border-saffron-200 border-t-saffron-500 animate-spin" />
            </div>
          ) : (
            <TrendChart data={trendData} timeFrame={timeFrame} />
          )}
        </div>
      </div>

      {/* ── Two Column Section ───────────────────────────── */}
      <div className="grid md:grid-cols-2 gap-6">
        
        {/* Keyword Performance */}
        <div className="bg-white border border-saffron-100 rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-saffron-100 bg-cream-50">
            <div className="flex items-center gap-2">
              <FiTag className="w-5 h-5 text-saffron-500" />
              <h3 className="font-semibold text-slate-800">Keyword Performance</h3>
            </div>
          </div>
          <div className="p-4">
            <KeywordPerformance sellers={currentSellerId ? sellers.filter(s => s.sellerId === currentSellerId) : sellers} />
          </div>
        </div>

        {/* Extension Status */}
        <div className="bg-white border border-saffron-100 rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-saffron-100 bg-cream-50">
            <div className="flex items-center gap-2">
              <FiChrome className="w-5 h-5 text-saffron-500" />
              <h3 className="font-semibold text-slate-800">Extension Status</h3>
            </div>
          </div>
          <div className="p-4">
            <ExtensionStatus heartbeats={heartbeats} loading={loading} />
          </div>
        </div>
      </div>

      {/* ── Recent Leads ─────────────────────────────────── */}
      <div className="bg-white border border-saffron-100 rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-saffron-100 flex items-center justify-between bg-cream-50">
          <div className="flex items-center gap-2">
            <FiTarget className="w-5 h-5 text-saffron-500" />
            <h3 className="font-semibold text-slate-800">Recent Leads</h3>
            <span className="text-xs text-slate-400 bg-slate-100 px-2 py-0.5 rounded">Last 10</span>
          </div>
          <div className="flex items-center gap-3">
            {lastUpdated && (
              <span className="text-xs text-slate-400 hidden sm:inline">
                Updated {timeAgo(lastUpdated.toISOString())}
              </span>
            )}
            <button 
              onClick={load}
              disabled={loading}
              className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-saffron-600 bg-saffron-50 border border-saffron-200 rounded-lg hover:bg-saffron-100 disabled:opacity-50 transition-colors"
            >
              <FiRefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Refresh</span>
            </button>
          </div>
        </div>

        {/* Mobile Cards */}
        <div className="sm:hidden divide-y divide-saffron-50">
          {loading && recentLeads.length === 0 ? (
            <div className="text-center py-10">
              <div className="w-8 h-8 mx-auto mb-3 rounded-full border-2 border-saffron-200 border-t-saffron-500 animate-spin" />
              <p className="text-slate-400 text-sm">Loading leads...</p>
            </div>
          ) : recentLeads.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-sm">
              <FiTarget className="w-10 h-10 mx-auto mb-2 text-slate-200" />
              No leads yet
            </div>
          ) : recentLeads.map(l => (
            <div key={l._id} className="px-4 py-3 hover:bg-cream-50 transition-colors">
              <div className="flex items-start justify-between gap-2">
                <div className="font-medium text-sm text-slate-800 truncate flex-1">{l.title || '—'}</div>
                <ScoreBadge score={l.score} />
              </div>
              <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-slate-500">
                <span className="flex items-center gap-1">
                  <FiMapPin className="w-3 h-3" /> {cleanCity(l.location?.city)}
                </span>
                {l.status?.clicked
                  ? <Badge variant="success">Contacted</Badge>
                  : <Badge variant="muted">New</Badge>}
                <span className="flex items-center gap-1 text-slate-400 ml-auto">
                  <FiClock className="w-3 h-3" /> {l.capturedAt ? timeAgo(l.capturedAt) : '—'}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Desktop Table */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-cream-50 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <th className="px-4 py-3">Title</th>
                <th className="px-4 py-3">City</th>
                <th className="px-4 py-3">Score</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Captured</th>
              </tr>
            </thead>
            <tbody>
              {loading && recentLeads.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center py-10">
                    <div className="w-6 h-6 mx-auto mb-2 rounded-full border-2 border-saffron-200 border-t-saffron-500 animate-spin" />
                    <p className="text-slate-400 text-sm">Loading...</p>
                  </td>
                </tr>
              ) : recentLeads.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center py-10 text-slate-400">
                    <FiTarget className="w-8 h-8 mx-auto mb-2 text-slate-200" />
                    No leads captured yet
                  </td>
                </tr>
              ) : recentLeads.map(l => (
                <tr key={l._id} className="border-t border-saffron-50 hover:bg-cream-50 transition-colors">
                  <td className="px-4 py-3 max-w-[200px]">
                    <div className="truncate font-medium text-slate-800" title={l.title}>{l.title || '—'}</div>
                    {l.detectedCategory && (
                      <div className="text-[10px] text-slate-400 truncate">{l.detectedCategory}</div>
                    )}
                  </td>
                  <td className="px-4 py-3 text-slate-500">{cleanCity(l.location?.city)}</td>
                  <td className="px-4 py-3"><ScoreBadge score={l.score} /></td>
                  <td className="px-4 py-3">
                    {l.status?.clicked ? <Badge variant="success">Contacted</Badge> : <Badge variant="muted">New</Badge>}
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-slate-600 text-xs">{l.capturedAt ? timeAgo(l.capturedAt) : '—'}</div>
                    <div className="text-slate-400 text-[10px] font-mono">{l.capturedAt ? toIST(l.capturedAt) : ''}</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer Link */}
        {recentLeads.length > 0 && (
          <div className="px-4 py-2 border-t border-saffron-100 bg-cream-50 text-center">
            <button 
              onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'leads' }))}
              className="text-sm text-saffron-600 hover:text-saffron-700 font-medium inline-flex items-center gap-1"
            >
              View all leads →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}