import type { ReactNode } from 'react';

interface Props {
  variant: 'hot' | 'warm' | 'cool' | 'success' | 'muted' | 'accent' | 'danger';
  children: ReactNode;
}

const styles: Record<string, string> = {
  hot:     'bg-red-50 text-red-600 border border-red-200',
  warm:    'bg-amber-50 text-amber-600 border border-amber-200',
  cool:    'bg-cyan-50 text-cyan-600 border border-cyan-200',
  success: 'bg-igreen-50 text-igreen-600 border border-igreen-200',
  muted:   'bg-slate-100 text-slate-500 border border-slate-200',
  accent:  'bg-saffron-50 text-saffron-600 border border-saffron-200',
  danger:  'bg-red-50 text-red-600 border border-red-200',
};

export default function Badge({ variant, children }: Props) {
  return (
    <span className={`badge ${styles[variant]}`}>
      {children}
    </span>
  );
}

export function ScoreBadge({ score }: { score: number }) {
  const v = score >= 60 ? 'hot' : score >= 25 ? 'warm' : 'cool';
  const bg = score >= 60 ? 'bg-gradient-to-r from-red-500 to-orange-500' 
           : score >= 25 ? 'bg-gradient-to-r from-amber-400 to-amber-500' 
           : 'bg-gradient-to-r from-cyan-400 to-cyan-500';
  return (
    <span className={`inline-flex items-center justify-center min-w-[32px] px-2 py-0.5 rounded-full text-xs font-bold text-white ${bg}`}>
      {score}
    </span>
  );
}

export function RoleBadge({ role }: { role: string }) {
  const isAdmin = role === 'admin';
  return (
    <span className={`badge ${isAdmin ? 'bg-navy-50 text-navy-600 border border-navy-200' : 'bg-slate-100 text-slate-500 border border-slate-200'}`}>
      {role}
    </span>
  );
}

export function StatusBadge({ active }: { active: boolean }) {
  return (
    <span className={`badge ${active ? 'bg-igreen-50 text-igreen-600 border border-igreen-200' : 'bg-red-50 text-red-500 border border-red-200'}`}>
      {active ? 'Active' : 'Inactive'}
    </span>
  );
}
