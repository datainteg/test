export default function StatusDot({ online }: { online: boolean }) {
  return (
    <span className="relative flex-shrink-0">
      <span
        className={`inline-block w-2.5 h-2.5 rounded-full ${
          online 
            ? 'bg-igreen-500 shadow-[0_0_0_3px_rgba(19,136,8,0.15)]' 
            : 'bg-red-500 shadow-[0_0_0_3px_rgba(239,68,68,0.15)]'
        }`}
      />
      {online && (
        <span className="absolute inset-0 w-2.5 h-2.5 rounded-full bg-igreen-400 animate-ping opacity-75" />
      )}
    </span>
  );
}
