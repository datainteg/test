import { useState, useCallback, useRef, createContext, useContext, ReactNode } from 'react';
import { FiCheckCircle, FiAlertCircle, FiInfo, FiX } from 'react-icons/fi';

type ToastType = 'success' | 'error' | 'info';

interface ToastCtx {
  toast: (msg: string, type?: ToastType) => void;
}

const ToastContext = createContext<ToastCtx>({ toast: () => {} });

const icons = { success: FiCheckCircle, error: FiAlertCircle, info: FiInfo };
const colors = {
  success: 'bg-igreen-50 text-igreen-700 border-igreen-200',
  error: 'bg-red-50 text-red-600 border-red-200',
  info: 'bg-saffron-50 text-saffron-700 border-saffron-200',
};

const iconColors = {
  success: 'text-igreen-500',
  error: 'text-red-500',
  info: 'text-saffron-500',
};

export function ToastProvider({ children }: { children: ReactNode }) {
  const [msg, setMsg] = useState('');
  const [type, setType] = useState<ToastType>('info');
  const [visible, setVisible] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const toast = useCallback((m: string, t: ToastType = 'info') => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setMsg(m); setType(t); setVisible(true);
    timerRef.current = setTimeout(() => setVisible(false), 3500);
  }, []);

  const dismiss = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setVisible(false);
  };

  const Icon = icons[type];

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      {visible && (
        <div className={`fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:bottom-6 sm:max-w-sm z-[999] flex items-center gap-3 px-4 py-3 rounded-xl border shadow-lg text-sm font-medium transition-all animate-in slide-in-from-bottom-4 duration-300 ${colors[type]}`}>
          <Icon className={`w-5 h-5 flex-shrink-0 ${iconColors[type]}`} />
          <span className="flex-1">{msg}</span>
          <button onClick={dismiss} className="p-1 hover:bg-black/5 rounded-lg transition-colors">
            <FiX className="w-4 h-4" />
          </button>
        </div>
      )}
    </ToastContext.Provider>
  );
}

export const useToast = () => useContext(ToastContext);
