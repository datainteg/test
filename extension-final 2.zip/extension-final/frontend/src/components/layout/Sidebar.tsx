import React, { useState, type ReactNode } from 'react';
import { useAuth } from '@/context/AuthContext';
import {
  FiGrid, FiTarget, FiShoppingBag, FiKey, FiUsers, FiActivity,
  FiLogOut, FiMenu, FiX, FiChevronRight, FiZap, FiHelpCircle, FiBook
} from 'react-icons/fi';

interface NavItem {
  key: string;
  label: string;
  icon: React.ComponentType<{ className?: string; size?: number }>;
  admin?: boolean;
}

const navItems: NavItem[] = [
  { key: 'overview',  label: 'Overview',  icon: FiGrid },
  { key: 'leads',     label: 'Leads',     icon: FiTarget },
  { key: 'sellers',   label: 'Sellers',   icon: FiShoppingBag },
  { key: 'keywords',  label: 'Keywords',  icon: FiKey },
  { key: 'users',     label: 'Users',     icon: FiUsers, admin: true },
  { key: 'heartbeat', label: 'Heartbeat', icon: FiActivity },
  { key: 'docs',      label: 'Documentation', icon: FiBook },
  { key: 'help',      label: 'Help & Support', icon: FiHelpCircle },
];

interface Props {
  activePage: string;
  onNavigate: (page: string) => void;
  children: ReactNode;
  topbar: ReactNode;
}

export default function Sidebar({ activePage, onNavigate, children, topbar }: Props) {
  const { user, logout, isAdmin } = useAuth();
  const [open, setOpen] = useState(false);
  const visibleNav = navItems.filter(n => !n.admin || isAdmin);

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-cream-50 via-white to-igreen-50/30">
      <div className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-saffron-500 via-white to-igreen-500 z-[60]" />

      {open && (
        <div
          className="fixed inset-0 bg-navy-500/20 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      <aside className={`
        fixed top-0 left-0 bottom-0 w-60 bg-white border-r border-saffron-100
        flex flex-col z-50 transition-transform duration-300 pt-1
        lg:translate-x-0
        ${open ? 'translate-x-0 shadow-2xl' : '-translate-x-full'}
      `}>
        <div className="px-4 py-4 flex items-center justify-between border-b border-saffron-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-saffron-400 to-saffron-600 rounded-xl flex items-center justify-center shadow-glow-saffron">
              <FiZap className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-bold text-navy-500 text-sm">Lead Magnet</div>
              <div className="text-[10px] text-slate-400 font-mono">mlaics.com</div>
            </div>
          </div>
          <button className="lg:hidden text-slate-400 hover:text-slate-600 p-1" onClick={() => setOpen(false)}>
            <FiX size={18} />
          </button>
        </div>

        <nav className="flex-1 py-3 px-2 overflow-y-auto space-y-1">
          {visibleNav.map(n => (
            <button
              key={n.key}
              onClick={() => { onNavigate(n.key); setOpen(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                activePage === n.key
                  ? 'bg-gradient-to-r from-saffron-50 to-saffron-100 text-saffron-700 font-semibold border border-saffron-200'
                  : 'text-slate-600 hover:bg-cream-100 hover:text-slate-800'
              }`}
            >
              <n.icon className={`w-[18px] h-[18px] flex-shrink-0 ${
                activePage === n.key ? 'text-saffron-600' : 'text-slate-400'
              }`} />
              <span>{n.label}</span>
              {activePage === n.key && (
                <FiChevronRight className="ml-auto w-4 h-4 text-saffron-400" />
              )}
            </button>
          ))}
        </nav>

        <div className="px-3 py-3 border-t border-saffron-100 bg-cream-50/50">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-9 h-9 bg-gradient-to-br from-navy-400 to-navy-600 text-white font-bold text-sm rounded-lg flex items-center justify-center">
              {(user?.name || 'U')[0].toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-slate-800 truncate">{user?.name || user?.email}</div>
              <div className={`text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded inline-block ${
                user?.role === 'admin' ? 'bg-igreen-100 text-igreen-700' : 'bg-saffron-100 text-saffron-700'
              }`}>{user?.role}</div>
            </div>
          </div>
          <button 
            onClick={logout} 
            className="w-full flex items-center justify-center gap-2 py-2 text-xs font-medium text-red-500 bg-red-50 rounded-lg hover:bg-red-100 transition-colors"
          >
            <FiLogOut size={14} />
            Logout
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col lg:ml-60 min-w-0 pt-1">
        <header className="h-14 bg-white/95 backdrop-blur-sm border-b border-saffron-100 flex items-center gap-3 px-4 sticky top-1 z-30">
          <button className="lg:hidden text-saffron-600 hover:text-saffron-700 p-1.5 bg-saffron-50 rounded-lg border border-saffron-200" onClick={() => setOpen(true)}>
            <FiMenu size={20} />
          </button>
          {topbar}
        </header>
        <main className="flex-1 p-4 lg:p-6 pb-24 lg:pb-6">
          {children}
        </main>
      </div>

      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-saffron-100 z-30 flex safe-area-pb">
        {visibleNav.slice(0, 5).map(n => (
          <button
            key={n.key}
            onClick={() => onNavigate(n.key)}
            className={`flex-1 flex flex-col items-center justify-center py-2.5 gap-0.5 text-[10px] font-semibold transition-colors ${
              activePage === n.key
                ? 'text-saffron-600 bg-saffron-50'
                : 'text-slate-400'
            }`}
          >
            <n.icon size={18} />
            <span>{n.label}</span>
          </button>
        ))}
        {visibleNav.length > 5 && (
          <button
            onClick={() => setOpen(true)}
            className="flex-1 flex flex-col items-center justify-center py-2.5 gap-0.5 text-[10px] font-semibold text-slate-400"
          >
            <FiMenu size={18} />
            <span>More</span>
          </button>
        )}
      </nav>
    </div>
  );
}