import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useSellers } from '@/context/SellerContext';
import { checkHealth } from '@/services/api';
import LoginPage from '@/components/auth/LoginPage';
import Sidebar from '@/components/layout/Sidebar';
import OverviewPage from '@/components/pages/OverviewPage';
import LeadsPage from '@/components/pages/LeadsPage';
import SellersPage from '@/components/pages/SellersPage';
import KeywordsPage from '@/components/pages/KeywordsPage';
import UsersPage from '@/components/pages/UsersPage';
import HeartbeatPage from '@/components/pages/HeartbeatPage';
import HelpSupportPage from '@/components/pages/HelpSupportPage';
import DocumentationPage from '@/components/pages/DocumentationPage';
import StatusDot from '@/components/ui/StatusDot';
import { FiClock, FiChevronDown } from 'react-icons/fi';

const pageTitles: Record<string, string> = {
  overview: 'Overview', leads: 'Leads', sellers: 'Sellers',
  keywords: 'Keywords', users: 'Users', heartbeat: 'Heartbeat',
  help: 'Help & Support', docs: 'Documentation',
};

function ISTClock() {
  const [time, setTime] = useState('');
  useEffect(() => {
    const tick = () => {
      const now = new Date().toLocaleTimeString('en-IN', {
        timeZone: 'Asia/Kolkata',
        hour: '2-digit', minute: '2-digit', second: '2-digit',
        hour12: true,
      });
      setTime(now);
    };
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="hidden sm:flex items-center gap-2 text-xs font-mono bg-cream-100 border border-saffron-200 px-3 py-1.5 rounded-lg">
      <FiClock className="w-3.5 h-3.5 text-saffron-500" />
      <span className="text-slate-700 font-semibold">{time}</span>
      <span className="text-saffron-500 font-sans font-bold text-[10px]">IST</span>
    </div>
  );
}

export default function App() {
  const { user, loading } = useAuth();
  const { sellers, currentSellerId, setCurrentSellerId } = useSellers();
  
  const [page, setPage] = useState(() => {
    const saved = localStorage.getItem('lm_current_page');
    return saved || 'overview';
  });
  const [online, setOnline] = useState(false);

  useEffect(() => {
    localStorage.setItem('lm_current_page', page);
  }, [page]);

  useEffect(() => {
    const handler = (e: CustomEvent) => setPage(e.detail);
    window.addEventListener('navigate', handler as EventListener);
    return () => window.removeEventListener('navigate', handler as EventListener);
  }, []);

  useEffect(() => {
    checkHealth().then(setOnline);
    const t = setInterval(() => checkHealth().then(setOnline), 30000);
    return () => clearInterval(t);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-cream-50 to-white">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-saffron-400 to-saffron-600 flex items-center justify-center shadow-glow-saffron animate-pulse">
            <span className="text-2xl">🎯</span>
          </div>
          <p className="text-slate-500 text-sm font-medium">Loading Lead Magnet...</p>
        </div>
      </div>
    );
  }

  if (!user) return <LoginPage />;

  const activeSellers = sellers.filter(s => s.active !== false);

  const topbar = (
    <div className="flex items-center w-full gap-4">
      <div className="relative flex-shrink-0">
        <select
          value={currentSellerId || ''}
          onChange={e => setCurrentSellerId(e.target.value || null)}
          className="text-sm pl-3 pr-8 py-2 border border-saffron-200 rounded-lg bg-white w-40 sm:w-48 focus:outline-none focus:border-saffron-400 focus:ring-2 focus:ring-saffron-100 font-medium text-slate-700 appearance-none cursor-pointer"
        >
          <option value="">All Sellers ({activeSellers.length})</option>
          {activeSellers.map(s => <option key={s.sellerId} value={s.sellerId}>{s.name || s.sellerId}</option>)}
        </select>
        <FiChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
      </div>

      <h2 className="flex-1 text-center text-base sm:text-lg font-bold text-navy-500 truncate">
        {pageTitles[page] || 'Dashboard'}
      </h2>

      <div className="flex items-center gap-4 flex-shrink-0">
        <ISTClock />
        <div className="flex items-center gap-2 text-xs">
          <StatusDot online={online} />
          <span className={`font-medium ${online ? 'text-igreen-500' : 'text-red-500'}`}>
            {online ? 'Online' : 'Offline'}
          </span>
        </div>
      </div>
    </div>
  );

  const renderPage = () => {
    switch (page) {
      case 'overview':  return <OverviewPage />;
      case 'leads':     return <LeadsPage />;
      case 'sellers':   return <SellersPage />;
      case 'keywords':  return <KeywordsPage />;
      case 'users':     return <UsersPage />;
      case 'heartbeat': return <HeartbeatPage />;
      case 'help':      return <HelpSupportPage />;
      case 'docs':      return <DocumentationPage />;
      default:          return <OverviewPage />;
    }
  };

  return (
    <Sidebar activePage={page} onNavigate={setPage} topbar={topbar}>
      {renderPage()}
    </Sidebar>
  );
}