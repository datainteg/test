/**
 * Express App — component-based route mounting
 * @version 10.0.0
 */
'use strict';

const express = require('express');
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');
const mongoose = require('mongoose');

const { corsOptions } = require('./config/cors');

const app = express();

// ── SECURITY HEADERS ─────────────────────────────
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
}));

// ── CORS ──────────────────────────────────────────
app.use(cors(corsOptions));
app.options('*', cors(corsOptions));

// ── BODY PARSING ──────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ── ROUTES (component-based) ──────────────────────
app.use('/api/auth', require('./routes/auth'));
app.use('/api/sellers', require('./routes/sellers'));
app.use('/api/leads', require('./routes/leads'));
app.use('/api/heartbeat', require('./routes/heartbeat'));
app.use('/api', require('./routes/stats'));

// ── HEALTH (public — no auth) ─────────────────────
app.get('/api/health', async (req, res) => {
  const states = { 0: 'disconnected', 1: 'connected', 2: 'connecting', 3: 'disconnecting' };
  res.json({
    success: true,
    service: 'Extension Dashboard API',
    domain: process.env.API_DOMAIN || 'localhost',
    mongodb: states[mongoose.connection.readyState] || 'unknown',
    version: '10.0.0',
    timestamp: new Date().toISOString()
  });
});

// ── STATIC + DASHBOARD ────────────────────────────
app.use(express.static(path.join(__dirname, '..', 'public')));

// ── 404 for unmatched API routes ──────────────────
app.all('/api/*', (req, res) => res.status(404).json({ error: 'API route not found' }));

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

module.exports = app;
