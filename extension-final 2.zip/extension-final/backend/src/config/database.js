/**
 * MongoDB connection config
 */
const mongoose = require('mongoose');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/leadmagnet';

async function connectDB() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ MongoDB connected:', MONGO_URI);
  } catch (err) {
    console.error('❌ MongoDB failed:', err.message);
    process.exit(1);
  }

  mongoose.connection.on('disconnected', () => console.log('⚠️  MongoDB disconnected'));
  mongoose.connection.on('reconnected', () => console.log('✅ MongoDB reconnected'));
}

module.exports = { connectDB, MONGO_URI };
