/**
 * Admin seed — creates default admin on first boot
 */
const User = require('../models/user');

async function seedAdmin() {
  try {
    const email = (process.env.ADMIN_EMAIL || 'admin@example.com').toLowerCase();
    const password = process.env.ADMIN_PASSWORD;

    if (!password || password.includes('CHANGE_ME') || password === 'admin123!' || password === 'admin123') {
      if (process.env.NODE_ENV === 'production') {
        console.error('❌ ADMIN_PASSWORD not set or is default. Set a strong password in .env for production.');
        return;
      }
      console.warn('⚠️  Using default admin password — change before deploying to production!');
    }

    const existing = await User.findOne({ email });
    if (!existing) {
      await User.create({
        email,
        password: password || 'admin123!',
        name: process.env.ADMIN_NAME || 'Admin',
        role: 'admin',
        sellerId: ''
      });
      console.log(`✅ Admin seeded: ${email}`);
    } else {
      console.log(`✅ Admin exists: ${email}`);
    }
  } catch (e) {
    console.error('⚠️ Admin seed error:', e.message);
  }
}

module.exports = { seedAdmin };
