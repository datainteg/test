/**
 * CORS configuration
 */
const BASE_ORIGINS = [
  'http://localhost:5000',
  'http://127.0.0.1:5000',
  'http://localhost:5173',
  'http://127.0.0.1:5173',
  // Production domains
  'https://extension.mlaics.com',
  'http://extension.mlaics.com',
  'https://mlaics.com',
  'http://mlaics.com',
  'https://leadmagnet.mlaics.com',
  'http://leadmagnet.mlaics.com',
];

if (process.env.API_DOMAIN) {
  BASE_ORIGINS.push(
    `https://${process.env.API_DOMAIN}`,
    `http://${process.env.API_DOMAIN}`
  );
}

const ENV_ORIGINS = (process.env.ALLOWED_ORIGINS || '')
  .split(',').map(o => o.trim()).filter(Boolean);

const ALLOWED_ORIGINS = [...new Set([...BASE_ORIGINS, ...ENV_ORIGINS])];

const corsOptions = {
  origin: function (origin, cb) {
    // Allow requests with no origin (mobile apps, curl, etc.)
    if (!origin) return cb(null, true);
    // Allow Chrome extensions
    if (origin.startsWith('chrome-extension://')) return cb(null, true);
    // Allow IndiaMART
    if (origin.endsWith('.indiamart.com') || origin === 'https://indiamart.com' || origin === 'http://indiamart.com') return cb(null, true);
    // Check whitelist
    if (ALLOWED_ORIGINS.includes(origin)) return cb(null, true);
    cb(new Error('CORS blocked: ' + origin));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
};

module.exports = { corsOptions, ALLOWED_ORIGINS };
