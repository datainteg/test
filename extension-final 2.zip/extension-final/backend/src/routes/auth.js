/**
 * Auth routes
 * /api/auth/*
 */
const express = require('express');
const router = express.Router();
const User = require('../models/user');
const Seller = require('../models/seller');
const { signToken, requireAuth, requireAdmin } = require('../middleware/auth');

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const user = await User.findOne({ email: email.toLowerCase().trim() }).select('+password');
    if (!user) return res.status(401).json({ error: 'Invalid email or password' });
    if (!user.active) return res.status(401).json({ error: 'Account deactivated. Contact admin.' });

    const isMatch = await user.comparePassword(password);
    if (!isMatch) return res.status(401).json({ error: 'Invalid email or password' });

    user.lastLogin = new Date();
    user.loginCount += 1;
    await user.save();

    const token = signToken(user._id);

    let seller = null;
    if (user.sellerId) {
      seller = await Seller.findOne({ sellerId: user.sellerId }).lean();
    }

    res.json({
      success: true,
      token,
      user: {
        id: user._id, email: user.email, name: user.name,
        role: user.role, sellerId: user.sellerId, active: user.active
      },
      seller
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/auth/me
router.get('/me', requireAuth, async (req, res) => {
  try {
    let seller = null;
    if (req.user.sellerId) {
      seller = await Seller.findOne({ sellerId: req.user.sellerId }).lean();
    }
    res.json({
      success: true,
      user: {
        id: req.user._id, email: req.user.email, name: req.user.name,
        role: req.user.role, sellerId: req.user.sellerId, active: req.user.active
      },
      seller
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/auth/change-password
router.post('/change-password', requireAuth, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) return res.status(400).json({ error: 'Both passwords required' });
    if (newPassword.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });

    const user = await User.findById(req.user._id).select('+password');
    const isMatch = await user.comparePassword(currentPassword);
    if (!isMatch) return res.status(401).json({ error: 'Current password is wrong' });

    user.password = newPassword;
    await user.save();
    res.json({ success: true, message: 'Password changed' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ═══ ADMIN ONLY — User Management ════════════════════════════

// GET /api/auth/users
router.get('/users', requireAuth, requireAdmin, async (req, res) => {
  try {
    const users = await User.find({}).sort({ createdAt: -1 }).lean();
    const sellerIds = users.filter(u => u.sellerId).map(u => u.sellerId);
    const sellers = await Seller.find({ sellerId: { $in: sellerIds } }).lean();
    const sellerMap = {};
    sellers.forEach(s => { sellerMap[s.sellerId] = s; });

    const result = users.map(u => ({
      ...u,
      seller: u.sellerId ? sellerMap[u.sellerId] || null : null
    }));
    res.json({ success: true, users: result });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/auth/users
router.post('/users', requireAuth, requireAdmin, async (req, res) => {
  try {
    const { email, password, name, role } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
    if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });

    const safeEmail = String(email).toLowerCase().trim();
    const safeName = name ? String(name).replace(/<[^>]*>/g, '').replace(/[<>"'`]/g, '').trim().substring(0, 80) : safeEmail.split('@')[0];

    const existing = await User.findOne({ email: safeEmail });
    if (existing) return res.status(400).json({ error: 'User with this email already exists' });

    const userRole = (role === 'admin') ? 'admin' : 'seller';
    const user = await User.create({
      email: safeEmail,
      password,
      name: safeName || safeEmail.split('@')[0],
      role: userRole,
      sellerId: ''
    });

    res.json({
      success: true,
      user: {
        id: user._id, email: user.email, name: user.name,
        role: user.role, sellerId: user.sellerId, active: user.active
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// PUT /api/auth/users/:userId
router.put('/users/:userId', requireAuth, requireAdmin, async (req, res) => {
  try {
    const { name, email, role, active, password } = req.body;
    const user = await User.findById(req.params.userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (name !== undefined) user.name = name;
    if (email !== undefined) user.email = email.toLowerCase().trim();
    if (role !== undefined && ['admin', 'seller'].includes(role)) user.role = role;
    if (active !== undefined) user.active = active;
    if (password && password.length >= 6) user.password = password;

    await user.save();
    res.json({ success: true, user: user.toJSON() });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// DELETE /api/auth/users/:userId
router.delete('/users/:userId', requireAuth, requireAdmin, async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);
    if (!user) return res.status(404).json({ error: 'User not found' });
    if (user._id.toString() === req.user._id.toString()) {
      return res.status(400).json({ error: 'Cannot delete your own account' });
    }
    await User.deleteOne({ _id: user._id });
    res.json({ success: true, message: 'User deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
