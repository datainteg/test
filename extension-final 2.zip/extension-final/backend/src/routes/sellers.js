/**
 * Sellers routes
 * /api/sellers/*
 */
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const Seller = require('../models/seller');
const { requireAuth, requireAdmin, requireOwnerOrAdmin } = require('../middleware/auth');

function classifyKeyword(k) {
  const kl = (k || '').toLowerCase();
  const cities = ['mumbai','delhi','bangalore','bengaluru','pune','chennai','hyderabad','kolkata',
    'ahmedabad','jaipur','lucknow','surat','nagpur','indore','bhopal','patna','vadodara','ludhiana',
    'agra','nashik','raipur','raigarh','chhattisgarh','maharashtra','gujarat','rajasthan','punjab',
    'odisha','karnataka','telangana','jharkhand','uttar pradesh','madhya pradesh','west bengal',
    'tamil','kerala','bihar','haryana','uttarakhand','goa','assam'];
  if (cities.some(c => kl.includes(c))) return 'city';
  if (/\d/.test(kl) || /rs\.|lakh|crore|thousand|₹|price|value|budget/.test(kl)) return 'value';
  return 'category';
}

function buildCategories(keywords) {
  const cats = { category: [], city: [], value: [] };
  keywords.forEach(k => cats[classifyKeyword(k)].push(k));
  return cats;
}

// POST /api/sellers/register
router.post('/register', requireAuth, async (req, res) => {
  try {
    const { extensionId } = req.body;
    if (!extensionId) return res.status(400).json({ error: 'extensionId required' });

    // Admin accounts do NOT get an auto-created seller on extension install
    if (req.user.role === 'admin') {
      console.log(`[Sellers] Skipping auto-register for admin user: ${req.user.email}`);
      return res.json({ success: true, skipped: true, reason: 'admin accounts do not auto-register sellers' });
    }

    // Seller role: link extension to their existing sellerId
    if (req.user.role === 'seller' && req.user.sellerId) {
      const seller = await Seller.findOneAndUpdate(
        { sellerId: req.user.sellerId },
        { $set: { extensionId } },
        { new: true }
      );
      if (seller) {
        console.log(`[Sellers] Extension linked: ${extensionId} → ${seller.sellerId}`);
        return res.json({ success: true, sellerId: seller.sellerId, seller });
      }
    }

    // Seller role with no sellerId yet: find or create by extensionId
    let seller = await Seller.findOne({ extensionId });
    if (!seller) {
      seller = await Seller.create({
        sellerId: uuidv4(),
        extensionId,
        name: `Seller-${extensionId.substring(0, 8)}`,
        keywords: [],
        keywordCategories: { category: [], city: [], value: [] }
      });
      console.log(`[Sellers] New seller registered: ${seller.sellerId}`);
    }
    res.json({ success: true, sellerId: seller.sellerId, seller });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/sellers
router.get('/', requireAuth, async (req, res) => {
  try {
    let query = {};
    if (req.user.role !== 'admin') {
      query.userId = req.user._id;
    }
    const sellers = await Seller.find(query, {
      sellerId: 1, extensionId: 1, name: 1, active: 1,
      keywords: 1, keywordCategories: 1, userId: 1, createdAt: 1
    }).lean();
    res.json({ success: true, sellers });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/sellers/:sellerId
router.get('/:sellerId', requireAuth, requireOwnerOrAdmin, async (req, res) => {
  try {
    const seller = await Seller.findOne({ sellerId: req.params.sellerId }).lean();
    if (!seller) return res.status(404).json({ error: 'Seller not found' });
    res.json({ success: true, seller });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// PUT /api/sellers/:sellerId
router.put('/:sellerId', requireAuth, requireOwnerOrAdmin, async (req, res) => {
  try {
    const { name, active } = req.body;
    const update = { updatedAt: new Date() };
    if (name !== undefined) update.name = name;
    if (active !== undefined) update.active = active;
    const seller = await Seller.findOneAndUpdate({ sellerId: req.params.sellerId }, { $set: update }, { new: true });
    if (!seller) return res.status(404).json({ error: 'Seller not found' });
    res.json({ success: true, seller });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/sellers — create seller
router.post('/', requireAuth, async (req, res) => {
  try {
    const { name, sellerId: customId } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Seller name required' });
    const safeName = String(name).replace(/<[^>]*>/g, '').replace(/[<>"'`]/g, '').trim().substring(0, 80);
    if (!safeName) return res.status(400).json({ error: 'Seller name is invalid' });

    let sellerId = customId
      ? customId.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '-').replace(/-+/g, '-')
      : safeName.toLowerCase().replace(/[^a-z0-9_-]/g, '-').replace(/-+/g, '-') + '-' + Date.now().toString(36);

    const exists = await Seller.findOne({ sellerId });
    if (exists) return res.status(400).json({ error: 'Seller ID "' + sellerId + '" already exists.' });

    const seller = await Seller.create({
      sellerId,
      userId: req.user._id,
      name: safeName,
      extensionId: '',
      keywords: [],
      keywordCategories: { category: [], city: [], value: [] }
    });

    if (!req.user.sellerId) {
      const User = require('../models/user');
      await User.updateOne({ _id: req.user._id }, { $set: { sellerId: seller.sellerId } });
    }

    console.log(`[Sellers] Created: ${seller.sellerId} by ${req.user.email}`);
    res.json({ success: true, seller });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// DELETE /api/sellers/:sellerId
router.delete('/:sellerId', requireAuth, requireOwnerOrAdmin, async (req, res) => {
  try {
    const { sellerId } = req.params;
    const seller = await Seller.findOne({ sellerId });
    if (!seller) return res.status(404).json({ error: 'Seller not found' });

    const Lead = require('../models/lead');
    const ActionLog = require('../models/actionLog');
    await Lead.deleteMany({ sellerId });
    await ActionLog.deleteMany({ sellerId });

    const User = require('../models/user');
    await User.updateMany({ sellerId }, { $set: { sellerId: '' } });

    await Seller.deleteOne({ sellerId });
    console.log(`[Sellers] Deleted: ${sellerId} by ${req.user.email}`);
    res.json({ success: true, message: 'Seller and associated data deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/sellers/:sellerId/keywords
router.post('/:sellerId/keywords', requireAuth, requireOwnerOrAdmin, async (req, res) => {
  try {
    let { keyword, category } = req.body;
    if (!keyword) return res.status(400).json({ error: 'keyword required' });

    keyword = String(keyword)
      .replace(/<[^>]*>/g, '')
      .replace(/[<>"'`]/g, '')
      .toLowerCase().trim()
      .substring(0, 100);

    if (!keyword) return res.status(400).json({ error: 'keyword is empty after sanitization' });
    if (!category) category = classifyKeyword(keyword);
    if (!['category','city','value'].includes(category)) category = 'category';

    const seller = await Seller.findOneAndUpdate(
      { sellerId: req.params.sellerId },
      { $addToSet: { keywords: keyword, [`keywordCategories.${category}`]: keyword }, $set: { updatedAt: new Date() } },
      { new: true }
    );
    if (!seller) return res.status(404).json({ error: 'Seller not found' });
    res.json({ success: true, seller });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// DELETE /api/sellers/:sellerId/keywords/:keyword
router.delete('/:sellerId/keywords/:keyword', requireAuth, requireOwnerOrAdmin, async (req, res) => {
  try {
    const keyword = decodeURIComponent(req.params.keyword).toLowerCase();
    const cat = classifyKeyword(keyword);
    const seller = await Seller.findOneAndUpdate(
      { sellerId: req.params.sellerId },
      { $pull: { keywords: keyword, [`keywordCategories.${cat}`]: keyword }, $set: { updatedAt: new Date() } },
      { new: true }
    );
    if (!seller) return res.status(404).json({ error: 'Seller not found' });
    res.json({ success: true, seller });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// PUT /api/sellers/:sellerId/keywords
router.put('/:sellerId/keywords', requireAuth, requireOwnerOrAdmin, async (req, res) => {
  try {
    const { keywords, keywordCategories } = req.body;
    if (!Array.isArray(keywords)) return res.status(400).json({ error: 'keywords array required' });
    const cleaned = keywords.map(k => k.toLowerCase().trim()).filter(Boolean);

    const cats = keywordCategories && keywordCategories.category
      ? {
          category: (keywordCategories.category || []).map(k => k.toLowerCase().trim()).filter(Boolean),
          city:     (keywordCategories.city     || []).map(k => k.toLowerCase().trim()).filter(Boolean),
          value:    (keywordCategories.value    || []).map(k => k.toLowerCase().trim()).filter(Boolean)
        }
      : buildCategories(cleaned);

    const seller = await Seller.findOneAndUpdate(
      { sellerId: req.params.sellerId },
      { $set: { keywords: cleaned, keywordCategories: cats, updatedAt: new Date() } },
      { new: true }
    );
    if (!seller) return res.status(404).json({ error: 'Seller not found' });
    res.json({ success: true, seller });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
