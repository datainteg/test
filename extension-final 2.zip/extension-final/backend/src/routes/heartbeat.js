/**
 * Heartbeat routes
 * /api/heartbeat/*
 */
const express = require('express');
const router = express.Router();
const Heartbeat = require('../models/heartbeat');
const Seller = require('../models/seller');
const { requireAuth } = require('../middleware/auth');

// POST /api/heartbeat
router.post('/', requireAuth, async (req, res) => {
  try {
    const sellerId = req.user.sellerId || req.body.sellerId;
    if (!sellerId) return res.status(400).json({ error: 'sellerId required' });

    const { extensionId, phase, stats, tabUrl, chromeFlags } = req.body;
    await Heartbeat.findOneAndUpdate(
      { sellerId },
      {
        $set: {
          sellerId,
          extensionId: extensionId || '',
          phase: phase || 'unknown',
          stats: stats || {},
          tabUrl: tabUrl || '',
          chromeFlags: chromeFlags || '',
          lastPing: new Date(),
          isAlive: true
        },
        $inc: { pingCount: 1 }
      },
      { upsert: true, new: true }
    );
    res.json({ success: true, serverTime: new Date().toISOString() });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/heartbeat
router.get('/', requireAuth, async (req, res) => {
  try {
    let query = {};
    
    if (req.user.role !== 'admin') {
      // Collect all sellerIds owned by this user
      const ownSellers = await Seller.find({ userId: req.user._id }, { sellerId: 1 }).lean();
      const ownIds = ownSellers.map(s => s.sellerId);
      if (req.user.sellerId && !ownIds.includes(req.user.sellerId)) ownIds.push(req.user.sellerId);
      
      // FIX: If sellerId query param provided, filter within owned sellers
      if (req.query.sellerId) {
        if (ownIds.includes(req.query.sellerId)) {
          query.sellerId = req.query.sellerId;
        } else {
          return res.json({ success: true, heartbeats: [] });
        }
      } else {
        query.sellerId = ownIds.length === 1 ? ownIds[0] : { $in: ownIds };
      }
    } else if (req.query.sellerId) {
      // Admin with sellerId filter
      query.sellerId = req.query.sellerId;
    }
    
    const heartbeats = await Heartbeat.find(query).lean();
    const now = Date.now();
    const result = heartbeats.map(hb => ({
      ...hb,
      isAlive: hb.lastPing && (now - new Date(hb.lastPing).getTime()) < 90000,
      secondsSinceLastPing: hb.lastPing ? Math.round((now - new Date(hb.lastPing).getTime()) / 1000) : null
    }));
    res.json({ success: true, heartbeats: result });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/heartbeat/history
router.get('/history', requireAuth, async (req, res) => {
  try {
    const sellerId = req.query.sellerId || req.user.sellerId;
    if (!sellerId) return res.status(400).json({ error: 'sellerId required' });
    if (req.user.role !== 'admin' && sellerId !== req.user.sellerId) {
      return res.status(403).json({ error: 'Access denied' });
    }
    const hb = await Heartbeat.findOne({ sellerId }).lean();
    if (!hb) return res.json({ success: true, history: [] });
    res.json({
      success: true, sellerId,
      lastPing: hb.lastPing,
      isAlive: hb.lastPing && (Date.now() - new Date(hb.lastPing).getTime()) < 90000,
      phase: hb.phase, stats: hb.stats, pingCount: hb.pingCount,
      tabUrl: hb.tabUrl, chromeFlags: hb.chromeFlags
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
