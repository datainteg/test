/**
 * Shared utility functions
 */

// Escape regex special chars to prevent ReDoS
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// CSV escape with proper quoting
function csvEscape(val) {
  const str = String(val == null ? '' : val);
  return '"' + str.replace(/"/g, '""') + '"';
}

// UTF-8 BOM for Excel compatibility with Indian characters
const CSV_BOM = '\uFEFF';

module.exports = { escapeRegex, csvEscape, CSV_BOM };
