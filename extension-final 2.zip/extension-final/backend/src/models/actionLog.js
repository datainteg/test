const mongoose = require('mongoose');

const actionLogSchema = new mongoose.Schema({
  sellerId: { type: String, required: true, index: true },
  leadId: { type: String, required: true },
  action: { type: String, enum: ['captured', 'contacted', 'skipped', 'filtered'], required: true },
  reason: { type: String, default: '' },
  title: { type: String, default: '' },
  keywordMatched: { type: String, default: '' },
  timestamp: { type: Date, default: Date.now, index: true }
});

module.exports = mongoose.model('ActionLog', actionLogSchema);
