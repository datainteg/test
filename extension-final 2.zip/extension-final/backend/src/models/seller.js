const mongoose = require('mongoose');

const sellerSchema = new mongoose.Schema({
  sellerId: { type: String, required: true, unique: true, index: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  extensionId: { type: String, default: '' },
  name: { type: String, default: '' },
  active: { type: Boolean, default: true },
  keywords: { type: [String], default: [] },
  keywordCategories: {
    category: { type: [String], default: [] },
    city: { type: [String], default: [] },
    value: { type: [String], default: [] }
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

sellerSchema.pre('save', function(next) {
  this.updatedAt = new Date();
  next();
});

module.exports = mongoose.model('Seller', sellerSchema);
