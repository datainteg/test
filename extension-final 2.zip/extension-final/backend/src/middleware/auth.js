/**
 * Auth middleware
 */
const jwt = require('jsonwebtoken');
const User = require('../models/user');

const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_ME_default_secret';

// Generate JWT token
function signToken(userId) {
  return jwt.sign({ id: userId }, JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '30d'
  });
}

// Middleware: require valid JWT → sets req.user
async function requireAuth(req, res, next) {
  try {
    let token = null;

    // Check Authorization header ONLY
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      return res.status(401).json({ error: 'Not authenticated. Please login.' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(decoded.id);

    if (!user || !user.active) {
      return res.status(401).json({ error: 'User not found or deactivated.' });
    }

    req.user = user;
    next();
  } catch (err) {
    if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Invalid or expired token. Please login again.' });
    }
    return res.status(500).json({ error: 'Auth error: ' + err.message });
  }
}

// Middleware: require admin role
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required.' });
  }
  next();
}

// Middleware: require seller to only access own data (or admin can access all)
async function requireOwnerOrAdmin(req, res, next) {
  if (req.user.role === 'admin') return next();

  const requestedSellerId = req.params.sellerId || req.query.sellerId || req.body.sellerId;

  if (!requestedSellerId) {
    return res.status(400).json({ error: 'sellerId is required.' });
  }

  const Seller = require('../models/seller');
  const seller = await Seller.findOne({ sellerId: requestedSellerId });
  if (!seller) return res.status(404).json({ error: 'Seller not found' });

  // Check 1: seller was created via dashboard — userId is set
  if (seller.userId && seller.userId.toString() === req.user._id.toString()) return next();

  // Check 2: seller matches the user's primary sellerId
  if (requestedSellerId === req.user.sellerId) return next();

  // Check 3: seller is in the user's owned sellers list
  const ownedSeller = await Seller.findOne({ sellerId: requestedSellerId, userId: req.user._id });
  if (ownedSeller) return next();

  return res.status(403).json({ error: 'Access denied. You can only access your own data.' });
}

module.exports = { signToken, requireAuth, requireAdmin, requireOwnerOrAdmin };
