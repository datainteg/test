/**
 * Extension Dashboard — Backend Server
 * @version 10.0.0
 */
'use strict';
require('dotenv').config();

const app = require('./src/app');
const { connectDB } = require('./src/config/database');
const { seedAdmin } = require('./src/config/seed');

const PORT = process.env.PORT || 5000;
const ENV = process.env.NODE_ENV || 'development';

// Graceful shutdown
const shutdown = (signal) => {
  console.log(`\n${signal} received. Shutting down gracefully...`);
  process.exit(0);
};

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

(async () => {
  await connectDB();
  await seedAdmin();

  app.listen(PORT, '0.0.0.0', () => {
    console.log('');
    console.log('═══════════════════════════════════════════════════════');
    console.log(`🧲 Extension Dashboard v10.0.0  [${ENV.toUpperCase()}]`);
    console.log(`📍 Port: ${PORT}`);
    console.log(`🔗 Health: http://localhost:${PORT}/api/health`);
    console.log('═══════════════════════════════════════════════════════');
    console.log('');
  });
})();
