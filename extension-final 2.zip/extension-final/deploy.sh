#!/bin/bash
# ============================================
# Extension Dashboard - Deployment Script
# extension.mlaics.com (Port 82)
# ============================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}     Extension Dashboard - Deployment${NC}"
echo -e "${BLUE}     extension.mlaics.com${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo ""

# Check if .env exists
if [ ! -f .env ]; then
    echo -e "${RED}❌ .env file not found!${NC}"
    echo -e "${YELLOW}   Run: cp .env.example .env && nano .env${NC}"
    exit 1
fi

# Check for CHANGE_ME values
if grep -q "CHANGE_ME" .env; then
    echo -e "${RED}❌ Found CHANGE_ME placeholders in .env!${NC}"
    echo -e "${YELLOW}   Please update all values marked CHANGE_ME${NC}"
    grep "CHANGE_ME" .env | head -5
    exit 1
fi

# Ensure network exists
ensure_network() {
    if ! docker network ls | grep -q "mlaics-network"; then
        echo -e "${YELLOW}Creating mlaics-network...${NC}"
        docker network create mlaics-network
    fi
}

# Full deploy
full_deploy() {
    echo -e "${GREEN}🚀 Starting full deployment...${NC}"
    ensure_network
    
    echo -e "${YELLOW}Building containers...${NC}"
    docker compose build --no-cache
    
    echo -e "${YELLOW}Starting services...${NC}"
    docker compose up -d
    
    echo -e "${YELLOW}Waiting for services to be ready...${NC}"
    sleep 15
    
    echo -e "${GREEN}Checking health...${NC}"
    if curl -s http://localhost:82/api/health | grep -q "success"; then
        echo -e "${GREEN}✅ Deployment successful!${NC}"
        echo -e "${GREEN}   API: http://localhost:82/api/health${NC}"
        echo ""
        echo -e "${YELLOW}Next steps:${NC}"
        echo "  1. Add subdomain to host nginx (option 8)"
        echo "  2. Get SSL certificate (option 7)"
        echo "  3. Access: https://extension.mlaics.com"
    else
        echo -e "${RED}⚠️  Health check failed. Check logs:${NC}"
        docker compose logs --tail=30
    fi
}

# Menu
show_menu() {
    echo -e "${GREEN}Select an option:${NC}"
    echo ""
    echo "  1) Full Deploy (build + start all)"
    echo "  2) Rebuild & Restart"
    echo "  3) Start Services"
    echo "  4) Stop Services"
    echo "  5) View Logs"
    echo "  6) Check Status"
    echo "  7) Setup SSL Certificate"
    echo "  8) Add to Host Nginx (mlaics-nginx)"
    echo "  0) Exit"
    echo ""
    read -p "Enter choice [0-8]: " choice
}

# Rebuild
rebuild() {
    echo -e "${YELLOW}Rebuilding containers...${NC}"
    docker compose down
    docker compose build --no-cache
    docker compose up -d
    echo -e "${GREEN}✅ Rebuild complete${NC}"
}

# Start
start_services() {
    ensure_network
    docker compose up -d
    echo -e "${GREEN}✅ Services started${NC}"
}

# Stop
stop_services() {
    docker compose down
    echo -e "${GREEN}✅ Services stopped${NC}"
}

# Logs
view_logs() {
    echo "Select service:"
    echo "  1) All"
    echo "  2) Backend"
    echo "  3) Frontend"
    echo "  4) MongoDB"
    echo "  5) Nginx"
    read -p "Choice: " log_choice
    
    case $log_choice in
        1) docker compose logs -f --tail=100 ;;
        2) docker compose logs -f --tail=100 extension-backend ;;
        3) docker compose logs -f --tail=100 extension-frontend ;;
        4) docker compose logs -f --tail=100 extension-mongodb ;;
        5) docker compose logs -f --tail=100 extension-nginx ;;
        *) docker compose logs -f --tail=100 ;;
    esac
}

# Status
check_status() {
    echo -e "${GREEN}Container Status:${NC}"
    docker compose ps
    echo ""
    echo -e "${GREEN}Health Check:${NC}"
    curl -s http://localhost:82/api/health | python3 -m json.tool 2>/dev/null || echo "API not responding"
}

# SSL Setup
setup_ssl() {
    echo -e "${YELLOW}Setting up SSL certificate...${NC}"
    echo -e "${YELLOW}Note: Run this AFTER adding to host nginx${NC}"
    
    read -p "Email for Let's Encrypt [contact@mlaics.com]: " ssl_email
    ssl_email=${ssl_email:-contact@mlaics.com}
    
    docker exec mlaics-certbot certbot certonly --webroot \
        -w /var/www/certbot -d extension.mlaics.com \
        --non-interactive --agree-tos --email "$ssl_email"
    
    echo -e "${GREEN}✅ SSL certificate obtained${NC}"
    echo -e "${YELLOW}Now update host nginx config to enable HTTPS${NC}"
}

# Add to host nginx
add_to_host_nginx() {
    echo -e "${YELLOW}Adding extension.mlaics.com to host nginx (mlaics-nginx)...${NC}"
    
    # Get container IP
    EXT_IP=$(docker inspect extension-nginx --format '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' 2>/dev/null)
    
    if [ -z "$EXT_IP" ]; then
        echo -e "${RED}❌ Could not find extension-nginx IP. Is it running?${NC}"
        return 1
    fi
    
    echo -e "${GREEN}Extension nginx IP: ${EXT_IP}${NC}"
    
    # Create config
    CONFIG_PATH="/home/datainteg/mlaics-main/nginx/conf.d/extension.conf"
    
    cat > /tmp/extension-host.conf << EOF
# EXTENSION.MLAICS.COM - Host Nginx Config
upstream extension_internal {
    server ${EXT_IP}:80;
    keepalive 32;
}

server {
    listen 80;
    listen [::]:80;
    server_name extension.mlaics.com;

    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }

    location / {
        proxy_pass http://extension_internal;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

    echo ""
    echo -e "${GREEN}Run these commands to add to host nginx:${NC}"
    echo ""
    echo "  sudo cp /tmp/extension-host.conf ${CONFIG_PATH}"
    echo "  docker exec mlaics-nginx nginx -t"
    echo "  docker exec mlaics-nginx nginx -s reload"
    echo ""
    
    read -p "Copy config now? (y/n): " copy_now
    if [ "$copy_now" = "y" ]; then
        sudo cp /tmp/extension-host.conf "$CONFIG_PATH" 2>/dev/null || cp /tmp/extension-host.conf "$CONFIG_PATH"
        docker exec mlaics-nginx nginx -t && docker exec mlaics-nginx nginx -s reload
        echo -e "${GREEN}✅ Config added and nginx reloaded${NC}"
    fi
}

# Main loop
while true; do
    show_menu
    case $choice in
        1) full_deploy ;;
        2) rebuild ;;
        3) start_services ;;
        4) stop_services ;;
        5) view_logs ;;
        6) check_status ;;
        7) setup_ssl ;;
        8) add_to_host_nginx ;;
        0) echo "Goodbye!"; exit 0 ;;
        *) echo -e "${RED}Invalid option${NC}" ;;
    esac
    echo ""
    read -p "Press Enter to continue..."
    clear
done
