import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { User } from '@/types';
import { login as apiLogin, getMe } from '@/services/api';

interface AuthCtx {
  token: string | null;
  user: User | null;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<string | null>;
  logout: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthCtx>({
  token: null, user: null, isAdmin: false,
  login: async () => null, logout: () => {}, loading: true,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Restore session on mount
  useEffect(() => {
    (async () => {
      const stored = localStorage.getItem('lm_auth');
      if (stored) {
        try {
          const d = JSON.parse(stored);
          if (!d.token) throw new Error('No token');
          // Token is already in localStorage, so authFetch in getMe() can read it
          const res = await getMe();
          if (res.success) {
            setToken(d.token);
            setUser(res.user);
          } else {
            // Token expired or invalid — clean up both localStorage AND React state
            localStorage.removeItem('lm_auth');
            setToken(null);
            setUser(null);
          }
        } catch {
          localStorage.removeItem('lm_auth');
          setToken(null);
          setUser(null);
        }
      }
      setLoading(false);
    })();
  }, []);

  const login = async (email: string, password: string): Promise<string | null> => {
    const d = await apiLogin(email, password);
    if (!d.success) return d.error || 'Login failed';
    setToken(d.token);
    setUser(d.user);
    localStorage.setItem('lm_auth', JSON.stringify({ token: d.token, user: d.user }));
    return null;
  };

  const logout = () => {
    setToken(null); setUser(null);
    localStorage.removeItem('lm_auth');
  };

  return (
    <AuthContext.Provider value={{ token, user, isAdmin: user?.role === 'admin', login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
