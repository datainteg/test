import React, { useState, type ReactNode } from 'react';
import { useAuth } from '@/context/AuthContext';
import {
  FiGrid, FiUsers, FiUser, FiHash, FiShield, FiActivity,
  FiLogOut, FiMenu, FiX
} from 'react-icons/fi';

interface NavItem {
  key: string;
  label: string;
  icon: React.ComponentType<{ className?: string; size?: number }>;
  admin?: boolean;
}

const navItems: NavItem[] = [
  { key: 'overview',  label: 'Overview',  icon: FiGrid },
  { key: 'leads',     label: 'Leads',     icon: FiUsers },
  { key: 'sellers',   label: 'Sellers',   icon: FiUser },
  { key: 'keywords',  label: 'Keywords',  icon: FiHash },
  { key: 'users',     label: 'Users',     icon: FiShield, admin: true },
  { key: 'heartbeat', label: 'Heartbeat', icon: FiActivity },
];

interface Props {
  activePage: string;
  onNavigate: (page: string) => void;
  children: ReactNode;
  topbar: ReactNode;
}

export default function Sidebar({ activePage, onNavigate, children, topbar }: Props) {
  const { user, logout, isAdmin } = useAuth();
  const [open, setOpen] = useState(false);
  const visibleNav = navItems.filter(n => !n.admin || isAdmin);

  return (
    <div className="flex min-h-screen bg-slate-50">

      {/* ── MOBILE DRAWER OVERLAY ── */}
      {open && (
        <div
          className="fixed inset-0 bg-black/40 z-40 lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      {/* ── SIDEBAR (desktop: always visible | mobile: drawer) ── */}
      <aside className={`
        fixed top-0 left-0 bottom-0 w-64 bg-white border-r border-slate-200
        flex flex-col z-50 transition-transform duration-200
        lg:translate-x-0
        ${open ? 'translate-x-0 shadow-2xl' : '-translate-x-full'}
      `}>
        {/* Logo */}
        <div className="px-5 py-4 flex items-center justify-between border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-accent rounded-lg flex items-center justify-center text-white font-bold text-sm flex-shrink-0">LM</div>
            <div>
              <div className="font-bold text-slate-900 text-sm">Lead Magnet</div>
              <div className="text-[10px] text-slate-400">mlaics.com</div>
            </div>
          </div>
          <button className="lg:hidden text-slate-400 hover:text-slate-600 p-1" onClick={() => setOpen(false)}>
            <FiX size={18} />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-3 px-2 overflow-y-auto space-y-0.5">
          {visibleNav.map(n => (
            <button
              key={n.key}
              onClick={() => { onNavigate(n.key); setOpen(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                activePage === n.key
                  ? 'bg-indigo-50 text-accent font-semibold'
                  : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700'
              }`}
            >
              <n.icon className="w-[18px] h-[18px] flex-shrink-0" />
              {n.label}
            </button>
          ))}
        </nav>

        {/* User footer */}
        <div className="px-4 py-3 border-t border-slate-200 flex items-center gap-2">
          <div className="w-8 h-8 bg-indigo-50 text-accent font-bold text-xs rounded-full flex items-center justify-center flex-shrink-0">
            {(user?.name || 'U')[0].toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-semibold text-slate-900 truncate">{user?.name || user?.email}</div>
            <div className="text-[10px] text-slate-400 uppercase tracking-wider">{user?.role}</div>
          </div>
          <button onClick={logout} className="text-slate-400 hover:text-red-500 p-1 transition-colors" title="Logout">
            <FiLogOut size={16} />
          </button>
        </div>
      </aside>

      {/* ── MAIN CONTENT ── */}
      <div className="flex-1 flex flex-col lg:ml-64 min-w-0">

        {/* Topbar */}
        <header className="h-14 bg-white border-b border-slate-200 flex items-center gap-2 px-3 sm:px-4 sticky top-0 z-30">
          {/* Hamburger — mobile only */}
          <button className="lg:hidden text-slate-500 hover:text-slate-700 p-1 flex-shrink-0" onClick={() => setOpen(true)}>
            <FiMenu size={20} />
          </button>
          {topbar}
        </header>

        {/* Page content */}
        <main className="flex-1 p-3 sm:p-4 lg:p-6 pb-20 lg:pb-6">
          {children}
        </main>
      </div>

      {/* ── MOBILE BOTTOM NAV ── */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-30 flex">
        {visibleNav.slice(0, 5).map(n => (
          <button
            key={n.key}
            onClick={() => onNavigate(n.key)}
            className={`flex-1 flex flex-col items-center justify-center py-2 gap-0.5 text-[10px] font-medium transition-colors ${
              activePage === n.key
                ? 'text-accent'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <n.icon size={18} />
            <span>{n.label}</span>
          </button>
        ))}
        {/* More button for remaining items */}
        {visibleNav.length > 5 && (
          <button
            onClick={() => setOpen(true)}
            className="flex-1 flex flex-col items-center justify-center py-2 gap-0.5 text-[10px] font-medium text-slate-400 hover:text-slate-600"
          >
            <FiMenu size={18} />
            <span>More</span>
          </button>
        )}
      </nav>

    </div>
  );
}
