export default function StatusDot({ online }: { online: boolean }) {
  return (
    <span
      className={`inline-block w-2 h-2 rounded-full flex-shrink-0 ${
        online ? 'bg-emerald-500 shadow-[0_0_0_3px_#ecfdf5]' : 'bg-red-500'
      }`}
    />
  );
}
