import { useState, useCallback, useRef, createContext, useContext, ReactNode } from 'react';
import { FiCheckCircle, FiAlertCircle, FiInfo } from 'react-icons/fi';

type ToastType = 'success' | 'error' | 'info';

interface ToastCtx {
  toast: (msg: string, type?: ToastType) => void;
}

const ToastContext = createContext<ToastCtx>({ toast: () => {} });

const icons = { success: FiCheckCircle, error: FiAlertCircle, info: FiInfo };
const colors = {
  success: 'bg-emerald-50 text-emerald-600 border-emerald-200',
  error: 'bg-red-50 text-red-600 border-red-200',
  info: 'bg-indigo-50 text-indigo-600 border-indigo-200',
};

export function ToastProvider({ children }: { children: ReactNode }) {
  const [msg, setMsg] = useState('');
  const [type, setType] = useState<ToastType>('info');
  const [visible, setVisible] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const toast = useCallback((m: string, t: ToastType = 'info') => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setMsg(m); setType(t); setVisible(true);
    timerRef.current = setTimeout(() => setVisible(false), 3000);
  }, []);

  const Icon = icons[type];

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      {visible && (
        <div className={`fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:bottom-6 z-[999] flex items-center gap-2 px-4 py-2.5 rounded-lg border shadow-lg text-sm font-semibold transition-all ${colors[type]}`}>
          <Icon className="w-4 h-4" />
          {msg}
        </div>
      )}
    </ToastContext.Provider>
  );
}

export const useToast = () => useContext(ToastContext);
