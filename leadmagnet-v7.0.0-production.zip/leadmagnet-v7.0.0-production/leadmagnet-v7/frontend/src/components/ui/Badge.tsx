import type { ReactNode } from 'react';

interface Props {
  variant: 'hot' | 'warm' | 'cool' | 'success' | 'muted' | 'accent' | 'danger';
  children: ReactNode;
}

const styles: Record<string, string> = {
  hot:     'bg-red-50 text-red-600',
  warm:    'bg-amber-50 text-amber-600',
  cool:    'bg-blue-50 text-blue-600',
  success: 'bg-emerald-50 text-emerald-600',
  muted:   'bg-slate-100 text-slate-400',
  accent:  'bg-indigo-50 text-indigo-600',
  danger:  'bg-red-50 text-red-600',
};

export default function Badge({ variant, children }: Props) {
  return (
    <span className={`badge ${styles[variant]}`}>
      {children}
    </span>
  );
}

export function ScoreBadge({ score }: { score: number }) {
  const v = score >= 60 ? 'hot' : score >= 25 ? 'warm' : 'cool';
  return <Badge variant={v}>{score}</Badge>;
}
