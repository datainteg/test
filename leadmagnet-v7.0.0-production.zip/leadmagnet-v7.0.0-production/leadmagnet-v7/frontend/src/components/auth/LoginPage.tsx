import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { checkHealth } from '@/services/api';
import StatusDot from '@/components/ui/StatusDot';

export default function LoginPage() {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [online, setOnline] = useState(false);

  useEffect(() => { checkHealth().then(setOnline); }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) { setError('Enter email and password'); return; }
    setLoading(true); setError('');
    const err = await login(email, password);
    if (err) { setError(err); setLoading(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-10 w-full max-w-sm shadow-lg mx-4 sm:mx-0">
        <div className="text-center mb-8">
          <div className="w-14 h-14 mx-auto mb-4 bg-accent rounded-xl flex items-center justify-center text-white font-bold text-xl">
            LM
          </div>
          <h1 className="text-xl font-bold text-slate-900">Lead Magnet</h1>
          <p className="text-slate-400 text-sm mt-1">Sign in to your dashboard</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-500 mb-1.5">Email</label>
            <input
              type="email" value={email} onChange={e => setEmail(e.target.value)}
              placeholder="you@company.com" autoComplete="email"
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-accent focus:ring-2 focus:ring-indigo-50"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-500 mb-1.5">Password</label>
            <input
              type="password" value={password} onChange={e => setPassword(e.target.value)}
              placeholder="Your password" autoComplete="current-password"
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-accent focus:ring-2 focus:ring-indigo-50"
            />
          </div>
          {error && <p className="text-red-500 text-xs">{error}</p>}
          <button
            type="submit" disabled={loading}
            className="w-full py-2.5 bg-accent hover:bg-accent-hover text-white font-semibold rounded-lg text-sm disabled:opacity-50 transition-colors"
          >
            {loading ? 'Signing in…' : 'Sign In'}
          </button>
        </form>

        <div className="flex items-center justify-center gap-1.5 mt-6 text-xs text-slate-400">
          <StatusDot online={online} />
          {online ? 'Server online' : 'Server offline'}
        </div>
      </div>
    </div>
  );
}
