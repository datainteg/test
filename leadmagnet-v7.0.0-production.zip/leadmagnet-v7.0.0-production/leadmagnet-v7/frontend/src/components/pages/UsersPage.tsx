import { useState, useEffect, useCallback } from 'react';
import { FiPlus, FiTrash2, FiToggleLeft, FiToggleRight } from 'react-icons/fi';
import { getUsers, createUser, updateUser, deleteUser } from '@/services/api';
import { useToast } from '@/components/ui/Toast';
import { useSellers } from '@/context/SellerContext';
import Modal from '@/components/ui/Modal';
import Badge from '@/components/ui/Badge';

interface UserRow {
  _id: string; name: string; email: string;
  role: string; sellerId: string; active: boolean;
  seller?: { name: string; sellerId: string } | null;
  createdAt?: string; lastLogin?: string; loginCount?: number;
}

const toIST = (iso: string) =>
  new Date(iso).toLocaleString('en-IN', {
    timeZone: 'Asia/Kolkata', dateStyle: 'short', timeStyle: 'short',
  });

export default function UsersPage() {
  const { toast } = useToast();
  const { sellers } = useSellers();
  const [users, setUsers] = useState<UserRow[]>([]);
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState('seller');

  const load = useCallback(async () => {
    try { const d = await getUsers(); if (d.success) setUsers(d.users || []); } catch {}
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleCreate = async () => {
    if (!email || !pw) { toast('Email and password required', 'error'); return; }
    if (pw.length < 6) { toast('Password min 6 characters', 'error'); return; }
    const d = await createUser({ email, password: pw, name, role });
    if (d.success) { toast('User created', 'success'); setOpen(false); setEmail(''); setPw(''); setName(''); load(); }
    else toast(d.error || 'Failed', 'error');
  };

  const handleToggle = async (userId: string, currentActive: boolean) => {
    const d = await updateUser(userId, { active: !currentActive });
    if (d.success) { toast(currentActive ? 'User disabled' : 'User enabled', 'success'); load(); }
    else toast(d.error || 'Failed', 'error');
  };

  const handleDelete = async (userId: string, userEmail: string) => {
    if (!confirm(`Delete user "${userEmail}"?\n\nSeller profiles and leads will NOT be deleted.`)) return;
    const d = await deleteUser(userId);
    if (d.success) { toast('User deleted', 'success'); load(); }
    else toast(d.error || 'Failed', 'error');
  };

  const sellerCountByUserId = (userId: string) =>
    sellers.filter(s => s.userId === userId).length;

  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
      <div className="px-4 sm:px-5 py-3 sm:py-4 border-b border-slate-200 flex items-center justify-between gap-2">
        <div className="min-w-0">
          <h3 className="font-semibold text-slate-900 text-sm sm:text-base">User Management</h3>
          <p className="text-xs text-slate-400 mt-0.5 hidden sm:block">{users.length} user{users.length !== 1 ? 's' : ''} total</p>
        </div>
        <button onClick={() => setOpen(true)} className="flex items-center gap-1.5 text-xs font-semibold text-white bg-accent px-3 py-1.5 rounded-lg hover:bg-accent-hover flex-shrink-0">
          <FiPlus size={14} /> <span className="hidden sm:inline">New User</span><span className="sm:hidden">New</span>
        </button>
      </div>

      {/* Mobile card list */}
      <div className="sm:hidden divide-y divide-slate-100">
        {users.length === 0 ? (
          <div className="text-center py-10 text-slate-400 text-sm">No users</div>
        ) : users.map(u => {
          const isActive = u.active !== false;
          return (
            <div key={u._id} className="px-4 py-3">
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="font-semibold text-slate-900 text-sm truncate">{u.name || u.email}</div>
                  <div className="text-xs text-slate-400 truncate">{u.email}</div>
                </div>
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <Badge variant={u.role === 'admin' ? 'accent' : 'muted'}>{u.role}</Badge>
                  <Badge variant={isActive ? 'success' : 'danger'}>{isActive ? 'On' : 'Off'}</Badge>
                </div>
              </div>
              {u.lastLogin && (
                <div className="text-[10px] text-slate-300 mt-1">Last login: {toIST(u.lastLogin)}</div>
              )}
              <div className="flex gap-2 mt-2">
                <button onClick={() => handleToggle(u._id, isActive)}
                  className={`flex-1 flex items-center justify-center gap-1 text-xs font-medium py-1.5 rounded-lg border transition-colors ${isActive ? 'text-amber-600 border-amber-200 bg-amber-50' : 'text-emerald-600 border-emerald-200 bg-emerald-50'}`}>
                  {isActive ? <FiToggleRight size={14} /> : <FiToggleLeft size={14} />}
                  {isActive ? 'Disable' : 'Enable'}
                </button>
                <button onClick={() => handleDelete(u._id, u.email)}
                  className="flex-1 flex items-center justify-center gap-1 text-xs font-medium py-1.5 rounded-lg border text-red-500 border-red-200 bg-red-50">
                  <FiTrash2 size={13} /> Delete
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Desktop table */}
      <div className="hidden sm:block overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
              <th className="px-4 py-2.5">Name</th>
              <th className="px-4 py-2.5">Email</th>
              <th className="px-4 py-2.5">Role</th>
              <th className="px-4 py-2.5 hidden md:table-cell">Seller ID</th>
              <th className="px-4 py-2.5 hidden lg:table-cell">Sellers</th>
              <th className="px-4 py-2.5">Status</th>
              <th className="px-4 py-2.5 hidden md:table-cell">Last Login (IST)</th>
              <th className="px-4 py-2.5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.length === 0 ? (
              <tr><td colSpan={8} className="text-center py-10 text-slate-400">No users</td></tr>
            ) : users.map(u => {
              const isActive = u.active !== false;
              const sCount = sellerCountByUserId(u._id);
              return (
                <tr key={u._id} className="border-t border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-3 font-semibold text-slate-900">{u.name || '—'}</td>
                  <td className="px-4 py-3 text-slate-600 text-xs">{u.email}</td>
                  <td className="px-4 py-3"><Badge variant={u.role === 'admin' ? 'accent' : 'muted'}>{u.role}</Badge></td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    {u.sellerId ? <code className="text-xs text-slate-500 bg-slate-50 px-1.5 py-0.5 rounded">{u.sellerId}</code> : <span className="text-xs text-slate-300">None</span>}
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell text-xs font-semibold text-slate-500">{sCount}</td>
                  <td className="px-4 py-3"><Badge variant={isActive ? 'success' : 'danger'}>{isActive ? 'Active' : 'Disabled'}</Badge></td>
                  <td className="px-4 py-3 text-xs text-slate-400 hidden md:table-cell">
                    {u.lastLogin ? toIST(u.lastLogin) : 'Never'}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => handleToggle(u._id, isActive)}
                        className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-lg border transition-colors ${isActive ? 'text-amber-600 border-amber-200 bg-amber-50 hover:bg-amber-100' : 'text-emerald-600 border-emerald-200 bg-emerald-50 hover:bg-emerald-100'}`}>
                        {isActive ? <FiToggleRight size={14} /> : <FiToggleLeft size={14} />}
                        {isActive ? 'Disable' : 'Enable'}
                      </button>
                      <button onClick={() => handleDelete(u._id, u.email)}
                        className="flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-lg border text-red-500 border-red-200 bg-red-50 hover:bg-red-100 transition-colors">
                        <FiTrash2 size={13} /> Delete
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Create New User" footer={
        <button onClick={handleCreate} className="px-4 py-2 bg-accent text-white text-sm font-semibold rounded-lg hover:bg-accent-hover">Create</button>
      }>
        <div className="space-y-3">
          <div><label className="block text-sm font-medium text-slate-500 mb-1">Email</label>
            <input value={email} onChange={e => setEmail(e.target.value)} type="email" placeholder="user@example.com"
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-accent" /></div>
          <div><label className="block text-sm font-medium text-slate-500 mb-1">Password</label>
            <input value={pw} onChange={e => setPw(e.target.value)} type="password" placeholder="Min 6 characters"
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-accent" /></div>
          <div><label className="block text-sm font-medium text-slate-500 mb-1">Name</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="Full name"
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-accent" /></div>
          <div><label className="block text-sm font-medium text-slate-500 mb-1">Role</label>
            <select value={role} onChange={e => setRole(e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white">
              <option value="seller">Seller</option><option value="admin">Admin</option>
            </select></div>
        </div>
      </Modal>
    </div>
  );
}
