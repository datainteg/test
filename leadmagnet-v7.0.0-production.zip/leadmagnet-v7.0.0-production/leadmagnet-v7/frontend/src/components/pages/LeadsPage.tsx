import { useState, useEffect, useCallback } from 'react';
import { FiDownload, FiTrash2, FiFilter } from 'react-icons/fi';
import type { Lead } from '@/types';
import { getLeads, exportLeads, clearData, getCategories } from '@/services/api';
import { useSellers } from '@/context/SellerContext';
import { useToast } from '@/components/ui/Toast';
import { ScoreBadge } from '@/components/ui/Badge';
import Badge from '@/components/ui/Badge';

const toIST = (iso: string) =>
  new Date(iso).toLocaleString('en-IN', {
    timeZone: 'Asia/Kolkata',
    day: '2-digit', month: '2-digit', year: '2-digit',
    hour: '2-digit', minute: '2-digit', hour12: true,
  });

export default function LeadsPage() {
  const { currentSellerId } = useSellers();
  const { toast } = useToast();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [categories, setCategories] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);

  const [clicked, setClicked] = useState('');
  const [city, setCity] = useState('');
  const [minScore, setMinScore] = useState('');
  const [category, setCategory] = useState('');
  const [appliedFilters, setAppliedFilters] = useState({ clicked: '', city: '', minScore: '', category: '' });

  const load = useCallback(async () => {
    const params: Record<string, string> = { page: String(page), limit: '25', sort: 'capturedAt', order: 'desc' };
    if (currentSellerId) params.sellerId = currentSellerId;
    if (appliedFilters.clicked) params.clicked = appliedFilters.clicked;
    if (appliedFilters.city) params.city = appliedFilters.city;
    if (appliedFilters.minScore) params.minScore = appliedFilters.minScore;
    if (appliedFilters.category) params.category = appliedFilters.category;
    try {
      const d = await getLeads(params);
      if (d.success) { setLeads(d.data || []); setTotalPages(d.pages || 1); }
    } catch {}
  }, [page, currentSellerId, appliedFilters]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    (async () => {
      try {
        const d = await getCategories(currentSellerId || undefined);
        if (d.success) setCategories(d.categories || []);
      } catch {}
    })();
  }, [currentSellerId]);

  const handleExport = async () => {
    try {
      const blob = await exportLeads(currentSellerId || undefined);
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `leadmagnet_export_${Date.now()}.csv`;
      document.body.appendChild(a); a.click(); a.remove();
      toast('Export downloaded', 'success');
    } catch { toast('Export failed', 'error'); }
  };

  const handleClear = async () => {
    if (!confirm('Clear all leads? This cannot be undone.')) return;
    try {
      const d = await clearData(currentSellerId || undefined);
      if (d.success) { toast('Leads cleared', 'success'); load(); }
    } catch { toast('Clear failed', 'error'); }
  };

  const applyFilters = () => {
    setPage(1);
    setAppliedFilters({ clicked, city, minScore, category });
    setShowFilters(false);
  };

  return (
    <div className="space-y-3">

      {/* ── Header ── */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between gap-2">
          <h3 className="font-semibold text-slate-900 text-sm sm:text-base">All Leads</h3>
          <div className="flex gap-1.5">
            <button onClick={() => setShowFilters(v => !v)}
              className={`flex items-center gap-1 text-xs font-medium px-2 sm:px-3 py-1.5 border rounded-lg transition-colors ${showFilters ? 'bg-accent text-white border-accent' : 'text-slate-600 border-slate-200 hover:bg-slate-50'}`}>
              <FiFilter size={13} /> <span className="hidden sm:inline">Filters</span>
            </button>
            <button onClick={handleExport}
              className="flex items-center gap-1 text-xs font-medium text-slate-600 px-2 sm:px-3 py-1.5 border border-slate-200 rounded-lg hover:bg-slate-50">
              <FiDownload size={13} /> <span className="hidden sm:inline">Export</span>
            </button>
            <button onClick={handleClear}
              className="flex items-center gap-1 text-xs font-medium text-red-500 px-2 sm:px-3 py-1.5 bg-red-50 border border-red-100 rounded-lg hover:bg-red-100">
              <FiTrash2 size={13} /> <span className="hidden sm:inline">Clear</span>
            </button>
          </div>
        </div>

        {/* Filters panel */}
        {showFilters && (
          <div className="px-4 py-3 bg-slate-50 border-b border-slate-200">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <select value={clicked} onChange={e => setClicked(e.target.value)}
                className="text-xs px-2.5 py-2 border border-slate-200 rounded-lg bg-white w-full">
                <option value="">All Status</option>
                <option value="true">Contacted</option>
                <option value="false">Not Contacted</option>
              </select>
              <input value={city} onChange={e => setCity(e.target.value)} placeholder="City…"
                className="text-xs px-2.5 py-2 border border-slate-200 rounded-lg w-full" />
              <input value={minScore} onChange={e => setMinScore(e.target.value)} placeholder="Min score" type="number" min={0} max={100}
                className="text-xs px-2.5 py-2 border border-slate-200 rounded-lg w-full" />
              <select value={category} onChange={e => setCategory(e.target.value)}
                className="text-xs px-2.5 py-2 border border-slate-200 rounded-lg bg-white w-full">
                <option value="">All Categories</option>
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <button onClick={applyFilters}
              className="mt-2 w-full sm:w-auto text-xs font-semibold text-white bg-accent px-4 py-2 rounded-lg hover:bg-accent-hover">
              Apply Filters
            </button>
          </div>
        )}

        {/* ── Mobile card list ── */}
        <div className="sm:hidden divide-y divide-slate-100">
          {leads.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-sm">No leads found</div>
          ) : leads.map(l => (
            <div key={l._id} className="px-4 py-3 hover:bg-slate-50">
              <div className="flex items-start gap-2 justify-between">
                <div className="font-medium text-sm text-slate-900 truncate flex-1">{l.title || '—'}</div>
                <ScoreBadge score={l.score} />
              </div>
              <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400">
                <span>📍 {
  l.location?.city
    ?.replace(/Click here.*$/i, '')
    ?.replace(/View.*BuyLeads.*$/i, '')
    ?.replace(/BuyLeads.*$/i, '')
    ?.replace(/Shortlist.*$/i, '')
    ?.replace(/[^A-Za-z\s]/g, '')
    ?.replace(/\s+/g, ' ')
    ?.trim() || '—'
}</span>
                <span>🏷️ {l.detectedCategory || l.category || '—'}</span>
                {l.orderValue?.display && <span>💰 {l.orderValue.display}</span>}
              </div>
              <div className="mt-1.5 flex items-center gap-2">
                {l.status?.clicked ? <Badge variant="success">Contacted</Badge> : <Badge variant="muted">New</Badge>}
                <span className="text-[10px] text-slate-300 ml-auto">{l.capturedAt ? toIST(l.capturedAt) : '—'}</span>
              </div>
            </div>
          ))}
        </div>

        {/* ── Desktop/tablet table ── */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <th className="px-4 py-2.5">Title</th>
                <th className="px-4 py-2.5">City</th>
                <th className="px-4 py-2.5 hidden md:table-cell">Category</th>
                <th className="px-4 py-2.5">Score</th>
                <th className="px-4 py-2.5 hidden lg:table-cell">Order Value</th>
                <th className="px-4 py-2.5">Contacted</th>
                <th className="px-4 py-2.5">Captured (IST)</th>
              </tr>
            </thead>
            <tbody>
              {leads.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-10 text-slate-400">No leads found</td></tr>
              ) : leads.map(l => (
                <tr key={l._id} className="border-t border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-2.5 max-w-[180px] truncate" title={l.title}>{l.title || '—'}</td>
                  <td className="px-4 py-2.5 text-slate-500">{
  l.location?.city
    ?.replace(/Click here.*$/i, '')
    ?.replace(/View.*BuyLeads.*$/i, '')
    ?.replace(/BuyLeads.*$/i, '')
    ?.replace(/Shortlist.*$/i, '')
    ?.replace(/[^A-Za-z\s]/g, '')
    ?.replace(/\s+/g, ' ')
    ?.trim() || '—'
}</td>
                  <td className="px-4 py-2.5 text-xs hidden md:table-cell">{l.detectedCategory || l.category || '—'}</td>
                  <td className="px-4 py-2.5"><ScoreBadge score={l.score} /></td>
                  <td className="px-4 py-2.5 hidden lg:table-cell text-xs">{l.orderValue?.display || '—'}</td>
                  <td className="px-4 py-2.5">
                    {l.status?.clicked ? <Badge variant="success">Yes</Badge> : <Badge variant="muted">No</Badge>}
                  </td>
                  <td className="px-4 py-2.5 text-xs text-slate-400">
                    {l.capturedAt ? toIST(l.capturedAt) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* ── Pagination ── */}
        {totalPages > 1 && (
          <div className="px-4 py-3 border-t border-slate-200 flex items-center justify-center gap-1 flex-wrap">
            <button disabled={page <= 1} onClick={() => setPage(p => p - 1)}
              className="px-3 py-1.5 text-xs border border-slate-200 rounded-lg disabled:opacity-40 hover:bg-slate-50">← Prev</button>
            {(() => {
              const windowSize = 5;
              const half = Math.floor(windowSize / 2);
              let start = Math.max(1, page - half);
              let end = Math.min(totalPages, start + windowSize - 1);
              start = Math.max(1, end - windowSize + 1);
              return Array.from({ length: end - start + 1 }, (_, i) => start + i).map(n => (
                <button key={n} onClick={() => setPage(n)}
                  className={`px-3 py-1.5 text-xs border rounded-lg ${n === page ? 'bg-accent text-white border-accent' : 'border-slate-200 hover:bg-slate-50'}`}>{n}</button>
              ));
            })()}
            <button disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}
              className="px-3 py-1.5 text-xs border border-slate-200 rounded-lg disabled:opacity-40 hover:bg-slate-50">Next →</button>
          </div>
        )}
      </div>
    </div>
  );
}
