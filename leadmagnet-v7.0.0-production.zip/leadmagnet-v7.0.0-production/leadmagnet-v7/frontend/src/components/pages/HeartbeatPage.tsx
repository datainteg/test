import { useState, useEffect, useCallback } from 'react';
import { FiRefreshCw, FiWifi, FiWifiOff } from 'react-icons/fi';
import type { Heartbeat } from '@/types';
import { getHeartbeats } from '@/services/api';

const toIST = (iso: string) =>
  new Date(iso).toLocaleTimeString('en-IN', {
    timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true,
  });

export default function HeartbeatPage() {
  const [heartbeats, setHeartbeats] = useState<Heartbeat[]>([]);

  const load = useCallback(async () => {
    try { const d = await getHeartbeats(); if (d.success) setHeartbeats(d.heartbeats || []); } catch {}
  }, []);

  useEffect(() => { load(); const t = setInterval(load, 15000); return () => clearInterval(t); }, [load]);

  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
      <div className="px-4 sm:px-5 py-3 sm:py-4 border-b border-slate-200 flex items-center justify-between">
        <h3 className="font-semibold text-slate-900 text-sm sm:text-base">Extension Heartbeat</h3>
        <button onClick={load} className="flex items-center gap-1.5 text-xs font-medium text-slate-500 px-3 py-1.5 border border-slate-200 rounded-lg hover:bg-slate-50">
          <FiRefreshCw size={13} /> Refresh
        </button>
      </div>

      {/* Mobile cards */}
      <div className="sm:hidden divide-y divide-slate-100">
        {heartbeats.length === 0 ? (
          <div className="text-center py-10 text-slate-400 text-sm">No heartbeat data</div>
        ) : heartbeats.map(hb => (
          <div key={hb.sellerId} className="px-4 py-3">
            <div className="flex items-center justify-between gap-2">
              <code className="text-xs text-slate-600 font-mono truncate flex-1">{hb.sellerId}</code>
              <div className={`flex items-center gap-1 text-xs font-semibold ${hb.isAlive ? 'text-emerald-600' : 'text-red-500'}`}>
                {hb.isAlive ? <FiWifi size={13} /> : <FiWifiOff size={13} />}
                {hb.isAlive ? 'Alive' : 'Dead'}
              </div>
            </div>
            <div className="mt-1.5 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-slate-400">
              <span>Phase: <span className="text-slate-600 font-medium">{hb.phase || '—'}</span></span>
              <span>Pings: <span className="text-slate-600 font-medium">{hb.pingCount || 0}</span></span>
              {hb.lastPing && (
                <span>Last: <span className="text-slate-600 font-medium">{toIST(hb.lastPing)} IST</span>
                  {hb.secondsSinceLastPing != null && <span className="text-slate-300"> ({hb.secondsSinceLastPing}s ago)</span>}
                </span>
              )}
            </div>
            {hb.tabUrl && (
              <div className="mt-1 text-[10px] text-slate-300 truncate">{hb.tabUrl}</div>
            )}
          </div>
        ))}
      </div>

      {/* Desktop table */}
      <div className="hidden sm:block overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
              <th className="px-4 py-2.5">Seller</th>
              <th className="px-4 py-2.5">Status</th>
              <th className="px-4 py-2.5">Phase</th>
              <th className="px-4 py-2.5">Last Ping (IST)</th>
              <th className="px-4 py-2.5 hidden md:table-cell">Pings</th>
              <th className="px-4 py-2.5 hidden lg:table-cell">Tab URL</th>
            </tr>
          </thead>
          <tbody>
            {heartbeats.length === 0 ? (
              <tr><td colSpan={6} className="text-center py-10 text-slate-400">No heartbeat data</td></tr>
            ) : heartbeats.map(hb => (
              <tr key={hb.sellerId} className="border-t border-slate-100 hover:bg-slate-50">
                <td className="px-4 py-2.5 font-mono text-xs">{hb.sellerId}</td>
                <td className="px-4 py-2.5">
                  <span className={`flex items-center gap-1 font-semibold text-xs ${hb.isAlive ? 'text-emerald-600' : 'text-red-500'}`}>
                    {hb.isAlive ? <FiWifi size={12} /> : <FiWifiOff size={12} />}
                    {hb.isAlive ? 'Alive' : 'Dead'}
                  </span>
                </td>
                <td className="px-4 py-2.5 text-xs text-slate-500">{hb.phase || '—'}</td>
                <td className="px-4 py-2.5 text-xs text-slate-500">
                  {hb.lastPing ? toIST(hb.lastPing) : '—'}
                  {hb.secondsSinceLastPing != null && <span className="text-slate-300 ml-1">({hb.secondsSinceLastPing}s ago)</span>}
                </td>
                <td className="px-4 py-2.5 text-xs hidden md:table-cell">{hb.pingCount || 0}</td>
                <td className="px-4 py-2.5 text-xs text-slate-400 max-w-[200px] truncate hidden lg:table-cell" title={hb.tabUrl}>{hb.tabUrl || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
