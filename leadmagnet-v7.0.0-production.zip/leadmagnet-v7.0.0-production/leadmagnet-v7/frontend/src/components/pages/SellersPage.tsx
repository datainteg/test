import { useState } from 'react';
import { FiPlus, FiTrash2, FiToggleLeft, FiToggleRight } from 'react-icons/fi';
import { useSellers } from '@/context/SellerContext';
import { createSeller, updateSeller, deleteSeller } from '@/services/api';
import { useToast } from '@/components/ui/Toast';
import Modal from '@/components/ui/Modal';
import Badge from '@/components/ui/Badge';

export default function SellersPage() {
  const { sellers, refresh } = useSellers();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [customId, setCustomId] = useState('');

  const handleCreate = async () => {
    if (!name.trim()) { toast('Seller name required', 'error'); return; }
    const d = await createSeller(name, customId || undefined);
    if (d.success) { toast('Seller created', 'success'); setOpen(false); setName(''); setCustomId(''); refresh(); }
    else toast(d.error || 'Failed', 'error');
  };

  const handleToggle = async (sellerId: string, currentActive: boolean) => {
    const d = await updateSeller(sellerId, { active: !currentActive });
    if (d.success) { toast(currentActive ? 'Seller disabled' : 'Seller enabled', 'success'); refresh(); }
    else toast(d.error || 'Failed', 'error');
  };

  const handleDelete = async (sellerId: string, sellerName: string) => {
    if (!confirm(`Delete seller "${sellerName}" (${sellerId})?\n\nThis will also delete ALL leads and data for this seller. This cannot be undone.`)) return;
    const d = await deleteSeller(sellerId);
    if (d.success) { toast('Seller deleted', 'success'); refresh(); }
    else toast(d.error || 'Failed', 'error');
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
      {/* Header */}
      <div className="px-4 sm:px-5 py-3 sm:py-4 border-b border-slate-200 flex items-center justify-between gap-2">
        <div className="min-w-0">
          <h3 className="font-semibold text-slate-900 text-sm sm:text-base">Seller Profiles</h3>
          <p className="text-xs text-slate-400 mt-0.5 hidden sm:block">{sellers.length} seller{sellers.length !== 1 ? 's' : ''} · One user can manage multiple profiles</p>
        </div>
        <button onClick={() => setOpen(true)} className="flex items-center gap-1.5 text-xs font-semibold text-white bg-accent px-3 py-1.5 rounded-lg hover:bg-accent-hover flex-shrink-0">
          <FiPlus size={14} /> <span className="hidden sm:inline">New Seller</span><span className="sm:hidden">New</span>
        </button>
      </div>

      {/* Mobile card list */}
      <div className="sm:hidden divide-y divide-slate-100">
        {sellers.length === 0 ? (
          <div className="text-center py-10 text-slate-400 text-sm">No sellers yet. Create one to get started.</div>
        ) : sellers.map(s => {
          const isActive = s.active !== false;
          const cats = s.keywordCategories || { category: [], city: [], value: [] };
          return (
            <div key={s.sellerId} className="px-4 py-3">
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="font-semibold text-slate-900 text-sm truncate">{s.name || 'Unnamed'}</div>
                  <code className="text-[10px] text-slate-400">{s.sellerId}</code>
                </div>
                <Badge variant={isActive ? 'success' : 'danger'}>{isActive ? 'Active' : 'Off'}</Badge>
              </div>
              <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                {cats.category?.length > 0 && <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-indigo-50 text-indigo-600">{cats.category.length} category</span>}
                {cats.city?.length > 0 && <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-600">{cats.city.length} city</span>}
                {cats.value?.length > 0 && <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-600">{cats.value.length} value</span>}
              </div>
              <div className="flex gap-2 mt-2">
                <button onClick={() => handleToggle(s.sellerId, isActive)}
                  className={`flex-1 flex items-center justify-center gap-1 text-xs font-medium py-1.5 rounded-lg border transition-colors ${isActive ? 'text-amber-600 border-amber-200 bg-amber-50' : 'text-emerald-600 border-emerald-200 bg-emerald-50'}`}>
                  {isActive ? <FiToggleRight size={14} /> : <FiToggleLeft size={14} />}
                  {isActive ? 'Disable' : 'Enable'}
                </button>
                <button onClick={() => handleDelete(s.sellerId, s.name || s.sellerId)}
                  className="flex-1 flex items-center justify-center gap-1 text-xs font-medium py-1.5 rounded-lg border text-red-500 border-red-200 bg-red-50">
                  <FiTrash2 size={13} /> Delete
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Desktop table */}
      <div className="hidden sm:block overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
              <th className="px-4 py-2.5">Name</th>
              <th className="px-4 py-2.5">Seller ID</th>
              <th className="px-4 py-2.5">Status</th>
              <th className="px-4 py-2.5">Keywords</th>
              <th className="px-4 py-2.5 hidden lg:table-cell">Extension</th>
              <th className="px-4 py-2.5 hidden md:table-cell">Created</th>
              <th className="px-4 py-2.5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {sellers.length === 0 ? (
              <tr><td colSpan={7} className="text-center py-10 text-slate-400">No sellers yet. Create one to get started.</td></tr>
            ) : sellers.map(s => {
              const isActive = s.active !== false;
              const cats = s.keywordCategories || { category: [], city: [], value: [] };
              return (
                <tr key={s.sellerId} className="border-t border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-3 font-semibold text-slate-900">{s.name || 'Unnamed'}</td>
                  <td className="px-4 py-3">
                    <code className="text-xs text-slate-500 bg-slate-50 px-1.5 py-0.5 rounded">{s.sellerId}</code>
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant={isActive ? 'success' : 'danger'}>{isActive ? 'Active' : 'Disabled'}</Badge>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {cats.category?.length > 0 && <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-indigo-50 text-indigo-600">{cats.category.length} category</span>}
                      {cats.city?.length > 0 && <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-600">{cats.city.length} city</span>}
                      {cats.value?.length > 0 && <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-600">{cats.value.length} value</span>}
                      {(s.keywords || []).length === 0 && <span className="text-xs text-slate-300">None</span>}
                    </div>
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell">
                    {s.extensionId
                      ? <span className="text-[10px] font-mono text-slate-400">{s.extensionId.substring(0, 12)}…</span>
                      : <span className="text-xs text-slate-300">Not linked</span>}
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-400 hidden md:table-cell">
                    {s.createdAt ? new Date(s.createdAt).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' }) : '—'}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => handleToggle(s.sellerId, isActive)}
                        className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-lg border transition-colors ${isActive ? 'text-amber-600 border-amber-200 bg-amber-50 hover:bg-amber-100' : 'text-emerald-600 border-emerald-200 bg-emerald-50 hover:bg-emerald-100'}`}>
                        {isActive ? <FiToggleRight size={14} /> : <FiToggleLeft size={14} />}
                        {isActive ? 'Disable' : 'Enable'}
                      </button>
                      <button onClick={() => handleDelete(s.sellerId, s.name || s.sellerId)}
                        className="flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-lg border text-red-500 border-red-200 bg-red-50 hover:bg-red-100 transition-colors">
                        <FiTrash2 size={13} /> Delete
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Create New Seller" footer={
        <button onClick={handleCreate} className="px-4 py-2 bg-accent text-white text-sm font-semibold rounded-lg hover:bg-accent-hover">Create</button>
      }>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-500 mb-1">Seller Name</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. My Store"
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-accent focus:ring-2 focus:ring-indigo-50" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-500 mb-1">Custom ID (optional)</label>
            <input value={customId} onChange={e => setCustomId(e.target.value)} placeholder="auto-generated if empty"
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-accent focus:ring-2 focus:ring-indigo-50" />
          </div>
          <p className="text-xs text-slate-400">Each seller profile captures leads independently.</p>
        </div>
      </Modal>
    </div>
  );
}
