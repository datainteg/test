import { useState, useMemo } from 'react';
import { FiPlus, FiX, FiChevronDown } from 'react-icons/fi';
import { useSellers } from '@/context/SellerContext';
import { addKeyword, removeKeyword } from '@/services/api';
import { useToast } from '@/components/ui/Toast';

const groups = [
  {
    key: 'category' as const,
    label: 'Category Keywords',
    icon: '🏷️',
    desc: 'IndiaMART category names — e.g. Swings, Indoor Playground, Artificial Grass'
  },
  {
    key: 'city' as const,
    label: 'City Keywords',
    icon: '📍',
    desc: 'Target cities, states, regions'
  },
  {
    key: 'value' as const,
    label: 'Value Keywords',
    icon: '💰',
    desc: 'Prices, budgets, order values'
  },
];

const tagStyle = {
  category: 'bg-indigo-50 text-indigo-600 border-indigo-100',
  city: 'bg-emerald-50 text-emerald-600 border-emerald-100',
  value: 'bg-amber-50 text-amber-600 border-amber-100',
};

/* ✅ Safe array helper — never undefined */
function arr(v: any): string[] {
  return Array.isArray(v) ? v : [];
}

export default function KeywordsPage() {
  const { sellers, refresh } = useSellers();
  const { toast } = useToast();

  const [selectedSellerId, setSelectedSellerId] = useState('');
  const [kw, setKw] = useState('');
  const [cat, setCat] = useState<'category' | 'city' | 'value'>('category');

  const selectedSeller = useMemo(
    () => sellers.find(s => s.sellerId === selectedSellerId),
    [sellers, selectedSellerId]
  );

  const cats = {
    category: arr(selectedSeller?.keywordCategories?.category),
    city: arr(selectedSeller?.keywordCategories?.city),
    value: arr(selectedSeller?.keywordCategories?.value),
  };

  const totalKw = arr(selectedSeller?.keywords).length;

  const handleAdd = async () => {
    if (!kw.trim()) return toast('Enter a keyword', 'error');
    if (!selectedSellerId) return toast('Select a seller first', 'error');

    const sanitized = kw
      .replace(/<[^>]*>/g, '')
      .replace(/[<>"'`]/g, '')
      .trim()
      .toLowerCase()
      .substring(0, 100);

    if (!sanitized) return toast('Invalid keyword', 'error');

    try {
      const d = await addKeyword(selectedSellerId, sanitized, cat);
      if (d.success) {
        toast('Keyword added', 'success');
        setKw('');
        refresh();
      } else toast(d.error || 'Failed', 'error');
    } catch (e) {
      toast('Error: ' + (e instanceof Error ? e.message : 'Unknown'), 'error');
    }
  };

  const handleRemove = async (keyword: string) => {
    if (!selectedSellerId) return;
    try {
      const d = await removeKeyword(selectedSellerId, keyword);
      if (d.success) {
        toast('Removed', 'success');
        refresh();
      } else toast(d.error || 'Failed', 'error');
    } catch (e) {
      toast('Error: ' + (e instanceof Error ? e.message : 'Unknown'), 'error');
    }
  };

  return (
    <div className="space-y-4">

      {/* ───────── Seller Selector ───────── */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-5">
        <label className="block text-xs font-semibold text-slate-500 uppercase mb-1.5">
          Select Seller to Manage Keywords
        </label>

        <div className="relative">
          <select
            value={selectedSellerId}
            onChange={e => setSelectedSellerId(e.target.value)}
            className="w-full px-3 py-2.5 border border-slate-200 rounded-lg text-sm bg-white appearance-none pr-8"
          >
            <option value="">— Choose a seller —</option>
            {sellers.map(s => (
              <option key={s.sellerId} value={s.sellerId}>
                {s.name || 'Unnamed'} ({s.sellerId}) — {arr(s.keywords).length} keywords
              </option>
            ))}
          </select>

          <FiChevronDown
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
            size={16}
          />
        </div>

        {selectedSeller && (
          <div className="mt-3 flex items-center gap-3 text-xs text-slate-500">
            <span className="font-semibold text-slate-900">
              {selectedSeller.name}
            </span>

            <span className="px-2 py-0.5 rounded-full bg-slate-100">
              {totalKw} keywords
            </span>

            <span
              className={`px-2 py-0.5 rounded-full ${
                selectedSeller.active !== false
                  ? 'bg-emerald-50 text-emerald-600'
                  : 'bg-red-50 text-red-500'
              }`}
            >
              {selectedSeller.active !== false ? 'Active' : 'Disabled'}
            </span>
          </div>
        )}
      </div>

      {/* ───────── Keyword Manager ───────── */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-5">

        {/* Add row */}
        <div className="flex flex-col sm:flex-row gap-2 mb-6">
          <input
            value={kw}
            onChange={e => setKw(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleAdd()}
            placeholder={selectedSellerId ? 'Add keyword…' : 'Select a seller first'}
            disabled={!selectedSellerId}
            className="flex-1 px-3 py-2 border rounded-lg text-sm"
          />

          <select
            value={cat}
            onChange={e => setCat(e.target.value as any)}
            disabled={!selectedSellerId}
            className="px-3 py-2 border rounded-lg text-sm bg-white"
          >
            <option value="category">🏷️ Category</option>
            <option value="city">📍 City</option>
            <option value="value">💰 Value</option>
          </select>

          <button
            onClick={handleAdd}
            disabled={!selectedSellerId}
            className="flex items-center gap-1 px-3 py-2 bg-accent text-white rounded-lg"
          >
            <FiPlus size={14} /> Add
          </button>
        </div>

        {!selectedSellerId ? (
          <div className="text-center py-12 text-slate-400">
            Select a seller above to manage keywords
          </div>
        ) : (
          <div className="space-y-6">
            {groups.map(g => {
              const kws = arr(cats[g.key]);

              return (
                <div key={g.key} className="border rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <span>{g.icon}</span>
                    <span className="font-semibold">{g.label}</span>
                    <span className="ml-2 text-xs bg-slate-100 px-2 rounded-full">
                      {kws.length}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {kws.length === 0 ? (
                      <span className="text-xs text-slate-300 italic">
                        No {g.key} keywords yet
                      </span>
                    ) : (
                      kws.map(k => (
                        <span
                          key={k}
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs border ${tagStyle[g.key]}`}
                        >
                          {k}
                          <button onClick={() => handleRemove(k)}>
                            <FiX size={12} />
                          </button>
                        </span>
                      ))
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ───────── Responsive Summary ───────── */}
      {sellers.length > 1 && (
        <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">

          <div className="px-5 py-3 border-b border-slate-200">
            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              All Sellers — Keyword Summary
            </h4>
          </div>

          {/* 📱 Mobile Cards */}
          <div className="sm:hidden divide-y divide-slate-100">
            {sellers.map(s => {
              const c = {
                category: arr(s.keywordCategories?.category),
                city: arr(s.keywordCategories?.city),
                value: arr(s.keywordCategories?.value),
              };

              const total = arr(s.keywords).length;
              const isSelected = s.sellerId === selectedSellerId;

              return (
                <div
                  key={s.sellerId}
                  onClick={() => setSelectedSellerId(s.sellerId)}
                  className={`px-4 py-3 cursor-pointer ${
                    isSelected ? 'bg-indigo-50' : 'hover:bg-slate-50'
                  }`}
                >
                  <div className="flex justify-between">
                    <div className="font-semibold text-sm text-slate-900">
                      {s.name || 'Unnamed'}
                    </div>
                    <div className="text-xs font-bold text-slate-700">
                      {total} total
                    </div>
                  </div>

                  <div className="mt-1 flex flex-wrap gap-x-4 text-xs text-slate-500">
                    <span>🏷️ {c.category.length}</span>
                    <span>📍 {c.city.length}</span>
                    <span>💰 {c.value.length}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* 💻 Desktop Table */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 font-semibold text-left text-slate-500 uppercase">
                  <th className="px-4 py-2">Seller</th>
                  <th className="px-4 py-2">Category</th>
                  <th className="px-4 py-2">City</th>
                  <th className="px-4 py-2">Value</th>
                  <th className="px-4 py-2">Total</th>
                </tr>
              </thead>

              <tbody>
                {sellers.map(s => {
                  const c = {
                    category: arr(s.keywordCategories?.category),
                    city: arr(s.keywordCategories?.city),
                    value: arr(s.keywordCategories?.value),
                  };

                  const total = arr(s.keywords).length;
                  const isSelected = s.sellerId === selectedSellerId;

                  return (
                    <tr
                      key={s.sellerId}
                      onClick={() => setSelectedSellerId(s.sellerId)}
                      className={`border-t cursor-pointer ${
                        isSelected ? 'bg-indigo-50' : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="px-4 py-2 font-semibold text-slate-700">
                        {s.name || 'Unnamed'}
                      </td>

                      <td className="px-4 py-2 text-indigo-600 font-semibold">
                        {c.category.length}
                      </td>

                      <td className="px-4 py-2 text-emerald-600 font-semibold">
                        {c.city.length}
                      </td>

                      <td className="px-4 py-2 text-amber-600 font-semibold">
                        {c.value.length}
                      </td>

                      <td className="px-4 py-2 font-bold text-slate-900">
                        {total}
                      </td>
                    </tr>
                  );
                })}
              </tbody>

            </table>
          </div>

        </div>
      )}

    </div>
  );
}