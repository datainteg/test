import { useState, useEffect, useCallback } from 'react';
import { FiUsers, FiCheckCircle, FiClock, FiZap, FiStar, FiDroplet } from 'react-icons/fi';
import type { Stats, Lead } from '@/types';
import { getStats, getLeads } from '@/services/api';
import { useSellers } from '@/context/SellerContext';
import { ScoreBadge } from '@/components/ui/Badge';
import Badge from '@/components/ui/Badge';

const statCards = [
  { key: 'total',   label: 'Total Leads', icon: FiUsers,       cls: 'bg-indigo-50 text-accent' },
  { key: 'clicked', label: 'Contacted',    icon: FiCheckCircle, cls: 'bg-emerald-50 text-emerald-600' },
  { key: 'today',   label: 'Today',        icon: FiClock,       cls: 'bg-amber-50 text-amber-600' },
  { key: 'hot',     label: 'Hot Leads',    icon: FiZap,         cls: 'bg-red-50 text-red-600' },
  { key: 'warm',    label: 'Warm Leads',   icon: FiStar,        cls: 'bg-amber-50 text-amber-600' },
  { key: 'cool',    label: 'Cool Leads',   icon: FiDroplet,     cls: 'bg-blue-50 text-blue-600' },
];

const toIST = (iso: string) =>
  new Date(iso).toLocaleString('en-IN', {
    timeZone: 'Asia/Kolkata',
    dateStyle: 'short',
    timeStyle: 'short',
  });

export default function OverviewPage() {
  const { currentSellerId } = useSellers();
  const [stats, setStats] = useState<Stats>({ total: 0, clicked: 0, today: 0, hot: 0, warm: 0, cool: 0 });
  const [recentLeads, setRecentLeads] = useState<Lead[]>([]);

  const load = useCallback(async () => {
    try {
      const sd = await getStats(currentSellerId || undefined);
      if (sd.success) setStats(sd.stats);
      const ld = await getLeads({
        limit: '10', sort: 'capturedAt', order: 'desc',
        ...(currentSellerId ? { sellerId: currentSellerId } : {})
      });
      if (ld.success) setRecentLeads(ld.data || []);
    } catch {}
  }, [currentSellerId]);

  useEffect(() => { load(); const t = setInterval(load, 10000); return () => clearInterval(t); }, [load]);

  return (
    <div className="space-y-4 sm:space-y-6">

      {/* ── Stat Cards ── */}
      <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-3">
        {statCards.map(c => {
          const Icon = c.icon;
          const val = stats[c.key as keyof Stats] ?? 0;
          return (
            <div key={c.key} className="bg-white border border-slate-200 rounded-xl p-3 sm:p-4 flex items-center gap-3 shadow-sm hover:shadow-md transition-shadow">
              <div className={`w-9 h-9 sm:w-10 sm:h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${c.cls}`}>
                <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <div className="min-w-0">
                <div className="text-xl sm:text-2xl font-bold text-slate-900 leading-tight">{val}</div>
                <div className="text-[10px] sm:text-xs text-slate-400 mt-0.5 truncate">{c.label}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ── Recent Leads ── */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-semibold text-slate-900 text-sm sm:text-base">Recent Leads</h3>
          <button onClick={load} className="text-xs font-medium text-slate-500 hover:text-accent px-3 py-1.5 border border-slate-200 rounded-lg">
            Refresh
          </button>
        </div>

        {/* Mobile card list */}
        <div className="sm:hidden divide-y divide-slate-100">
          {recentLeads.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-sm">No leads yet</div>
          ) : recentLeads.map(l => (
            <div key={l._id} className="px-4 py-3">
              <div className="flex items-start justify-between gap-2">
                <div className="font-medium text-sm text-slate-900 truncate flex-1">{l.title || '—'}</div>
                <ScoreBadge score={l.score} />
              </div>
              <div className="flex items-center gap-3 mt-1.5">
                <span className="text-xs text-slate-400">{
  l.location?.city
    ?.replace(/Click here.*$/i, '')
    ?.replace(/View.*BuyLeads.*$/i, '')
    ?.replace(/BuyLeads.*$/i, '')
    ?.replace(/Shortlist.*$/i, '')
    ?.replace(/[^A-Za-z\s]/g, '')
    ?.replace(/\s+/g, ' ')
    ?.trim() || '—'
}</span>
                {l.status?.clicked
                  ? <Badge variant="success">Contacted</Badge>
                  : <Badge variant="muted">New</Badge>}
                <span className="text-xs text-slate-300 ml-auto">
                  {l.capturedAt ? toIST(l.capturedAt) : '—'}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Desktop/tablet table */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <th className="px-4 py-2.5">Title</th>
                <th className="px-4 py-2.5">City</th>
                <th className="px-4 py-2.5">Score</th>
                <th className="px-4 py-2.5">Status</th>
                <th className="px-4 py-2.5">Time (IST)</th>
              </tr>
            </thead>
            <tbody>
              {recentLeads.length === 0 ? (
                <tr><td colSpan={5} className="text-center py-8 text-slate-400">No leads yet</td></tr>
              ) : recentLeads.map(l => (
                <tr key={l._id} className="border-t border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-2.5 max-w-[200px] truncate" title={l.title}>{l.title || '—'}</td>
                  <td className="px-4 py-2.5 text-slate-500">{
  l.location?.city
    ?.replace(/Click here.*$/i, '')
    ?.replace(/View.*BuyLeads.*$/i, '')
    ?.replace(/BuyLeads.*$/i, '')
    ?.replace(/Shortlist.*$/i, '')
    ?.replace(/[^A-Za-z\s]/g, '')
    ?.replace(/\s+/g, ' ')
    ?.trim() || '—'
}</td>
                  <td className="px-4 py-2.5"><ScoreBadge score={l.score} /></td>
                  <td className="px-4 py-2.5">
                    {l.status?.clicked ? <Badge variant="success">Contacted</Badge> : <Badge variant="muted">New</Badge>}
                  </td>
                  <td className="px-4 py-2.5 text-slate-400 text-xs">
                    {l.capturedAt ? toIST(l.capturedAt) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
