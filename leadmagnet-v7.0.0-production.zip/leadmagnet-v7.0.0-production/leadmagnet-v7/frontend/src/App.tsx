import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useSellers } from '@/context/SellerContext';
import { checkHealth } from '@/services/api';
import LoginPage from '@/components/auth/LoginPage';
import Sidebar from '@/components/layout/Sidebar';
import OverviewPage from '@/components/pages/OverviewPage';
import LeadsPage from '@/components/pages/LeadsPage';
import SellersPage from '@/components/pages/SellersPage';
import KeywordsPage from '@/components/pages/KeywordsPage';
import UsersPage from '@/components/pages/UsersPage';
import HeartbeatPage from '@/components/pages/HeartbeatPage';
import StatusDot from '@/components/ui/StatusDot';

const pageTitles: Record<string, string> = {
  overview: 'Overview', leads: 'Leads', sellers: 'Sellers',
  keywords: 'Keywords', users: 'Users', heartbeat: 'Heartbeat',
};

function ISTClock() {
  const [time, setTime] = useState('');
  useEffect(() => {
    const tick = () => {
      const now = new Date().toLocaleTimeString('en-IN', {
        timeZone: 'Asia/Kolkata',
        hour: '2-digit', minute: '2-digit', second: '2-digit',
        hour12: true,
      });
      setTime(now);
    };
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="hidden sm:flex items-center gap-1.5 text-xs font-mono text-slate-500 bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-lg whitespace-nowrap">
      <span>🕐</span>
      <span>{time}</span>
      <span className="text-[10px] text-slate-400 font-sans font-semibold">IST</span>
    </div>
  );
}

export default function App() {
  const { user, loading } = useAuth();
  const { sellers, currentSellerId, setCurrentSellerId } = useSellers();
  const [page, setPage] = useState('overview');
  const [online, setOnline] = useState(false);

  useEffect(() => {
    checkHealth().then(setOnline);
    const t = setInterval(() => checkHealth().then(setOnline), 30000);
    return () => clearInterval(t);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-slate-400 text-sm">Loading…</div>
      </div>
    );
  }

  if (!user) return <LoginPage />;

  const topbar = (
    <div className="flex items-center w-full gap-2 sm:gap-3">
      {/* Left — Seller select */}
      <div className="flex items-center gap-1.5 flex-shrink-0">
        <label className="text-slate-400 font-medium text-xs whitespace-nowrap hidden md:inline">Seller:</label>
        <select
          value={currentSellerId || ''}
          onChange={e => setCurrentSellerId(e.target.value || null)}
          className="text-xs px-2 py-1.5 border border-slate-200 rounded-lg bg-white w-[110px] sm:w-[140px] focus:outline-none focus:border-accent"
        >
          <option value="">All Sellers</option>
          {sellers.map(s => <option key={s.sellerId} value={s.sellerId}>{s.name || s.sellerId}</option>)}
        </select>
      </div>

      {/* Center — Page title */}
      <h2 className="flex-1 text-center text-sm sm:text-base font-bold text-slate-900 truncate px-1">
        {pageTitles[page] || 'Dashboard'}
      </h2>

      {/* Right — IST clock + status */}
      <div className="flex items-center gap-2 flex-shrink-0">
        <ISTClock />
        <div className="flex items-center gap-1 text-xs text-slate-400">
          <StatusDot online={online} />
          <span className="hidden md:inline">{online ? 'Online' : 'Offline'}</span>
        </div>
      </div>
    </div>
  );

  const renderPage = () => {
    switch (page) {
      case 'overview':  return <OverviewPage />;
      case 'leads':     return <LeadsPage />;
      case 'sellers':   return <SellersPage />;
      case 'keywords':  return <KeywordsPage />;
      case 'users':     return <UsersPage />;
      case 'heartbeat': return <HeartbeatPage />;
      default:          return <OverviewPage />;
    }
  };

  return (
    <Sidebar activePage={page} onNavigate={setPage} topbar={topbar}>
      {renderPage()}
    </Sidebar>
  );
}
