const API_BASE = window.location.origin;

function getToken(): string | null {
  const stored = localStorage.getItem('lm_auth');
  if (!stored) return null;
  try { return JSON.parse(stored).token; } catch { return null; }
}

async function authFetch(url: string, opts: RequestInit = {}): Promise<Response> {
  const token = getToken();
  if (!token) throw new Error('Not authenticated');
  const headers = new Headers(opts.headers || {});
  headers.set('Authorization', `Bearer ${token}`);
  return fetch(url, { ...opts, headers });
}

// ── Auth ──────────────────────────────────────────
export async function login(email: string, password: string) {
  const res = await fetch(`${API_BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  return res.json();
}

export async function getMe() {
  const res = await authFetch(`${API_BASE}/api/auth/me`);
  return res.json();
}

// ── Health ────────────────────────────────────────
export async function checkHealth(): Promise<boolean> {
  try {
    const res = await fetch(`${API_BASE}/api/health`);
    return res.ok;
  } catch { return false; }
}

// ── Stats ────────────────────────────────────────
export async function getStats(sellerId?: string) {
  let url = `${API_BASE}/api/stats`;
  if (sellerId) url += `?sellerId=${sellerId}`;
  const res = await authFetch(url);
  return res.json();
}

// ── Sellers ──────────────────────────────────────
export async function getSellers() {
  const res = await authFetch(`${API_BASE}/api/sellers`);
  return res.json();
}

export async function createSeller(name: string, sellerId?: string) {
  const res = await authFetch(`${API_BASE}/api/sellers`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, sellerId: sellerId || undefined }),
  });
  return res.json();
}

export async function updateSeller(sellerId: string, data: { name?: string; active?: boolean }) {
  const res = await authFetch(`${API_BASE}/api/sellers/${sellerId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function deleteSeller(sellerId: string) {
  const res = await authFetch(`${API_BASE}/api/sellers/${sellerId}`, {
    method: 'DELETE',
  });
  return res.json();
}

// ── Leads ────────────────────────────────────────
export async function getLeads(params: Record<string, string>) {
  const qs = new URLSearchParams(params).toString();
  const res = await authFetch(`${API_BASE}/api/leads?${qs}`);
  return res.json();
}

export async function exportLeads(sellerId?: string) {
  let url = `${API_BASE}/api/leads/export`;
  if (sellerId) url += `?sellerId=${sellerId}`;
  const res = await authFetch(url);
  if (!res.ok) throw new Error('Export failed');
  return res.blob();
}

export async function clearData(sellerId?: string) {
  const res = await authFetch(`${API_BASE}/api/data/clear`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sellerId }),
  });
  return res.json();
}

export async function getCategories(sellerId?: string) {
  let url = `${API_BASE}/api/leads/categories`;
  if (sellerId) url += `?sellerId=${sellerId}`;
  const res = await authFetch(url);
  return res.json();
}

// ── Keywords ─────────────────────────────────────
export async function addKeyword(sellerId: string, keyword: string, category: string) {
  const res = await authFetch(`${API_BASE}/api/sellers/${sellerId}/keywords`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ keyword, category }),
  });
  return res.json();
}

export async function removeKeyword(sellerId: string, keyword: string) {
  const res = await authFetch(`${API_BASE}/api/sellers/${sellerId}/keywords/${encodeURIComponent(keyword)}`, {
    method: 'DELETE',
  });
  return res.json();
}

// ── Users (admin) ────────────────────────────────
export async function getUsers() {
  const res = await authFetch(`${API_BASE}/api/auth/users`);
  return res.json();
}

export async function createUser(data: { email: string; password: string; name: string; role: string }) {
  const res = await authFetch(`${API_BASE}/api/auth/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function updateUser(userId: string, data: Record<string, unknown>) {
  const res = await authFetch(`${API_BASE}/api/auth/users/${userId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function deleteUser(userId: string) {
  const res = await authFetch(`${API_BASE}/api/auth/users/${userId}`, {
    method: 'DELETE',
  });
  return res.json();
}

// ── Heartbeats ───────────────────────────────────
export async function getHeartbeats() {
  const res = await authFetch(`${API_BASE}/api/heartbeat`);
  return res.json();
}
