/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // 10% Accent — Indigo
        accent: {
          DEFAULT: '#4F46E5',
          hover: '#4338CA',
          bg: '#EEF2FF',
          text: '#3730A3',
          50: '#EEF2FF',
        },
        // Semantic
        hot: { DEFAULT: '#DC2626', bg: '#FEF2F2' },
        warm: { DEFAULT: '#D97706', bg: '#FFFBEB' },
        cool: { DEFAULT: '#2563EB', bg: '#EFF6FF' },
      },
      fontFamily: {
        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
        mono: ['SF Mono', 'Consolas', 'monospace'],
      },
    },
  },
  plugins: [],
};
