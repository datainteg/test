#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# Lead Magnet v7.0.0 — Production Deploy Script
# Usage: bash deploy.sh
# ═══════════════════════════════════════════════════════════════
set -e

DOMAIN="leadmagnet.mlaics.com"
EMAIL="admin@mlaics.com"          # for Let's Encrypt cert notifications

echo ""
echo "🚀 Lead Magnet v7.0.0 — Production Deploy"
echo "   Domain : $DOMAIN"
echo "   Email  : $EMAIL"
echo ""

# ── Preflight check ─────────────────────────────────────────────
if [ ! -f "./backend/.env" ]; then
  echo "❌ ERROR: backend/.env not found!"
  echo "   Copy backend/.env.example to backend/.env and fill in values first."
  exit 1
fi

if grep -q "REPLACE_WITH" ./backend/.env; then
  echo "❌ ERROR: backend/.env still has placeholder values!"
  echo "   Set JWT_SECRET and ADMIN_PASSWORD before deploying."
  exit 1
fi

echo "✅ Preflight passed"
echo ""

# ── Step 1: Build + start with HTTP-only nginx ─────────────────
echo "▶ Step 1: Building images and starting HTTP-only stack..."
cp nginx/nginx.http-only.conf nginx/nginx.conf
docker compose build --no-cache
docker compose up -d nginx backend mongo
echo "   Waiting for services to come up..."
sleep 8

# ── Step 2: Issue SSL certificate ──────────────────────────────
echo ""
echo "▶ Step 2: Issuing SSL certificate from Let's Encrypt..."
docker compose run --rm certbot \
  certonly --webroot \
  --webroot-path=/var/www/certbot \
  --email "$EMAIL" \
  --agree-tos \
  --no-eff-email \
  -d "$DOMAIN"

# ── Step 3: Swap to HTTPS nginx config ─────────────────────────
echo ""
echo "▶ Step 3: Switching to HTTPS nginx config..."
cp nginx/nginx.ssl.conf nginx/nginx.conf

# ── Step 4: Reload nginx ────────────────────────────────────────
echo ""
echo "▶ Step 4: Reloading nginx with SSL..."
docker compose exec nginx nginx -s reload || docker compose restart nginx

# ── Step 5: Health check ─────────────────────────────────────────
echo ""
echo "▶ Step 5: Health check..."
sleep 3
curl -sf "https://$DOMAIN/api/health" && echo "" && echo "✅ Health check passed!" || echo "⚠️  Health check failed — check logs: docker compose logs backend"

echo ""
echo "════════════════════════════════════════════"
echo "✅ DEPLOYED!"
echo "   Dashboard : https://$DOMAIN/"
echo "   API Health: https://$DOMAIN/api/health"
echo ""
echo "   View logs : docker compose logs -f backend"
echo "   Stop all  : docker compose down"
echo "════════════════════════════════════════════"
echo ""
