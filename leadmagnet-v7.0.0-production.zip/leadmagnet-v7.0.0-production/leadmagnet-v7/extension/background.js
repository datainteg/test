/**
 * Lead Magnet — Background Service Worker
 * @author datainteg.io
 * @version 6.0.0
 * Auth: all API calls use JWT token from storage
 */
'use strict';

importScripts('config.js');

const FALLBACK_URL = (typeof LM_CONFIG !== 'undefined' && LM_CONFIG.API_URL) || 'http://localhost:3000';

async function getBackendUrl() {
  const r = await chrome.storage.local.get(['leadopticsSettings']);
  return r.leadopticsSettings?.backend?.url || FALLBACK_URL;
}

async function getAuthToken() {
  const r = await chrome.storage.local.get(['authToken']);
  return r.authToken || null;
}

async function authFetch(url, options = {}) {
  const token = await getAuthToken();
  if (!token) throw new Error('Not authenticated');
  options.headers = options.headers || {};
  options.headers['Authorization'] = 'Bearer ' + token;
  return fetch(url, options);
}

// ── INSTALL ──────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('[Lead Magnet] Installed:', details.reason);
  const r = await chrome.storage.local.get(['leadopticsSettings','leadopticsStats']);

  if (!r.leadopticsSettings) {
    await chrome.storage.local.set({
      leadopticsSettings: {
        autoClick: { enabled: false, clickDelay: 3, autoClosePopup: true, maxLeadAge: 5 },
        refresh:   { enabled: true, interval: 15 },
        backend:   { url: FALLBACK_URL }
      }
    });
  }
  if (!r.leadopticsStats) {
    await chrome.storage.local.set({
      leadopticsStats: { total: 0, clicked: 0, filtered: 0, today: 0, clickedToday: 0, lastDate: new Date().toDateString() }
    });
  }

  setupAlarms();
  chrome.action.setBadgeText({ text: '' });
  chrome.action.setBadgeBackgroundColor({ color: '#4F46E5' });

  if (details.reason === 'install' || details.reason === 'update') {
    setTimeout(registerExtension, 3000);
  }
});

// ── REGISTER ─────────────────────────────────────────────────
async function registerExtension() {
  try {
    const token = await getAuthToken();
    if (!token) { console.log('[Lead Magnet] Not logged in, skip registration'); return; }

    // Admin accounts — skip auto-registration entirely
    const stored = await chrome.storage.local.get(['authUser']);
    if (stored.authUser?.role === 'admin') {
      console.log('[Lead Magnet] Admin account — skipping auto seller registration');
      return;
    }

    const url = await getBackendUrl();
    const res = await authFetch(url + '/api/sellers/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ extensionId: chrome.runtime.id })
    });
    if (res.ok) {
      const d = await res.json();
      if (d.seller) {
        await chrome.storage.local.set({
          extensionId: chrome.runtime.id,
          selectedSellerId: d.seller.sellerId
        });
        console.log('[Lead Magnet] Registered. sellerId:', d.seller.sellerId);
      }
    }
  } catch (e) {
    console.log('[Lead Magnet] Registration failed:', e.message);
  }
}

// ── ALARMS ───────────────────────────────────────────────────
function setupAlarms() {
  chrome.alarms.clearAll();
  chrome.alarms.create('healthCheck', { periodInMinutes: 1 });
  chrome.alarms.create('dailyReset',  { periodInMinutes: 5 });
  chrome.alarms.create('keepAlive',   { periodInMinutes: 0.4 });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'healthCheck') performHealthCheck();
  if (alarm.name === 'dailyReset')  checkDailyReset();
  if (alarm.name === 'keepAlive') {
    chrome.runtime.getPlatformInfo(() => {});
    chrome.storage.local.get(['leadopticsStats'], () => {});
  }
});

async function performHealthCheck() {
  try {
    const url  = await getBackendUrl();
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), 5000);
    const res = await fetch(url + '/api/health', { signal: ctrl.signal });
    chrome.action.setBadgeBackgroundColor({ color: res.ok ? '#059669' : '#D97706' });
  } catch {
    chrome.action.setBadgeBackgroundColor({ color: '#DC2626' });
  }
  const s = await chrome.storage.local.get(['leadopticsStats']);
  const n = s.leadopticsStats?.total || 0;
  chrome.action.setBadgeText({ text: n > 0 ? (n > 999 ? '999+' : String(n)) : '' });
}

function checkDailyReset() {
  chrome.storage.local.get(['leadopticsStats'], (r) => {
    const stats = r.leadopticsStats || {};
    const today = new Date().toDateString();
    if (stats.lastDate !== today) {
      stats.today = 0;
      stats.clickedToday = 0;
      stats.lastDate = today;
      chrome.storage.local.set({ leadopticsStats: stats });
      console.log('[Lead Magnet] Daily stats reset for', today);
    }
  });
}

// ── MESSAGES ─────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'REGISTER_EXTENSION') {
    registerExtension().then(() => sendResponse({ success: true }));
    return true;
  }
  if (msg.action === 'STATS_UPDATE') {
    const n = msg.stats?.total || 0;
    chrome.action.setBadgeText({ text: n > 0 ? (n > 999 ? '999+' : String(n)) : '' });
    chrome.storage.local.set({ leadopticsStats: msg.stats });
    sendResponse({ success: true });
    return true;
  }
  if (msg.action === 'LEAD_CLICKED') {
    chrome.notifications.create({
      type: 'basic', iconUrl: 'icons/icon128.png',
      title: '✅ Lead Contacted — Lead Magnet',
      message: 'Auto-clicked: ' + ((msg.leadData?.title || 'Unknown').substring(0, 60)),
      priority: 1
    });
    sendResponse({ success: true });
    return true;
  }
  if (msg.action === 'BACKEND_STATUS') {
    chrome.action.setBadgeBackgroundColor({ color: msg.online ? '#059669' : '#DC2626' });
    sendResponse({ success: true });
    return true;
  }
  if (msg.action === 'USER_LOGGED_IN') {
    registerExtension().then(() => sendResponse({ success: true }));
    return true;
  }
  if (msg.action === 'USER_LOGGED_OUT') {
    chrome.storage.local.remove(['authToken', 'authUser', 'selectedSellerId']);
    sendResponse({ success: true });
    return true;
  }
  sendResponse({ error: 'unknown action' });
  return true;
});

// ── TAB EVENTS ───────────────────────────────────────────────
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('indiamart.com')) {
    chrome.storage.local.get(['isScrapingActive'], (r) => {
      if (r.isScrapingActive) {
        setTimeout(() => chrome.tabs.sendMessage(tabId, { action: 'GET_STATUS' }).catch(() => {}), 3000);
      }
    });
  }
});

// ── STARTUP ──────────────────────────────────────────────────
chrome.runtime.onStartup.addListener(() => {
  setupAlarms();
  setTimeout(performHealthCheck, 5000);
});

setInterval(() => {
  chrome.runtime.getPlatformInfo(() => {});
  chrome.storage.local.get(['leadopticsStats'], () => {});
}, 20000);

console.log('[Lead Magnet] Service Worker v6.0.0 loaded');
