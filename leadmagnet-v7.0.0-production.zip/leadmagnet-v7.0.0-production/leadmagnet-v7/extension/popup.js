/**
 * Lead Magnet — Popup Script
 * @author datainteg.io
 * @version 6.0.0
 * Auth: JWT login, token stored in chrome.storage
 */
'use strict';

const $ = id => document.getElementById(id);
let currentSellerId = null;
let statsTimer      = null;
let sellers         = [];
let authToken       = null;
let authUser        = null;
const backendUrl    = () => ($('backendUrl')?.value || (typeof LM_CONFIG !== 'undefined' ? LM_CONFIG.API_URL : 'http://localhost:3000')).trim().replace(/\/$/, '');

// ── AUTH FETCH (adds JWT header) ─────────────────────────────
async function authFetch(url, options = {}) {
  if (!authToken) throw new Error('Not authenticated');
  options.headers = options.headers || {};
  options.headers['Authorization'] = 'Bearer ' + authToken;
  return fetch(url, options);
}

// ── BOOT: check if already logged in ─────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  // Check login backend status on login screen
  checkLoginBackend();

  // Setup login form
  $('btnLogin')?.addEventListener('click', doLogin);
  $('loginPassword')?.addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
  $('loginEmail')?.addEventListener('keydown', e => { if (e.key === 'Enter') $('loginPassword')?.focus(); });
  $('btnLogout')?.addEventListener('click', doLogout);

  // Check stored auth
  const stored = await chrome.storage.local.get(['authToken', 'authUser']);
  if (stored.authToken && stored.authUser) {
    authToken = stored.authToken;
    authUser  = stored.authUser;
    // Verify token still valid
    try {
      const res = await authFetch(backendUrl() + '/api/auth/me');
      if (res.ok) {
        const d = await res.json();
        authUser = d.user;
        await chrome.storage.local.set({ authUser: d.user });
        showApp();
        return;
      }
    } catch (e) {}
    // Token invalid — clear and show login
    authToken = null; authUser = null;
    await chrome.storage.local.remove(['authToken', 'authUser']);
  }
  showLogin();
});

async function checkLoginBackend() {
  try {
    const res = await fetch(backendUrl() + '/api/health');
    const ok = res.ok;
    const dot = $('loginBackendDot');
    const txt = $('loginBackendText');
    if (dot) dot.className = 'bdot ' + (ok ? 'online' : 'offline');
    if (txt) txt.textContent = ok ? 'Server online' : 'Server error';
  } catch {
    const dot = $('loginBackendDot');
    const txt = $('loginBackendText');
    if (dot) dot.className = 'bdot offline';
    if (txt) txt.textContent = 'Server offline';
  }
}

async function doLogin() {
  const email = $('loginEmail')?.value?.trim();
  const password = $('loginPassword')?.value;
  const err = $('loginError');
  const btn = $('btnLogin');

  if (!email || !password) { if (err) err.textContent = 'Enter email and password'; return; }
  if (btn) btn.disabled = true;
  if (err) err.textContent = '';

  try {
    const res = await fetch(backendUrl() + '/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const d = await res.json();
    if (!res.ok || !d.success) {
      if (err) err.textContent = d.error || 'Login failed';
      if (btn) btn.disabled = false;
      return;
    }

    authToken = d.token;
    authUser  = d.user;
    currentSellerId = d.user.sellerId || null;

    await chrome.storage.local.set({
      authToken: d.token,
      authUser: d.user,
      selectedSellerId: currentSellerId
    });

    // Tell background service worker
    chrome.runtime.sendMessage({ action: 'USER_LOGGED_IN' }).catch(() => {});
    showApp();
  } catch (e) {
    if (err) err.textContent = 'Network error: ' + e.message;
    if (btn) btn.disabled = false;
  }
}

async function doLogout() {
  authToken = null; authUser = null; currentSellerId = null;
  await chrome.storage.local.remove(['authToken', 'authUser', 'selectedSellerId', 'isScrapingActive']);
  chrome.runtime.sendMessage({ action: 'USER_LOGGED_OUT' }).catch(() => {});
  showLogin();
}

function showLogin() {
  $('loginScreen').style.display = 'flex';
  $('appScreen').style.display = 'none';
  $('loginEmail')?.focus();
}

function showApp() {
  $('loginScreen').style.display = 'none';
  $('appScreen').style.display = 'block';

  // Show user info in auth bar
  if ($('authName')) $('authName').textContent = authUser?.name || authUser?.email || '—';
  const roleEl = $('authRole');
  if (roleEl) {
    roleEl.textContent = authUser?.role || 'seller';
    roleEl.className = 'auth-role ' + (authUser?.role || 'seller');
  }

  // For seller role: auto-set sellerId, hide seller selector
  if (authUser?.role === 'seller' && authUser?.sellerId) {
    currentSellerId = authUser.sellerId;
  }

  initApp();
}

async function initApp() {
  setupTabs();
  setupPresets();
  await loadSettings();
  await loadSellers();
  await checkBackend();
  loadStats();
  bindButtons();
  setupTimeWindow();
  statsTimer = setInterval(loadStats, 2000);
  const extId = $('extensionIdDisplay');
  if (extId) extId.textContent = chrome.runtime.id || '—';

  // For seller role: auto-select if only one seller, show dropdown if multiple
  if (authUser?.role === 'seller') {
    if (sellers.length === 0) {
      // No seller IDs yet — prompt in status bar
      if ($('statusText')) $('statusText').textContent = 'Create a Seller ID first → Dashboard';
    } else if (sellers.length === 1) {
      currentSellerId = sellers[0].sellerId;
      const sel = $('sellerSelect');
      if (sel) { sel.value = currentSellerId; sel.dispatchEvent(new Event('change')); }
      const sc = document.querySelector('.sc');
      if (sc) sc.style.display = 'none';
    } else if (sellers.length > 1) {
      // Multiple sellers — show dropdown, pre-select first
      currentSellerId = sellers[0].sellerId;
      const sel = $('sellerSelect');
      if (sel) { sel.value = currentSellerId; sel.dispatchEvent(new Event('change')); }
    }
  }
}

// ── TABS ─────────────────────────────────────────────────────────
function setupTabs() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      const pane = $(tab.dataset.tab + '-tab');
      if (pane) pane.classList.add('active');
    });
  });
}

// ── PRESETS ──────────────────────────────────────────────────────
function setupPresets() {
  document.querySelectorAll('.preset[data-val]').forEach(btn => {
    btn.addEventListener('click', () => {
      const val = parseFloat(btn.dataset.val);
      const inp = $('refreshInterval');
      if (inp) inp.value = val;
      document.querySelectorAll('.preset[data-val]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });
  $('refreshInterval')?.addEventListener('input', () => {
    let val = parseFloat($('refreshInterval').value);
    if (isNaN(val) || val < 0.5) { val = 0.5; $('refreshInterval').value = 0.5; }
    document.querySelectorAll('.preset[data-val]').forEach(b => {
      b.classList.toggle('active', parseFloat(b.dataset.val) === val);
    });
  });
  // Custom refresh button
  $('btnCustomRefresh')?.addEventListener('click', () => {
    const custom = $('customRefresh');
    const unit   = $('customRefreshUnit')?.value || 'sec';
    const inp    = $('refreshInterval');
    if (custom && inp) {
      let val = parseFloat(custom.value);
      if (!isNaN(val) && val > 0) {
        // Convert minutes to seconds for internal storage
        if (unit === 'min') val = val * 60;
        val = Math.max(0.5, val); // minimum 0.5s
        inp.value = val;
        document.querySelectorAll('.preset[data-val]').forEach(b => b.classList.remove('active'));
        const display = unit === 'min' ? `${custom.value} min (${val}s)` : `${val}s`;
        showToast('Interval set to ' + display, 'success');
      } else {
        showToast('Enter a valid number greater than 0', 'error');
      }
    }
  });
}

// ── TIME WINDOW ──────────────────────────────────────────────────
// Must be called AFTER loadSettings so the toggle checked state is already restored.
// Uses id="tw-inputs" (matches popup.html) and id="twHint".
function setupTimeWindow() {
  const toggle = $('enableTimeWindow');
  const inputs = $('tw-inputs');         // ← correct ID matching popup.html
  const hint   = $('twHint');

  function applyTWState() {
    const on = toggle?.checked || false;
    if (inputs) {
      if (on) { inputs.classList.remove('dim'); }
      else    { inputs.classList.add('dim'); }
    }
    if (hint) {
      if (on) {
        const s = $('clickStartTime')?.value || '09:00';
        const e = $('clickEndTime')?.value   || '18:00';
        hint.textContent   = '✅ Clicking only between ' + s + ' – ' + e;
        hint.style.color   = 'var(--gn)';
      } else {
        hint.textContent   = 'Enable toggle to restrict click hours';
        hint.style.color   = 'var(--t3)';
      }
    }
  }

  // Apply initial state immediately (settings already loaded)
  applyTWState();

  toggle?.addEventListener('change', applyTWState);
  $('clickStartTime')?.addEventListener('change', applyTWState);
  $('clickEndTime')?.addEventListener('change', applyTWState);
}

// ── SETTINGS ─────────────────────────────────────────────────────
async function loadSettings() {
  return new Promise(resolve => {
    chrome.storage.local.get(['leadopticsSettings', 'selectedSellerId'], result => {
      const s  = result.leadopticsSettings || {};
      const ac = s.autoClick || {};
      const rf = s.refresh   || {};
      const fl = s.filter    || {};
      const be = s.backend   || {};

      if ($('enableAutoClick'))  $('enableAutoClick').checked  = ac.enabled !== false;
      if ($('autoClosePopup'))   $('autoClosePopup').checked   = ac.autoClosePopup !== false;
      if ($('clickDelay'))       $('clickDelay').value         = ac.clickDelay   || 3;
      if ($('minScore'))         $('minScore').value           = ac.minScore     || 0;
      if ($('maxLeadAge'))       $('maxLeadAge').value         = ac.maxLeadAge   || 5;
      if ($('dailyClickLimit'))  $('dailyClickLimit').value    = ac.dailyClickLimit ?? 0;
      if ($('refreshInterval'))  $('refreshInterval').value   = rf.interval     || 15;
      if ($('backendUrl'))       $('backendUrl').value         = be.url || 'http://localhost:3000';
      if ($('targetCities'))     $('targetCities').value       = (fl.targetCities || []).join(', ');
      if ($('minOrderValue'))    $('minOrderValue').value      = fl.minOrderValue || '';
      if ($('maxOrderValue'))    $('maxOrderValue').value      = fl.maxOrderValue || '';
      if ($('excludedKeywords')) $('excludedKeywords').value   = (fl.excludedKeywords || []).join('\n');

      // Time window — set checked state BEFORE setupTimeWindow() reads it
      if ($('enableTimeWindow')) $('enableTimeWindow').checked = ac.enableTimeWindow || false;
      if ($('clickStartTime'))   $('clickStartTime').value    = ac.clickStartTime || '09:00';
      if ($('clickEndTime'))     $('clickEndTime').value      = ac.clickEndTime   || '18:00';

      // Sync preset buttons
      const cur = parseFloat($('refreshInterval')?.value || 15);
      document.querySelectorAll('.preset').forEach(b => {
        b.classList.toggle('active', parseInt(b.dataset.val) === cur);
      });

      currentSellerId = result.selectedSellerId || s.sellerId || null;
      resolve();
    });
  });
}

function buildSettings() {
  const twOn = $('enableTimeWindow')?.checked || false;
  return {
    sellerId: currentSellerId,
    keywords: [],
    autoClick: {
      enabled:          $('enableAutoClick')?.checked ?? true,
      clickDelay:       parseInt($('clickDelay')?.value)    || 3,
      autoClosePopup:   $('autoClosePopup')?.checked ?? true,
      minScore:         parseInt($('minScore')?.value)      || 0,
      maxLeadAge:       Math.min(parseInt($('maxLeadAge')?.value) || 5, 5), // hard max: 5 min
      dailyClickLimit:  parseInt($('dailyClickLimit')?.value) || 0,         // 0 = unlimited
      enableTimeWindow: twOn,
      // Only store times when window is enabled; content.js checks enableTimeWindow flag
      clickStartTime:   twOn ? ($('clickStartTime')?.value || '09:00') : null,
      clickEndTime:     twOn ? ($('clickEndTime')?.value   || '18:00') : null,
    },
    refresh:  { enabled: true, interval: Math.max(0.5, parseFloat($('refreshInterval')?.value) || 5) },
    filter: {
      targetCities:     ($('targetCities')?.value || '').split(',').map(s => s.trim()).filter(Boolean),
      minOrderValue:    parseInt($('minOrderValue')?.value) || 0,
      maxOrderValue:    parseInt($('maxOrderValue')?.value) || 10000000,
      excludedKeywords: ($('excludedKeywords')?.value || '').split('\n').map(s => s.trim()).filter(Boolean)
    },
    backend: { url: backendUrl() }  // defaults to http://localhost:3000
  };
}

async function saveSettings() {
  const settings = buildSettings();
  await chrome.storage.local.set({ leadopticsSettings: settings, selectedSellerId: currentSellerId });
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) chrome.tabs.sendMessage(tab.id, { action: 'UPDATE_SETTINGS', settings }).catch(() => {});
  showToast('✅ Settings saved', 'success');
}

// ── SELLERS ──────────────────────────────────────────────────────
async function loadSellers() {
  try {
    const res  = await authFetch(backendUrl() + '/api/sellers');
    const data = await res.json();
    sellers    = data.sellers || [];
    const sel  = $('sellerSelect');
    if (!sel) return;
    sel.innerHTML = '<option value="">— Select Seller —</option>' +
      sellers.map(s =>
        `<option value="${s.sellerId}"${s.sellerId === currentSellerId ? ' selected' : ''}>${s.name || s.sellerId}</option>`
      ).join('');

    // FIX BUG 1: If a seller is already selected, render keywords immediately
    if (currentSellerId) {
      const seller = sellers.find(s => s.sellerId === currentSellerId);
      renderKeywords(seller);
      if ($('btnStart')) $('btnStart').disabled = false;

      // FIX BUG 1: Pre-save keywords into storage so START always has them ready
      if (seller?.keywords?.length > 0) {
        const settings = buildSettings();
        settings.keywords          = seller.keywords;
        settings.keywordCategories = seller.keywordCategories || { category: [], city: [], value: [] };
        settings.sellerId          = currentSellerId;
        await chrome.storage.local.set({ leadopticsSettings: settings });
      }
    }
  } catch (e) {
    showToast('Cannot reach backend', 'error');
  }
}

// Seller select change — bound after DOM ready (merged from duplicate DOMContentLoaded — BUG FIX #9)
document.addEventListener('DOMContentLoaded', function sellerSelectInit() {
  $('sellerSelect')?.addEventListener('change', async function () {
    currentSellerId = this.value || null;
    await chrome.storage.local.set({ selectedSellerId: currentSellerId });
    const seller = sellers.find(s => s.sellerId === currentSellerId);
    renderKeywords(seller);
    if ($('btnStart')) $('btnStart').disabled = !currentSellerId;
    if (seller?.keywords?.length > 0) {
      const settings           = buildSettings();
      settings.keywords          = seller.keywords;
      settings.keywordCategories = seller.keywordCategories || { category: [], city: [], value: [] };
      await chrome.storage.local.set({ leadopticsSettings: settings });
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id) chrome.tabs.sendMessage(tab.id, { action: 'UPDATE_SETTINGS', settings }).catch(() => {});
    }
  });
});

function renderKeywords(seller) {
  const el  = $('sellerKeywords');
  const el2 = $('keywordGroups');
  if (!seller || !seller.keywords?.length) {
    if (el)  el.innerHTML  = '<span style="font-size:10px;color:var(--t3)">No keywords set</span>';
    if (el2) el2.innerHTML = '<div style="color:var(--t3);font-size:12px;text-align:center;padding:16px">No keywords — add in Dashboard</div>';
    return;
  }

  let cats = seller.keywordCategories || { category: [], city: [], value: [] };

  // FIX: If all buckets are empty but keywords exist, redistribute from flat array
  const totalBucketed = (cats.category?.length || 0) + (cats.city?.length || 0) + (cats.value?.length || 0);
  if (totalBucketed === 0 && seller.keywords.length > 0) {
    // Classify each keyword using same logic as backend
    const cityHints = ['mumbai','delhi','bangalore','bengaluru','pune','chennai','hyderabad',
      'kolkata','ahmedabad','jaipur','lucknow','surat','nagpur','indore','bhopal','patna',
      'vadodara','ludhiana','agra','nashik','raipur','maharashtra','gujarat','rajasthan',
      'punjab','odisha','karnataka','telangana','jharkhand','uttar pradesh','madhya pradesh',
      'west bengal','tamil nadu','andhra pradesh','kerala','haryana','himachal'];
    const valueHints = ['bulk','wholesale','urgent','oem','₹','rs.','lakh','crore',
      'quantity','units','pieces','tons','kg','quotation'];
    cats = { category: [], city: [], value: [] };
    seller.keywords.forEach(k => {
      const kl = k.toLowerCase();
      if (cityHints.some(c => kl.includes(c))) cats.city.push(k);
      else if (valueHints.some(v => kl.includes(v))) cats.value.push(k);
      else cats.category.push(k);
    });
  }

  // Seller header pill preview (shows first 12 keywords)
  if (el) {
    const pills = seller.keywords.slice(0, 12).map(kw => {
      const cls = cats.category?.includes(kw) ? 'category' : cats.city?.includes(kw) ? 'city' : 'value';
      return `<span class="kp ${cls}">${kw}</span>`;
    }).join('');
    const extra = seller.keywords.length > 12
      ? `<span style="font-size:9px;color:var(--t3)">+${seller.keywords.length - 12} more</span>` : '';
    el.innerHTML = pills + extra;
  }

  // Keywords tab — grouped by category
  if (el2) {
    const groups = [
      { key: 'category', icon: '🏷️', label: 'Category' },
      { key: 'city',     icon: '📍', label: 'City'     },
      { key: 'value',    icon: '💰', label: 'Value'    },
    ];
    const html = groups.map(g => {
      const kws = cats[g.key] || [];
      if (!kws.length) return '';
      return `<div class="kwg">
        <div class="kwgtitle">${g.icon} ${g.label}<span class="kwgcount">${kws.length}</span></div>
        <div class="kwgpills">${kws.map(k => `<span class="kp ${g.key}">${k}</span>`).join('')}</div>
      </div>`;
    }).join('');
    el2.innerHTML = html || '<div style="color:var(--t3);font-size:12px;padding:8px">No keywords yet</div>';
  }
}

// ── STATS ─────────────────────────────────────────────────────────
function loadStats() {
  chrome.storage.local.get(['leadopticsStats', 'isScrapingActive', 'leadopticsSettings'], result => {
    const stats = result.leadopticsStats || {};
    const limit = result.leadopticsSettings?.autoClick?.dailyClickLimit ?? 0;
    if ($('statTotal'))    $('statTotal').textContent    = stats.total    || 0;
    if ($('statClicked'))  $('statClicked').textContent  = stats.clicked  || 0;
    if ($('statFiltered')) $('statFiltered').textContent = stats.filtered || 0;
    if ($('statToday'))    $('statToday').textContent    = stats.today    || 0;

    // Daily limit hint
    const hint = $('dailyLimitHint');
    if (hint) {
      const clickedToday = stats.clickedToday || 0;
      if (limit > 0) {
        const remaining = Math.max(0, limit - clickedToday);
        hint.textContent = `✅ Limit: ${clickedToday} / ${limit} today · ${remaining} remaining`;
        hint.style.color = remaining === 0 ? 'var(--rd)' : 'var(--gn)';
      } else {
        hint.textContent = 'Set to 0 for unlimited · Resets at midnight each day';
        hint.style.color = '';
      }
    }

    const active = result.isScrapingActive;
    const dot    = $('statusDot');
    const text   = $('statusText');
    const phase  = $('statusPhase');
    const start  = $('btnStart');
    const stop   = $('btnStop');

    if (dot)   { dot.className = 'sdot' + (active ? ' active' : ''); }
    if (text)  text.textContent = active ? '🟢 Active — watching for leads' : (currentSellerId ? 'Ready to start' : 'Select a seller to begin');
    if (phase) { phase.className = 'sphase ' + (active ? 'running' : 'idle'); phase.textContent = active ? 'RUNNING' : 'IDLE'; }
    if (start) { start.style.display = active ? 'none' : 'flex'; start.disabled = !currentSellerId; }
    if (stop)  stop.style.display = active ? 'flex' : 'none';
  });
}

// ── BACKEND CHECK ─────────────────────────────────────────────────
async function checkBackend() {
  const dot  = $('backendDot');
  const text = $('backendText');
  try {
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), 5000);
    const res  = await fetch(backendUrl() + '/api/health', { signal: ctrl.signal });
    const data = await res.json();
    const ok   = res.ok && data.success;
    if (dot)  dot.className   = 'bdot ' + (ok ? 'online' : 'offline');
    if (text) text.textContent = ok ? 'Online' : 'Error';
    chrome.runtime.sendMessage({ action: 'BACKEND_STATUS', online: ok }).catch(() => {});
  } catch {
    if (dot)  dot.className   = 'bdot offline';
    if (text) text.textContent = 'Offline';
    chrome.runtime.sendMessage({ action: 'BACKEND_STATUS', online: false }).catch(() => {});
  }
}

// ── SCRAPING ──────────────────────────────────────────────────────
async function startScraping() {
  if (!currentSellerId) { showToast('Select a seller first!', 'error'); return; }

  // FIX BUG 1: Always fetch fresh seller data before starting
  // This ensures keywords are never empty on first start
  let seller = sellers.find(s => s.sellerId === currentSellerId);
  if (!seller || !seller.keywords?.length) {
    showToast('Fetching seller keywords…', 'info');
    try {
      const res  = await authFetch(backendUrl() + '/api/sellers');
      const data = await res.json();
      sellers    = data.sellers || [];
      seller     = sellers.find(s => s.sellerId === currentSellerId);
    } catch (e) {
      showToast('Failed to load keywords: ' + e.message, 'error');
      return;
    }
  }

  const settings = buildSettings();
  if (seller?.keywords)          settings.keywords          = seller.keywords;
  if (seller?.keywordCategories) settings.keywordCategories = seller.keywordCategories;
  settings.sellerId = currentSellerId;

  await chrome.storage.local.set({
    leadopticsSettings: settings,
    isScrapingActive: true,
    selectedSellerId: currentSellerId
  });

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) { showToast('No active IndiaMART tab!', 'error'); return; }
  chrome.tabs.sendMessage(tab.id, { action: 'START_SCRAPING', settings }, resp => {
    if (chrome.runtime.lastError) showToast('Open IndiaMART Buy Leads first', 'error');
    else { showToast('🎯 Started!', 'success'); loadStats(); }
  });
}

async function stopScraping() {
  await chrome.storage.local.set({ isScrapingActive: false });
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) chrome.tabs.sendMessage(tab.id, { action: 'STOP_SCRAPING' }).catch(() => {});
  showToast('Stopped', 'info');
  loadStats();
}

// ── BUTTONS ───────────────────────────────────────────────────────
function bindButtons() {
  $('btnStart')?.addEventListener('click', startScraping);
  $('btnStop') ?.addEventListener('click', stopScraping);
  $('btnSave') ?.addEventListener('click', saveSettings);
  $('btnRefreshSellers')?.addEventListener('click', async () => {
    await loadSellers(); await checkBackend(); showToast('Refreshed', 'success');
  });
  // BUG FIX #2: Export via auth header + blob download (no JWT in URL)
  $('btnExport')?.addEventListener('click', async () => {
    try {
      let url = backendUrl() + '/api/leads/export';
      if (currentSellerId) url += '?sellerId=' + currentSellerId;
      const res = await authFetch(url);
      if (!res.ok) { showToast('Export failed', 'error'); return; }
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      chrome.downloads.download({
        url: blobUrl,
        filename: 'leadmagnet_export_' + Date.now() + '.csv',
        saveAs: true
      });
      showToast('Export downloading…', 'success');
    } catch (e) { showToast('Export error: ' + e.message, 'error'); }
  });
  $('btnDashboard')?.addEventListener('click', () => chrome.tabs.create({ url: backendUrl() + '/dashboard' }));
  $('dashKwLink')?.addEventListener('click', e => { e.preventDefault(); chrome.tabs.create({ url: backendUrl() + '/dashboard' }); });
  $('btnClearData')?.addEventListener('click', async () => {
    if (!confirm('Clear all leads? Cannot be undone.')) return;
    try {
      const res = await authFetch(backendUrl() + '/api/data/clear', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sellerId: currentSellerId })
      });
      const d = await res.json();
      if (d.success) {
        await chrome.storage.local.set({ leadopticsStats: { total:0, clicked:0, filtered:0, today:0, clickedToday:0, lastDate: new Date().toDateString() } });
        loadStats(); showToast('Leads cleared', 'success');
      }
    } catch { showToast('Clear failed', 'error'); }
  });
  $('backendUrl')?.addEventListener('change', checkBackend);
}

// ── TOAST ─────────────────────────────────────────────────────────
function showToast(msg, type) {
  document.querySelector('.lm-toast')?.remove();
  const t = document.createElement('div');
  t.className = 'lm-toast';
  const clr = {
    success: { bg:'rgba(16,185,129,.15)',  color:'#10B981', border:'rgba(16,185,129,.3)' },
    error:   { bg:'rgba(239,68,68,.15)',   color:'#EF4444', border:'rgba(239,68,68,.3)' },
    info:    { bg:'rgba(99,102,241,.15)',  color:'#818CF8', border:'rgba(99,102,241,.3)' },
  };
  const c = clr[type] || clr.info;
  t.style.cssText = [
    'position:fixed','bottom:12px','left:50%','transform:translateX(-50%)',
    `background:${c.bg}`,`color:${c.color}`,`border:1px solid ${c.border}`,
    'padding:7px 16px','border-radius:20px','font-size:12px','font-weight:700',
    'white-space:nowrap','z-index:9999','box-shadow:0 4px 16px rgba(0,0,0,.3)',
    'backdrop-filter:blur(8px)','font-family:Space Grotesk,sans-serif'
  ].join(';');
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2500);
}
