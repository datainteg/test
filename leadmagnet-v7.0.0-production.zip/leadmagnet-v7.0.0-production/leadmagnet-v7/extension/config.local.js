/**
 * Lead Magnet — Extension Config (LOCAL DEV)
 * Used when testing extension against local backend
 * Switch manifest.json background.scripts to load this instead of config.js
 * @version 7.0.0
 */
const LM_CONFIG = {
  API_URL: 'http://localhost:3000',
  VERSION: '7.0.0'
};
