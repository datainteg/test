/**
 * Lead Magnet — Content Script
 * @author datainteg.io
 * @version 6.1.0
 *
 * FLOW:
 * Phase 1: Scroll entire page → capture ALL leads → save to MongoDB (skip duplicates)
 * Phase 2: Poll every N seconds for NEW leads only → match seller keywords → auto-click
 *
 * Features v5.4:
 * - Heartbeat signal every 30s → backend knows extension is alive
 * - Anti-throttle: prevents Chrome from freezing on RDP/EC2
 * - Overnight time window support (e.g. 22:00–06:00)
 * - closePopup returns accurate true/false
 * - All v5.3 features preserved
 */

(function () {
  'use strict';

  if (window.LEADMAGNET_INITIALIZED) {
    console.log('[Lead Magnet] Already initialized.');
    return;
  }
  window.LEADMAGNET_INITIALIZED = true;

  console.log('🚀 Lead Magnet Loading...');

  // ==================== CONFIG ====================
  const CONFIG = {
    SYNC_INTERVAL: 8000,
    NEW_LEAD_CHECK_INTERVAL: 15000,
    CLICK_DELAY_DEFAULT: 3000,
    POPUP_WAIT: 2500,
    POPUP_CLOSE_DELAY: 800,
    POPUP_CLOSE_RETRIES: 3,
    POPUP_RETRY_DELAY: 1000,
    SCROLL_AMOUNT: 500,
    SCROLL_DELAY: 1200,
    HEALTH_CHECK_INTERVAL: 30000,
    HEARTBEAT_INTERVAL: 30000,
    ANTI_THROTTLE_INTERVAL: 15000,
    MAX_RETRY_QUEUE: 100,
    MAX_SCROLL_ATTEMPTS: 30,
    DEBUG: true
  };

  // ==================== AUTH HELPER ====================
  // All API calls include JWT token from chrome.storage
  let _authToken = null;

  async function getAuthToken() {
    if (_authToken) return _authToken;
    return new Promise((resolve) => {
      chrome.storage.local.get(['authToken'], (r) => {
        _authToken = r.authToken || null;
        resolve(_authToken);
      });
    });
  }

  // Clear cached token when user logs in/out so new token is picked up
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.authToken) {
      _authToken = changes.authToken.newValue || null;
    }
  });

  async function authFetch(url, options = {}) {
    const token = await getAuthToken();
    if (!token) throw new Error('Not authenticated');
    options.headers = options.headers || {};
    options.headers['Authorization'] = 'Bearer ' + token;
    if (options.body && !options.headers['Content-Type']) {
      options.headers['Content-Type'] = 'application/json';
    }
    return fetch(url, options);
  }

  // ==================== STATE ====================
  let state = {
    isActive: false,
    phase: 'idle',
    settings: null,
    sellerId: null,
    keywords: [],
    keywordCategories: { category: [], city: [], value: [] }, // structured categories
    processedLeadIds: new Set(),
    clickedLeadIds: new Set(),
    leadQueue: [],
    backendOnline: true,
    isProcessingClick: false,
    intervals: { newLeadCheck: null, sync: null, health: null, heartbeat: null, antiThrottle: null },
    stats: { total: 0, clicked: 0, filtered: 0, today: 0, clickedToday: 0, lastDate: new Date().toDateString() }
  };

  const CONTENT_BLACKLIST = [
    'products with no specifications', 'buy leads quota', 'show more buyleads',
    'view similar', 'upgrade now', 'your membership', 'no leads found', 'no results'
  ];

  // ==================== UTILS ====================

  function log(msg, data = null) {
    if (!CONFIG.DEBUG) return;
    const ts = new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' });
    data !== null ? console.log(`[Lead Magnet ${ts}] ${msg}`, data) : console.log(`[Lead Magnet ${ts}] ${msg}`);  }

  function generateLeadId(data) {
    const str = [
      (data.title || '').toLowerCase().trim().substring(0, 100),
      (data.location?.city || '').toLowerCase().trim(),
      (data.buyer?.memberSince || '').trim()
    ].join('|');
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash = hash & hash;
    }
    return 'lead_' + Math.abs(hash).toString(36) + '_' + str.length;
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
  function randomDelay(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
  function cleanText(text) { return (text || '').replace(/\s+/g, ' ').trim(); }

  function parseTimestampToMinutes(tsText) {
    const ts = (tsText || '').toLowerCase().trim();
    if (!ts) return -1;
    if (ts === 'just now' || ts.includes('0 sec') || ts.includes('0 min')) return 0;
    const secMatch = ts.match(/(\d+)\s*(?:sec|secs|second|seconds)\s*ago/i);
    if (secMatch) return Math.ceil(parseInt(secMatch[1]) / 60);
    const minMatch = ts.match(/(\d+)\s*(?:min|mins|minute|minutes)\s*ago/i);
    if (minMatch) return parseInt(minMatch[1]);
    const hrMatch = ts.match(/(\d+)\s*(?:hr|hrs|hour|hours)\s*ago/i);
    if (hrMatch) return parseInt(hrMatch[1]) * 60;
    const dayMatch = ts.match(/(\d+)\s*(?:day|days)\s*ago/i);
    if (dayMatch) return parseInt(dayMatch[1]) * 1440;
    if (ts.includes('yesterday')) return 1440;
    if (ts.includes('today')) return 0;
    return -1;
  }

  // ==================== INIT ====================

  async function init() {
    log('🔧 Initializing Lead Magnet...');
    try {
      await loadSettings();
      await loadClickedLeadsFromDB();
      loadStats();
      setupMessageListener();
      injectStatusIndicator();
      startHealthCheck();
      startHeartbeat();       // ✅ NEW: heartbeat signal to backend
      startAntiThrottle();    // ✅ NEW: prevent Chrome tab suspension on RDP

      chrome.storage.local.get(['isScrapingActive', 'leadopticsSession'], (result) => {
        if (result.leadopticsSession) {
          // ✅ Restore phase → skip Phase 1 after reload, jump straight to Phase 2
          if (result.leadopticsSession.phase) {
            state.phase = result.leadopticsSession.phase;
          }
          // ✅ Restore clicked IDs → never re-click already contacted leads
          if (result.leadopticsSession.clickedLeadIds) {
            result.leadopticsSession.clickedLeadIds.forEach(id => state.clickedLeadIds.add(id));
          }
          // ❌ processedLeadIds NOT restored → fresh scan after reload
          // DB check in processLeadCard() prevents duplicate saves
        }

        // FIX BUG 2: If isScrapingActive is true but no session exists, it's a stale
        // state from a previous Chrome crash/close. Clear it so first START works cleanly.
        if (result.isScrapingActive && !result.leadopticsSession) {
          log('⚠️ Stale isScrapingActive detected with no session — clearing');
          chrome.storage.local.set({ isScrapingActive: false });
        } else if (result.isScrapingActive && result.leadopticsSession) {
          log(`🔄 Auto-resuming in phase: ${state.phase || 'initial'}...`);
          setTimeout(() => resumeScraping(), 2000);
        }
      });

      log('✅ Lead Magnet Ready!');
      showNotification('Lead Magnet Ready', 'info');
    } catch (error) {
      log('❌ Init error:', error);
    }
  }

  // ==================== SETTINGS ====================

  async function loadSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['leadopticsSettings', 'selectedSellerId'], (result) => {
        state.settings = result.leadopticsSettings || getDefaultSettings();
        state.sellerId = result.selectedSellerId || state.settings.sellerId || null;
        state.keywords = state.settings.keywords || state.settings.autoClick?.keywords || [];
        // Load structured keyword categories (category / city / value)
        state.keywordCategories = state.settings.keywordCategories || { category: [], city: [], value: [] };
        log(`⚙️ Settings loaded | Seller: ${state.sellerId} | Keywords: ${state.keywords.length} | Category: ${state.keywordCategories.category?.length || 0} City: ${state.keywordCategories.city?.length || 0} Value: ${state.keywordCategories.value?.length || 0}`);
        resolve();
      });
    });
  }

  function getDefaultSettings() {
    return {
      sellerId: null,
      keywords: [],
      autoClick: {
        enabled: false, keywords: [], minScore: 0, clickDelay: 3,
        autoClosePopup: true, maxLeadAge: 5, dailyClickLimit: 0
      },
      filter: { targetCities: [], excludedKeywords: [], minOrderValue: 0, maxOrderValue: 10000000 },
      refresh: { enabled: true, interval: 15 },
      backend: { url: 'http://localhost:3000' }
    };
  }

  function loadStats() {
    chrome.storage.local.get(['leadopticsStats'], (result) => {
      if (result.leadopticsStats) {
        state.stats = result.leadopticsStats;
        if (state.stats.lastDate !== new Date().toDateString()) {
          state.stats.today = 0;
          state.stats.clickedToday = 0;
          state.stats.lastDate = new Date().toDateString();
          // BUG FIX #13: Persist the reset immediately
          chrome.storage.local.set({ leadopticsStats: state.stats });
        }
      }
    });
  }

  // BUG FIX #13: Check for date rollover every 60s (not just at init)
  setInterval(() => {
    const today = new Date().toDateString();
    if (state.stats.lastDate && state.stats.lastDate !== today) {
      state.stats.today = 0;
      state.stats.clickedToday = 0;
      state.stats.lastDate = today;
      saveStats();
      log('🔄 Daily stats reset at ' + today);
    }
  }, 60000);

  function saveStats() {
    chrome.storage.local.set({ leadopticsStats: state.stats });
    chrome.runtime.sendMessage({ action: 'STATS_UPDATE', stats: state.stats }).catch(() => {});
    updateStatusIndicator();
  }

  function getBackendUrl() {
    return state.settings?.backend?.url || 'http://localhost:3000';
  }

  // ==================== MONGODB INTEGRATION ====================

  async function loadClickedLeadsFromDB() {
    if (!state.sellerId) return;
    try {
      const response = await authFetch(`${getBackendUrl()}/api/leads/clicked-ids?sellerId=${state.sellerId}`);
      if (response.ok) {
        const data = await response.json();
        if (data.clickedIds) {
          state.clickedLeadIds = new Set(data.clickedIds);
          log(`📥 Loaded ${state.clickedLeadIds.size} clicked IDs from MongoDB`);
        }
      }
    } catch (error) {
      log('⚠️ Could not load clicked leads:', error.message);
    }
  }

  async function checkLeadInDB(leadId) {
    if (!state.sellerId) return { exists: false, clicked: false };
    try {
      const response = await authFetch(`${getBackendUrl()}/api/leads/check/${leadId}?sellerId=${state.sellerId}`);
      if (response.ok) return await response.json();
    } catch (error) {
      log('⚠️ DB check failed:', error.message);
    }
    return { exists: false, clicked: false };
  }

  async function markLeadClickedInDB(leadId, leadData) {
    try {
      const response = await authFetch(`${getBackendUrl()}/api/leads/mark-clicked`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          leadId,
          sellerId: state.sellerId,
          clickedAt: new Date().toISOString(),
          title: leadData.title,
          location: leadData.location,
          keywordMatched: leadData.matchedKeywords?.[0] || ''
        })
      });
      if (response.ok) {
        state.clickedLeadIds.add(leadId);
        log(`✅ Marked clicked in MongoDB: ${leadId}`);
        return true;
      }
    } catch (error) {
      log('⚠️ Failed to mark clicked:', error.message);
    }
    return false;
  }

  // Update clickAttempted flag: Y = button found + clicked, N = button not found / error
  async function updateClickAttempted(leadId, flag) {
    try {
      await authFetch(`${getBackendUrl()}/api/leads/click-attempted`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ leadId, sellerId: state.sellerId, clickAttempted: flag })
      });
    } catch (e) {
      // non-critical — ignore errors
    }
  }

  async function syncLeadsToDB() {
    if (state.leadQueue.length === 0 || !state.backendOnline || !state.sellerId) return;

    const batch = [...state.leadQueue];
    state.leadQueue = [];

    try {
      const response = await authFetch(`${getBackendUrl()}/api/leads/batch`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ leads: batch, sellerId: state.sellerId, timestamp: new Date().toISOString() })
      });
      if (response.ok) {
        const result = await response.json();
        log(`☁️ Synced: ${result.inserted} new | ${result.skipped} existing`);
      } else {
        state.leadQueue.unshift(...batch);
      }
    } catch (error) {
      log('⚠️ Sync failed:', error.message);
      state.leadQueue.unshift(...batch);
      if (state.leadQueue.length > CONFIG.MAX_RETRY_QUEUE) {
        state.leadQueue = state.leadQueue.slice(0, CONFIG.MAX_RETRY_QUEUE);
      }
    }
  }

  // ==================== HEALTH CHECK ====================

  function startHealthCheck() {
    if (state.intervals.health) clearInterval(state.intervals.health);

    const doCheck = async () => {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);
        const response = await fetch(`${getBackendUrl()}/api/health`, { signal: controller.signal });
        clearTimeout(timeoutId);
        const wasOffline = !state.backendOnline;
        state.backendOnline = response.ok;
        if (wasOffline && state.backendOnline) {
          log('🟢 Backend reconnected!');
          syncLeadsToDB();
        }
      } catch (error) {
        state.backendOnline = false;
      }
      updateStatusIndicator();
    };

    state.intervals.health = setInterval(doCheck, CONFIG.HEALTH_CHECK_INTERVAL);
    setTimeout(doCheck, 1000);
  }

  // ==================== MESSAGE LISTENER ====================

  // ── HEARTBEAT: ping backend every 30s ──────────────────────────
  function startHeartbeat() {
    if (state.intervals.heartbeat) clearInterval(state.intervals.heartbeat);

    const sendHeartbeat = async () => {
      if (!state.sellerId) return;
      try {
        await authFetch(`${getBackendUrl()}/api/heartbeat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sellerId: state.sellerId,
            extensionId: chrome.runtime?.id || '',
            phase: state.phase,
            stats: state.stats,
            tabUrl: window.location.href,
            chromeFlags: document.hidden ? 'TAB_HIDDEN' : 'TAB_VISIBLE'
          })
        });
      } catch (e) {
        // non-critical — silently ignore
      }
    };

    state.intervals.heartbeat = setInterval(sendHeartbeat, CONFIG.HEARTBEAT_INTERVAL);
    setTimeout(sendHeartbeat, 2000); // first ping after 2s
    log('💓 Heartbeat started (every 30s)');
  }

  // ── ANTI-THROTTLE: prevent Chrome from freezing tab on RDP/EC2 ─
  function startAntiThrottle() {
    if (state.intervals.antiThrottle) clearInterval(state.intervals.antiThrottle);

    state.intervals.antiThrottle = setInterval(() => {
      // Touch DOM to prevent Chrome from suspending the tab
      const el = document.createElement('div');
      el.style.display = 'none';
      el.id = 'lm-keepalive-' + Date.now();
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 100);

      // Touch storage to keep service worker alive
      chrome.storage.local.get(['leadopticsStats'], () => {});

      // Request animation frame to signal "tab is active"
      if (typeof requestAnimationFrame === 'function') {
        requestAnimationFrame(() => {});
      }
    }, CONFIG.ANTI_THROTTLE_INTERVAL);
    log('🛡️ Anti-throttle started (every 15s)');
  }

  function setupMessageListener() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      log('📩 Message:', message.action);
      try {
        switch (message.action) {
          case 'START_SCRAPING':
            if (message.settings) {
              state.settings = message.settings;
              state.sellerId = message.settings.sellerId || state.sellerId;
              state.keywords = message.settings.keywords || message.settings.autoClick?.keywords || [];
              state.keywordCategories = message.settings.keywordCategories || { category: [], city: [], value: [] };
              chrome.storage.local.set({ leadopticsSettings: message.settings });
            }
            // FIX BUG 2: Reset isActive so startScraping() guard doesn't block first run
            state.isActive = false;
            state.phase = 'initial';
            state.processedLeadIds.clear();
            // FIX BUG 2: Wait for session clear BEFORE calling startScraping (was race condition)
            chrome.storage.local.remove(['leadopticsSession'], () => {
              startScraping();
            });
            sendResponse({ status: 'started', phase: state.phase });
            break;
          case 'STOP_SCRAPING':
            stopScraping();
            sendResponse({ status: 'stopped' });
            break;
          case 'UPDATE_SETTINGS':
            state.settings = message.settings;
            state.sellerId = message.settings.sellerId || state.sellerId;
            state.keywords = message.settings.keywords || message.settings.autoClick?.keywords || [];
            state.keywordCategories = message.settings.keywordCategories || { category: [], city: [], value: [] };
            chrome.storage.local.set({ leadopticsSettings: message.settings });
            sendResponse({ status: 'updated' });
            break;
          case 'GET_STATUS':
            sendResponse({
              isActive: state.isActive, phase: state.phase,
              backendOnline: state.backendOnline, queueSize: state.leadQueue.length,
              processedCount: state.processedLeadIds.size,
              sellerId: state.sellerId
            });
            break;
          default:
            sendResponse({ error: 'Unknown action' });
        }
      } catch (error) {
        sendResponse({ error: error.message });
      }
      return true;
    });
  }

  // ==================== SCRAPING CONTROL ====================

  function saveSessionState() {
    return new Promise((resolve) => {
      chrome.storage.local.set({
        leadopticsSession: {
          phase: state.phase,
          // ✅ Only save clickedLeadIds — NOT processedLeadIds
          // After reload we want a fresh scan; DB check handles duplicate saves
          clickedLeadIds: Array.from(state.clickedLeadIds)
        }
      }, resolve);
    });
  }

  async function resumeScraping() {
    if (state.isActive) return;
    if (!state.sellerId) {
      log('❌ Cannot resume: No seller ID');
      return;
    }
    state.isActive = true;
    chrome.storage.local.set({ isScrapingActive: true });
    await loadClickedLeadsFromDB();

    if (state.phase === 'continuous') {
      log('▶️ ═══ RESUMING PHASE 2 AFTER RELOAD ═══');
      updateStatusIndicator();
      showNotification('Resumed: watching for new leads...', 'success');
      startContinuousMonitoring();
    } else {
      startScraping();
    }
  }

  async function startScraping() {
    if (state.isActive) return;
    if (!state.sellerId) {
      log('❌ No seller ID set. Select a seller in popup first.');
      showNotification('Please select a Seller ID first!', 'error');
      return;
    }

    state.isActive = true;
    state.phase = 'initial';
    chrome.storage.local.set({ isScrapingActive: true });

    // Reload clicked IDs for this seller session
    await loadClickedLeadsFromDB();

    log('▶️ ═══ PHASE 1: INITIAL CAPTURE ═══');
    updateStatusIndicator();
    showNotification('Phase 1: Capturing all existing leads...', 'success');

    try {
      await runInitialCapture();
      if (!state.isActive) return;

      state.phase = 'continuous';
      log('▶️ ═══ PHASE 2: WATCHING FOR NEW LEADS ═══');
      updateStatusIndicator();
      showNotification('Phase 2: Watching for new leads...', 'success');
      startContinuousMonitoring();
    } catch (error) {
      log('❌ Scraping error:', error);
      stopScraping();
    }
  }

  function stopScraping() {
    state.isActive = false;
    state.phase = 'idle';
    chrome.storage.local.set({ isScrapingActive: false });
    chrome.storage.local.remove(['leadopticsSession']);

    if (state.intervals.newLeadCheck) clearInterval(state.intervals.newLeadCheck);
    if (state.intervals.sync) clearInterval(state.intervals.sync);
    // Note: heartbeat + antiThrottle keep running even after stop (monitoring continues)
    state.intervals.newLeadCheck = null;
    state.intervals.sync = null;

    log('⏹️ SCRAPING STOPPED');
    updateStatusIndicator();
    syncLeadsToDB();
  }

  // ==================== PHASE 1: INITIAL CAPTURE ====================

  async function runInitialCapture() {
    log('📜 Scrolling entire page to capture ALL existing leads...');
    let lastHeight = 0, noChangeCount = 0, scrollCount = 0;

    while (scrollCount < CONFIG.MAX_SCROLL_ATTEMPTS && state.isActive) {
      window.scrollBy({ top: CONFIG.SCROLL_AMOUNT, behavior: 'smooth' });
      await sleep(CONFIG.SCROLL_DELAY);
      clickShowMoreButton();
      await sleep(800);
      await scanAndProcessLeads(false);

      const currentHeight = document.body.scrollHeight;
      if (currentHeight === lastHeight) {
        noChangeCount++;
        if (noChangeCount >= 3) { log('📜 Reached bottom of page'); break; }
      } else { noChangeCount = 0; lastHeight = currentHeight; }

      scrollCount++;
      if (scrollCount % 5 === 0) {
        log(`📜 Scroll ${scrollCount} | Captured: ${state.stats.total}`);
        await syncLeadsToDB();
      }
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
    await sleep(1500);
    await scanAndProcessLeads(false);
    await syncLeadsToDB();
    log(`✅ PHASE 1 COMPLETE: ${state.stats.total} leads captured | ${state.stats.clicked} auto-clicked`);
  }

  // ==================== PHASE 2: CONTINUOUS MONITORING ====================

  function startContinuousMonitoring() {
    const checkInterval = (state.settings?.refresh?.interval || 15) * 1000;

    if (state.intervals.newLeadCheck) clearInterval(state.intervals.newLeadCheck);
    if (state.intervals.sync) clearInterval(state.intervals.sync);

    state.intervals.newLeadCheck = setInterval(async () => {
      if (!state.isActive || state.phase !== 'continuous' || state.isProcessingClick) return;
      log('🔍 Scanning for new leads...');

      window.scrollTo({ top: 0, behavior: 'smooth' });
      await sleep(500);
      window.scrollBy({ top: 300, behavior: 'smooth' });
      await sleep(400);
      clickShowMoreButton();
      await sleep(400);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      await sleep(400);

      const newCount = await scanAndProcessLeads(true);
      if (newCount > 0) {
        log(`🆕 ★ Found ${newCount} NEW leads!`);
        showNotification(`${newCount} new lead(s) found!`, 'success');
      } else {
        log('🔄 No new leads found. Reloading page for fresh leads...');
        showNotification('No new leads — refreshing page...', 'info');
        // BUG FIX #6: Wait for sync + session save to complete before reload
        try { await syncLeadsToDB(); } catch (e) { log('⚠️ Pre-reload sync error:', e.message); }
        try { await saveSessionState(); } catch (e) { log('⚠️ Pre-reload state save error:', e.message); }
        // Extra safety delay to let storage writes flush
        await sleep(500);
        window.location.reload();
      }
    }, checkInterval);

    state.intervals.sync = setInterval(() => {
      if (state.isActive) syncLeadsToDB();
    }, CONFIG.SYNC_INTERVAL);

    log(`⏰ Checking every ${checkInterval / 1000}s for new leads`);
  }

  function clickShowMoreButton() {
    const buttons = document.querySelectorAll('button, a, div[role="button"]');
    for (const btn of buttons) {
      if (btn.offsetParent === null) continue;
      const text = cleanText(btn.textContent).toLowerCase();
      if ((text.includes('show more') || text.includes('load more') || text.includes('view more')) &&
          !text.includes('similar') && !text.includes('products')) {
        try { btn.click(); return true; } catch (e) {}
      }
    }
    return false;
  }

  // ==================== LEAD SCANNING ====================

  async function scanAndProcessLeads(onlyNew) {
    if (!state.isActive) return 0;
    const leadCards = findLeadCards();
    let newLeads = 0;

    for (const card of leadCards) {
      if (!state.isActive) break;
      try {
        const result = await processLeadCard(card, onlyNew);
        if (result === 'new') newLeads++;
      } catch (error) {
        log('⚠️ Card error:', error.message);
      }
    }
    return newLeads;
  }

  function findLeadCards() {
    const cards = [];
    const allElements = document.querySelectorAll('div, article, section, li');

    for (const el of allElements) {
      const text = el.textContent || '';
      const lowerText = text.toLowerCase();

      if (text.length < 100 || text.length > 10000) continue;
      if (!lowerText.includes('member since')) continue;
      if (!lowerText.includes('buy') && !lowerText.includes('requirement') && !lowerText.includes('need')) continue;

      let isBlacklisted = false;
      for (const bl of CONTENT_BLACKLIST) {
        if (lowerText.includes(bl) && text.length < 300) { isBlacklisted = true; break; }
      }
      if (isBlacklisted) continue;

      let dominated = false;
      for (const existing of cards) {
        if (existing.contains(el) || el.contains(existing)) { dominated = true; break; }
      }
      if (!dominated) cards.push(el);
    }
    return cards;
  }

  // ==================== LEAD PROCESSING ====================

  async function processLeadCard(card, onlyNew) {
    if (card.dataset.leadmagnetProcessed === 'true') return 'skipped';

    const text = card.textContent || '';
    const leadData = extractLeadData(card, text);

    if (!leadData.title || leadData.title.length < 5) {
      card.dataset.leadmagnetProcessed = 'true';
      return 'invalid';
    }

    const leadId = generateLeadId(leadData);
    leadData.leadId = leadId;

    // ── PHASE 1: capture everything, no clicking ───────────────
    if (state.phase !== 'continuous') {
      // Lock card immediately — Phase 1 never retries
      if (state.processedLeadIds.has(leadId)) {
        card.dataset.leadmagnetProcessed = 'true';
        return 'duplicate';
      }
      state.processedLeadIds.add(leadId);
      card.dataset.leadmagnetProcessed = 'true';
      card.dataset.leadmagnetLeadId = leadId;

      const dbStatus = await checkLeadInDB(leadId);
      if (dbStatus.exists) return 'duplicate';

      const filterResult = applyFilters(leadData);
      if (!filterResult.passed) {
        markCardVisual(card, 'filtered', filterResult.reason);
        state.stats.filtered++; saveStats();
        return 'filtered';
      }

      const score = calculateScore(leadData);
      leadData.score = score;
      markCardVisual(card, score >= 60 ? 'hot' : score >= 25 ? 'warm' : 'cool', score);

      leadData.capturedAt   = new Date().toISOString();
      leadData.capturePhase = 'initial';
      leadData.sellerId     = state.sellerId;
      leadData.status       = { clicked: false, clickedAt: null, clickAttempted: '' };
      state.stats.total++; state.stats.today++; saveStats();
      state.leadQueue.push(leadData);
      log(`✅ P1 CAPTURED: "${leadData.title.substring(0, 50)}" | Score: ${score}`);
      return 'new';
    }

    // ── PHASE 2: SNIPER MODE ───────────────────────────────────
    // CRITICAL: Do NOT lock card as processed until AFTER click attempt.
    // IndiaMART renders contact buttons dynamically — button may not exist
    // on first scan. If we lock early and button isn't ready → never retried.
    // Only lock permanently after:
    //   a) Already clicked → skip forever
    //   b) Click succeeded → done
    //   c) Keyword doesn't match → save and lock
    // If button not found → do NOT lock → retry on next scan cycle

    // Skip if already clicked this session
    if (state.clickedLeadIds.has(leadId)) {
      card.dataset.leadmagnetProcessed = 'true';
      markCardVisual(card, 'already-clicked', 'ALREADY CONTACTED');
      return 'already-clicked';
    }

    const dbStatus = await checkLeadInDB(leadId);

    // Already clicked in DB → lock and skip
    if (dbStatus.exists && dbStatus.clicked) {
      state.clickedLeadIds.add(leadId);
      state.processedLeadIds.add(leadId);
      card.dataset.leadmagnetProcessed = 'true';
      markCardVisual(card, 'already-clicked', 'ALREADY CONTACTED');
      log(`⏭️ Already clicked in DB: ${leadData.title.substring(0, 40)}`);
      return 'already-clicked';
    }

    // exists but NOT clicked → fall through (this was the original bug — now fixed)
    // brand new → fall through

    const score = calculateScore(leadData);
    leadData.score = score;
    markCardVisual(card, score >= 60 ? 'hot' : score >= 25 ? 'warm' : 'cool', score);

    log(`🔍 P2 SCAN: "${leadData.title.substring(0, 50)}" | Score: ${score} | inDB: ${dbStatus.exists}`);

    if (shouldAutoClick(leadData, score)) {

      // ── FRESHNESS GATE: only click leads within max age ─────────
      // minutesAgo = 0  means "just now / 0 sec" → fresh
      // minutesAgo = -1 means timestamp was unrecognised → treat as stale, skip click
      // maxLeadAge comes from settings (default 5 mins)
      const maxAge = Math.min(state.settings?.autoClick?.maxLeadAge ?? 5, 5); // hard cap: never exceed 5 min
      const minutesAgo = parseTimestampToMinutes(leadData.timestamp);
      // minutesAgo === -1 means timestamp was unrecognised → treat as old, do NOT auto-click
      const isFresh = minutesAgo !== -1 && minutesAgo <= maxAge;
      if (!isFresh) {
        log(`⏭️ Lead too old (${minutesAgo} mins) — skip click, save only`);
        // Save to DB if new, lock card, no click
        state.processedLeadIds.add(leadId);
        card.dataset.leadmagnetProcessed = 'true';
        card.dataset.leadmagnetLeadId = leadId;
        if (!dbStatus.exists) {
          leadData.capturedAt   = new Date().toISOString();
          leadData.capturePhase = 'continuous';
          leadData.sellerId     = state.sellerId;
          leadData.status       = { clicked: false, clickedAt: null, clickAttempted: '' };
          state.stats.total++; state.stats.today++; saveStats();
          state.leadQueue.push(leadData);
          await syncLeadsToDB();
        }
        return 'old';
      }

      log(`🎯 ★ KEYWORD MATCH (${minutesAgo === -1 ? '0 sec' : minutesAgo + ' min'}): "${leadData.title.substring(0, 40)}" — finding button...`);

      // Save to DB if brand new (before click attempt so we have a record)
      if (!dbStatus.exists) {
        leadData.capturedAt   = new Date().toISOString();
        leadData.capturePhase = 'continuous';
        leadData.sellerId     = state.sellerId;
        leadData.status       = { clicked: false, clickedAt: null, clickAttempted: '' };
        state.stats.total++; state.stats.today++; saveStats();
        state.leadQueue.push(leadData);
        await syncLeadsToDB();
      }

      // ── DAILY CLICK LIMIT CHECK ───────────────────────────────
      const dailyLimit = state.settings?.autoClick?.dailyClickLimit ?? 0;
      if (dailyLimit > 0 && (state.stats.clickedToday || 0) >= dailyLimit) {
        log(`🚫 Daily click limit reached (${state.stats.clickedToday}/${dailyLimit}) — skipping click`);
        markCardVisual(card, 'filtered', `DAILY LIMIT (${dailyLimit})`);
        state.processedLeadIds.add(leadId);
        card.dataset.leadmagnetProcessed = 'true';
        return 'limit-reached';
      }

      // Attempt click
      const clicked = await performAutoClick(card, leadData, leadId);

      if (clicked) {
        // Click succeeded → lock card permanently
        const flagVal = 'Y';
        await updateClickAttempted(leadId, flagVal);
        log(`✅ ★ CLICK SUCCESS — locking card`);
        state.stats.clickedToday = (state.stats.clickedToday || 0) + 1;  // increment daily counter
        saveStats();
        state.processedLeadIds.add(leadId);
        card.dataset.leadmagnetProcessed = 'true';
        card.dataset.leadmagnetLeadId = leadId;
      } else {
        // Button not found or click failed → do NOT lock card
        // It will be retried on next scan cycle (5s reload)
        await updateClickAttempted(leadId, 'N');
        log(`⚠️ Button not ready — card NOT locked — will retry next cycle`);
        // Remove from processedLeadIds in case it was added during this run
        state.processedLeadIds.delete(leadId);
        card.dataset.leadmagnetProcessed = 'false';
      }

    } else {
      // Keyword did not match — lock card, save if new, no click
      state.processedLeadIds.add(leadId);
      card.dataset.leadmagnetProcessed = 'true';
      card.dataset.leadmagnetLeadId = leadId;

      if (!dbStatus.exists) {
        leadData.capturedAt   = new Date().toISOString();
        leadData.capturePhase = 'continuous';
        leadData.sellerId     = state.sellerId;
        leadData.status       = { clicked: false, clickedAt: null, clickAttempted: '' };
        state.stats.total++; state.stats.today++; saveStats();
        state.leadQueue.push(leadData);
        await syncLeadsToDB();
      }
    }

    return 'new';
  }

  // ==================== DATA EXTRACTION ====================

  function extractLeadData(card, text) {
    const data = {
      title: '', timestamp: '',
      location: { city: '', state: '', full: '' },
      category: '',        // IndiaMART category e.g. "Artificial Grass"
      productName: '',     // IndiaMART product e.g. "Artificial Turf"
      quantity: '',
      orderValue: null,    // { min, max, display }
      requirementType: '',
      material: '',
      specifications: {},  // key-value pairs
      buyer: {
        memberSince: '', businessType: '', buys: '',
        engagement: { requirements: 0, calls: 0, replies: 0 }
      },
      detectedCategory: 'General',
      rawText: text.substring(0, 5000)
    };

    // ── 1. TITLE: strip merged junk IndiaMART appends after title
    // Raw: "Artificial Grass Carpet2 mins agoRaigarhClick here..."
    // Also catches: "Indoor Playground0 secJaipur" → "Indoor Playground"
    const titleRaw = text.replace(/\n/g, ' ');
    let titleClean = titleRaw
      .replace(/\d*\s*(sec|secs|second|seconds|min|mins|minute|minutes|hr|hrs|hour|hours|day|days)\s*ago.*/i, '')
      .replace(/0\s*(sec|secs|second|seconds|min|mins).*/i, '')  // catches "0 sec" right after title
      .replace(/\bjust\s*now\b.*/i, '')
      .replace(/\byesterday\b.*/i, '')
      .replace(/\btoday\b.*/i, '')
      .replace(/Click here.*/i, '')
      .replace(/View [Ss]imilar.*/i, '')
      .replace(/Shortlist.*/i, '')
      .trim();
    // Remove leading city/state/location noise if title starts with it
    titleClean = titleClean.replace(/^[A-Z][a-z]+,\s*[A-Z][a-z\s]+\s*/,'').trim();
    data.title = titleClean.substring(0, 200) || 'Untitled Lead';

    // ── 2. TIMESTAMP
    const tsMatch = text.match(/(\d+\s*(?:sec|secs|min|mins|hr|hrs|hour|hours|day|days)\s*ago|Just\s*Now|Yesterday|Today|\d+\s*Days?\s*Old)/i);
    if (tsMatch) data.timestamp = cleanText(tsMatch[1]);

    // ── 3. LOCATION — validated against known Indian states to prevent product names bleeding in
    // Bad example: "Cement Grill, Fiberglass Pools" was being picked up as city, state
    const INDIAN_STATES = new Set([
      'andhra pradesh','arunachal pradesh','assam','bihar','chhattisgarh','goa','gujarat',
      'haryana','himachal pradesh','jharkhand','karnataka','kerala','madhya pradesh',
      'maharashtra','manipur','meghalaya','mizoram','nagaland','odisha','punjab','rajasthan',
      'sikkim','tamil nadu','telangana','tripura','uttar pradesh','uttarakhand','west bengal',
      'delhi','jammu','ladakh','chandigarh','puducherry','andaman','lakshadweep',
      'dadra','daman','jammu and kashmir'
    ]);

    const INDIAN_CITIES = new Set([
      'mumbai','delhi','bangalore','bengaluru','pune','chennai','hyderabad','kolkata',
      'ahmedabad','jaipur','lucknow','surat','nagpur','indore','bhopal','patna',
      'vadodara','ludhiana','agra','nashik','raipur','raigarh','faridabad','meerut',
      'rajkot','varanasi','srinagar','aurangabad','dhanbad','amritsar','navi mumbai',
      'allahabad','prayagraj','ranchi','coimbatore','jabalpur','gwalior','vijayawada',
      'jodhpur','madurai','raipur','kota','guwahati','chandigarh','solapur','hubli',
      'tiruchirappalli','trichy','bareilly','moradabad','mysore','gurgaon','gurugram',
      'noida','aligarh','jalandhar','bhubaneswar','salem','warangal','mira bhayandar',
      'thiruvananthapuram','bhiwandi','saharanpur','gorakhpur','guntur','amravati',
      'bikaner','noida','dehradun','durgapur','asansol','nanded','kolhapur','ajmer',
      'akola','gulbarga','jamshedpur','bokaro','siliguri','udaipur','mangalore',
      'belgaum','belagavi','tiruppur','malegaon','jalgaon','ujjain','sangli',
      'erode','new delhi','thane','kalyan','dombivli','panipat','rohtak','hisar',
      'karnal','ambala','sonipat','yamunanagar','patiala','bathinda','mohali',
      'firozabad','mathura','muzaffarnagar','hapur','shamli','muzzafarpur','bhagalpur',
      'gaya','darbhanga','begusarai','samastipur','cuttack','berhampur','rourkela',
      'bilaspur','korba','durg','rajnandgaon','satna','rewa','sagar','damoh',
      'katni','chhindwara','khandwa','vidisha','dewas','mandsaur','neemuch',
      'kakinada','nellore','kurnool','rajahmundry','tirupati','anantapur',
      'vizag','visakhapatnam','eluru','ongole','kadapa','chittoor','sivakasi',
      'vellore','tirunelveli','thoothukudi','nagercoil','kanchipuram','hosur',
      'thanjavur','kumbakonam','dindigul','karur','namakkal','dharmapuri',
      'shimla','dharamsala','mandi','solan','baddi','paonta sahib',
      'jammu','samba','kathua','udhampur','anantnag','baramulla',
      'leh','kargil','gangtok','siliguri','jorhat','dibrugarh','silchar',
      'imphal','shillong','aizawl','kohima','itanagar','agartala','dispur',
      'panaji','margao','mapusa','vasco','pondicherry','karaikal'
    ]);

    // Strategy 1: Try direct DOM element first (most reliable)
    // IndiaMART renders location in specific elements
    const locSelectors = [
      '.bklc', '.lctn', '.buyer-location', '[class*="location"]',
      '[class*="city"]', '[class*="lctn"]', '.kp-city', '.ql-city',
      'span[class*="loc"]', 'div[class*="loc"]'
    ];
    for (const sel of locSelectors) {
      const el = card.querySelector ? card.querySelector(sel) : null;
      if (el && el.textContent.trim()) {
        const locText = cleanText(el.textContent).trim();
        if (locText && locText.length < 50) {
          const parts = locText.split(',').map(p => p.trim());
          if (parts.length >= 2) {
            data.location.city  = parts[0];
            data.location.state = parts[1];
            data.location.full  = locText;
          } else {
            data.location.city = parts[0];
            data.location.full = parts[0];
          }
          break;
        }
      }
    }

    // Strategy 2: Regex "City, State" — validated against known Indian states
    if (!data.location.city) {
      const locCandidates = [...text.matchAll(/(?:from\s+)?([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+){0,2}),\s*([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+){0,2})(?!\s*\d)/g)];
      for (const m of locCandidates) {
        const candidateState = cleanText(m[2]).toLowerCase();
        if (INDIAN_STATES.has(candidateState)) {
          data.location.city  = cleanText(m[1]);
          data.location.state = cleanText(m[2]);
          data.location.full  = `${data.location.city}, ${data.location.state}`;
          break;
        }
      }
    }

    // Strategy 3: City-only match — IndiaMART sometimes shows just city with no state
    // e.g. "from Raigarh" or "Patna" standalone
    if (!data.location.city) {
      // Try "from CityName" pattern first
      const fromMatch = text.match(/\bfrom\s+([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)?)\b/);
      if (fromMatch) {
        const candidate = cleanText(fromMatch[1]).toLowerCase();
        if (INDIAN_CITIES.has(candidate) || INDIAN_STATES.has(candidate)) {
          data.location.city = cleanText(fromMatch[1]);
          data.location.full = data.location.city;
        }
      }
    }

    // Strategy 4: Scan entire text for any known city name as standalone word
    if (!data.location.city) {
      const words = text.replace(/\n/g, ' ').split(/\s+/);
      for (let i = 0; i < words.length; i++) {
        // Try 1-word and 2-word city names
        const w1 = words[i].replace(/[^a-zA-Z]/g, '').toLowerCase();
        const w2 = i + 1 < words.length ? (w1 + ' ' + words[i+1].replace(/[^a-zA-Z]/g, '').toLowerCase()) : '';
        if (w2 && INDIAN_CITIES.has(w2)) {
          data.location.city = words[i] + ' ' + words[i+1];
          data.location.full = data.location.city;
          break;
        }
        if (INDIAN_CITIES.has(w1)) {
          data.location.city = words[i].replace(/[^a-zA-Z\s]/g, '');
          data.location.full = data.location.city;
          break;
        }
      }
    }

    // ── 4. CATEGORY > PRODUCT  (e.g. "Artificial Grass>Artificial Turf")
    // IndiaMART puts "Category>Product" after noisy nav links like "BuyLeads from StateCategory>"
    // Strip all "Click here to view BuyLeads from [Location]" fragments first
    const raw2 = text.replace(/Click here to view BuyLeads from (?:[A-Z][A-Za-z\s,&]+?)(?=[A-Z][A-Za-z])/g, '');
    // Then extract: the category always starts with a capital after a word boundary
    const catProdMatch = raw2.match(/(?<![A-Z])([A-Z][a-z]+(?:\s[A-Z][a-z]+)*(?:\s&\s[A-Z][a-z]+)?)>([A-Za-z][A-Za-z\s&\/\-]+?)(?=\s+(?:Quantity|Material|Station|Equipment|Age|Seating|Pile|Width|Length|Probable|View|Click|Buyer|For\b|Type\b))/);
    if (catProdMatch) {
      data.category    = cleanText(catProdMatch[1]);
      data.productName = cleanText(catProdMatch[2]);
    } else {
      // Fallback: simpler pattern
      const simpleMatch = raw2.match(/\b([A-Z][A-Za-z\s&]{3,35})>([A-Za-z\s&]{3,40})/);
      if (simpleMatch) {
        data.category    = cleanText(simpleMatch[1]);
        data.productName = cleanText(simpleMatch[2]);
      }
    }

    // ── 5. ORDER VALUE  "Rs. 17,000 - 24,000" or "Rs. 3,000 to 10,000"
    const ovMatch = text.match(/(?:Probable\s+)?Order\s*Value[:\s]*(?:Rs\.?\s*)?([\d,]+)\s*[-–to]+\s*(?:Rs\.?\s*)?([\d,]+)/i);
    if (ovMatch) {
      const mn = parseInt(ovMatch[1].replace(/,/g, ''));
      const mx = parseInt(ovMatch[2].replace(/,/g, ''));
      data.orderValue = {
        min: mn, max: mx,
        display: `₹${mn.toLocaleString('en-IN')} – ₹${mx.toLocaleString('en-IN')}`
      };
    }

    // ── 6. SPECIFICATIONS — extract all key: value pairs
    const specPatterns = [
      'Quantity', 'Material', 'Seating Capacity', 'Width', 'Length',
      'Pile Height', 'Application', 'Station Type', 'Equipment Type',
      'Age Group', 'Primary Material', 'Bench Length', 'Color', 'Size',
      'Brand', 'Usage', 'Requirement Type', 'Buyer Filled Details',
      'Frame Material', 'Surface Material', 'Weight Capacity', 'Shape',
      'Thickness', 'Pattern', 'Finish', 'Certification', 'Country of Origin'
    ];
    const specs = {};
    for (const key of specPatterns) {
      const pat = new RegExp(key + '[:\\s]+([^\\n]{2,80}?)(?=(?:[A-Z][a-z]|Probable|View|Click|Buyer|$))', 'i');
      const m = text.match(pat);
      if (m) {
        const val = cleanText(m[1]).replace(/[\s,]+$/, '');
        if (val && val.length > 1) specs[key] = val;
      }
    }
    data.specifications = specs;
    if (specs['Quantity'])  data.quantity = specs['Quantity'];
    if (specs['Material'])  data.material = specs['Material'];
    if (specs['Requirement Type']) data.requirementType = specs['Requirement Type'];

    // ── 7. BUYER INFO
    const memberMatch = text.match(/Member\s*since[:\s]*(\d{4})/i);
    if (memberMatch) data.buyer.memberSince = memberMatch[1];

    const bizMatch = text.match(/Business\s*type[:\s]*([^\n]{2,50})/i);
    if (bizMatch) data.buyer.businessType = cleanText(bizMatch[1]);

    const reqNumMatch = text.match(/Requirements?[:\s]*(\d+)/i);
    if (reqNumMatch) data.buyer.engagement.requirements = parseInt(reqNumMatch[1]) || 0;

    // ── 8. DETECTED CATEGORY for internal use
    if (data.category) {
      data.detectedCategory = data.category;
    } else {
      const tl = data.title.toLowerCase();
      if (/artificial\s*(grass|turf)/i.test(tl))       data.detectedCategory = 'Artificial Grass';
      else if (/swing|jhula|झूला|zula/i.test(tl))       data.detectedCategory = 'Swings';
      else if (/bench|park bench/i.test(tl))             data.detectedCategory = 'Garden Furniture';
      else if (/playground|play station|play equipment/i.test(tl)) data.detectedCategory = 'Playground Equipment';
      else if (/foam mat|eva foam|rubber mat|rubber floor/i.test(tl)) data.detectedCategory = 'Flooring & Mats';
      else if (/flooring|court floor/i.test(tl))         data.detectedCategory = 'Sports Flooring';
      else if (/fencing|fence/i.test(tl))               data.detectedCategory = 'Fencing';
    }

    return data;
  }

  // ==================== FILTERING ====================

  function applyFilters(leadData) {
    const f = state.settings?.filter || {};

    if (f.targetCities?.length > 0) {
      const city = (leadData.location?.city || '').toLowerCase();
      const full = (leadData.location?.full || '').toLowerCase();
      if (!f.targetCities.some(c => city.includes(c.toLowerCase()) || full.includes(c.toLowerCase()))) {
        return { passed: false, reason: 'City not matched' };
      }
    }

    if (f.excludedKeywords?.length > 0) {
      const searchText = (leadData.title + ' ' + leadData.rawText).toLowerCase();
      if (f.excludedKeywords.some(k => searchText.includes(k.toLowerCase()))) {
        return { passed: false, reason: 'Contains excluded keyword' };
      }
    }

    if (leadData.orderValue) {
      const minFilter = f.minOrderValue || 0;
      const maxFilter = f.maxOrderValue || 10000000;
      if (leadData.orderValue.max < minFilter) return { passed: false, reason: 'Value too low' };
      if (leadData.orderValue.min > maxFilter) return { passed: false, reason: 'Value too high' };
    }

    return { passed: true };
  }

  // ==================== SCORING ====================

  function calculateScore(leadData) {
    // ── 30/60/10 SCORING ──────────────────────────────────────
    // RECENCY     =  30 pts  (fresh leads have less competition)
    // ORDER VALUE =  60 pts  (bigger deal = more worth clicking)
    // ENGAGEMENT  =  10 pts  (active buyer + urgency signals)
    // TOTAL MAX   = 100 pts
    // HOT  = 60+  |  WARM = 25–59  |  COOL = 0–24
    // ─────────────────────────────────────────────────────────
    let score = 0;

    // ── RECENCY (max 30 pts) ──
    const minutes = parseTimestampToMinutes(leadData.timestamp);
    if (minutes >= 0) {
      if      (minutes === 0)  score += 30;   // Just now
      else if (minutes <= 2)   score += 28;   // 1–2 min ago
      else if (minutes <= 5)   score += 25;   // 3–5 min ago
      else if (minutes <= 10)  score += 20;   // 6–10 min ago
      else if (minutes <= 20)  score += 15;   // 11–20 min ago
      else if (minutes <= 30)  score += 10;   // 21–30 min ago
      else if (minutes <= 60)  score += 5;    // 31–60 min ago
      else if (minutes <= 120) score += 2;    // 1–2 hrs ago
      // older = 0 pts
    }

    // ── ORDER VALUE (max 60 pts) ──
    const ov = (leadData.orderValue?.max || 0) || (leadData.orderValue?.min || 0);
    if (ov > 0) {
      if      (ov >= 500000) score += 60;   // ₹5 lakh+
      else if (ov >= 200000) score += 50;   // ₹2–5 lakh
      else if (ov >= 100000) score += 40;   // ₹1–2 lakh
      else if (ov >= 50000)  score += 30;   // ₹50k–1 lakh
      else if (ov >= 20000)  score += 20;   // ₹20k–50k
      else if (ov >= 5000)   score += 10;   // ₹5k–20k
      else                   score += 3;    // any value given
    }

    // ── ENGAGEMENT (max 10 pts) ──
    // Urgency keywords in lead text
    const txt = (leadData.title + ' ' + (leadData.rawText || '')).toLowerCase();
    let eng = 0;
    if (txt.includes('urgent'))    eng += 5;
    if (txt.includes('immediate')) eng += 4;
    if (txt.includes('asap'))      eng += 4;
    if (txt.includes('bulk'))      eng += 3;
    if (txt.includes('today'))     eng += 3;
    // Buyer seniority (older = more serious buyer)
    const memberYear = parseInt(leadData.buyer?.memberSince);
    if (memberYear > 2000) {
      const yrs = new Date().getFullYear() - memberYear;
      if      (yrs >= 5) eng += 4;
      else if (yrs >= 3) eng += 2;
      else if (yrs >= 1) eng += 1;
    }
    score += Math.min(eng, 10);

    return Math.min(score, 100);
  }

  // ==================== AUTO-CLICK DECISION ====================

  function shouldAutoClick(leadData, score) {
    const ac = state.settings?.autoClick;

    // Default to enabled=true if setting is missing/undefined
    if (ac?.enabled === false) {
      log(`⏭️ Auto-click disabled in settings`);
      return false;
    }

    // ── DAY LIMIT: only click within allowed time window ──────────
    // Only applies when enableTimeWindow is true AND both times are set.
    // When toggle is off, clickStartTime/clickEndTime are null → skipped automatically.
    // Double-checked with enableTimeWindow flag for safety.
    if (ac?.enableTimeWindow && ac?.clickStartTime && ac?.clickEndTime) {
      const now  = new Date();
      const hhmm = now.getHours() * 60 + now.getMinutes();
      const [sh, sm] = ac.clickStartTime.split(':').map(Number);
      const [eh, em] = ac.clickEndTime.split(':').map(Number);
      const start = sh * 60 + sm;
      const end   = eh * 60 + em;
      // ✅ FIX: handle overnight ranges (e.g. 22:00 → 06:00)
      let inWindow;
      if (start <= end) {
        // Normal range: e.g. 09:00–18:00
        inWindow = hhmm >= start && hhmm <= end;
      } else {
        // Overnight range: e.g. 22:00–06:00
        inWindow = hhmm >= start || hhmm <= end;
      }
      if (!inWindow) {
        log(`⏭️ Outside click window (${ac.clickStartTime}–${ac.clickEndTime}) current: ${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}`);
        return false;
      }
    }

    if (state.clickedLeadIds.has(leadData.leadId)) {
      log(`⏭️ Already clicked: ${leadData.leadId}`);
      return false;
    }

    const minScore = ac?.minScore ?? 0;
    if (score < minScore) {
      log(`⏭️ Score ${score} < minScore ${minScore}`);
      return false;
    }

    // ── STRUCTURED OR MATCHING ──────────────────────────────────
    // Trigger auto-click if ANY ONE of these matches:
    //   • Category keyword → matches IndiaMART category / detectedCategory field directly
    //   • City keyword     → location.city + location.state ONLY (not rawText)
    //   • Order value      → numeric check against orderValue.max
    // ───────────────────────────────────────────────────────────
    const cats = state.keywordCategories || { category: [], city: [], value: [] };
    const hasCategories = cats.category?.length > 0 || cats.city?.length > 0 || cats.value?.length > 0;

    // Fall back to flat keyword list if no categories saved yet
    if (!hasCategories && state.keywords.length === 0) {
      log(`⚠️ No keywords set for this seller — clicking all leads`);
      return true;
    }

    if (!hasCategories) {
      // Legacy flat keyword match against title + category
      const titleText = (leadData.title + ' ' + (leadData.category || '') + ' ' + (leadData.detectedCategory || '')).toLowerCase();
      const matched = state.keywords.filter(k => k && titleText.includes(k.toLowerCase()));
      if (matched.length > 0) {
        leadData.matchedKeywords = matched;
        log(`🔑 Keyword match (flat): [${matched.join(', ')}]`);
        return true;
      }
      log(`⏭️ No keyword match. Keywords: [${state.keywords.join(', ')}]`);
      return false;
    }

    // ── 1. CATEGORY MATCH ────────────────────────────────────────
    // Match against IndiaMART's actual category field (most reliable signal)
    // Priority:
    //   a) Exact match with category or detectedCategory
    //   b) Keyword is substring of category — e.g. "playground" in "Outdoor Playground Equipment"
    //   c) Category is substring of keyword — e.g. "Swings" in "outdoor garden swings"
    //   d) 2+ meaningful words (4+ chars) from keyword found in title (fallback only)
    let categoryMatched = null;
    const categoryKeywords = cats.category || [];
    if (categoryKeywords.length > 0) {
      const leadCat  = (leadData.category || leadData.detectedCategory || '').toLowerCase().trim();
      const leadProd = (leadData.productName || '').toLowerCase().trim();
      const leadTitle = (leadData.title || '').toLowerCase().trim();

      for (const k of categoryKeywords) {
        if (!k) continue;
        const kl = k.toLowerCase().trim();

        // a) Exact match
        if (kl === leadCat || kl === leadProd) {
          categoryMatched = k;
          log(`🎯 Category match (exact): "${k}" == "${leadCat}"`);
          break;
        }

        // b) Keyword substring of category — "indoor playground" in "Indoor Playground Equipment"
        if (leadCat && leadCat.includes(kl)) {
          categoryMatched = k;
          log(`🎯 Category match (kw in category): "${k}" in "${leadCat}"`);
          break;
        }
        if (leadProd && leadProd.includes(kl)) {
          categoryMatched = k;
          log(`🎯 Category match (kw in productName): "${k}" in "${leadProd}"`);
          break;
        }

        // c) Category substring of keyword — "swings" in "outdoor garden swings equipment"
        if (leadCat && kl.includes(leadCat)) {
          categoryMatched = k;
          log(`🎯 Category match (category in kw): "${leadCat}" in "${k}"`);
          break;
        }

        // d) 2+ words (4+ chars) from keyword found in BOTH title AND category (not title alone — too noisy)
        const kWords = kl.split(/\s+/).filter(w => w.length >= 4);
        if (kWords.length >= 2) {
          const catMatches   = kWords.filter(w => leadCat.includes(w));
          const titleMatches = kWords.filter(w => leadTitle.includes(w));
          // Must match at least 1 word in category + 1 word in title
          if (catMatches.length >= 1 && titleMatches.length >= 1) {
            categoryMatched = k;
            log(`🎯 Category match (words in cat+title): cat=[${catMatches}] title=[${titleMatches}]`);
            break;
          }
        }
      }
    }

    // ── 2. CITY MATCH ────────────────────────────────────────────
    // Match ONLY against structured location fields — not rawText
    // Prevents false match from breadcrumb "BuyLeads from Mumbai"
    let cityMatched = null;
    if (cats.city.length > 0) {
      const cityText = [
        leadData.location?.city  || '',
        leadData.location?.state || '',
        leadData.location?.full  || ''
      ].join(' ').toLowerCase();

      cityMatched = cats.city.find(k => k && cityText.includes(k.toLowerCase()));
      if (cityMatched) {
        log(`📍 City match: "${cityMatched}" → ${leadData.location?.city}, ${leadData.location?.state}`);
      }
    }

    // ── 3. ORDER VALUE MATCH ─────────────────────────────────────
    // value keywords are treated as minimum order value in ₹
    // e.g. value keyword "50000" means "only click if order >= ₹50,000"
    // Also supports text urgency keywords like "bulk", "urgent"
    let valueMatched = null;
    if (cats.value.length > 0) {
      const ovMax = leadData.orderValue?.max || leadData.orderValue?.min || 0;
      const titleForValue = (leadData.title + ' ' + (leadData.rawText || '')).toLowerCase();

      for (const k of cats.value) {
        if (!k) continue;
        const num = parseInt(k.replace(/[^0-9]/g, ''));
        if (!isNaN(num) && num > 0) {
          // Numeric: treat as minimum order value
          if (ovMax >= num) {
            valueMatched = k;
            log(`💰 Value match: ₹${ovMax.toLocaleString('en-IN')} >= ₹${num.toLocaleString('en-IN')} (keyword "${k}")`);
            break;
          }
        } else {
          // Text urgency keyword: match in title/rawText
          if (titleForValue.includes(k.toLowerCase())) {
            valueMatched = k;
            log(`💰 Value keyword match: "${k}"`);
            break;
          }
        }
      }
    }

    // ── OR LOGIC: any one match is enough ───────────────────────
    const anyMatch = categoryMatched || cityMatched || valueMatched;

    if (!anyMatch) {
      const tried = [];
      if (categoryKeywords.length > 0) tried.push(`category:[${categoryKeywords.join(',')}]`);
      if (cats.city?.length > 0)    tried.push(`city:[${cats.city.join(',')}]`);
      if (cats.value?.length > 0)   tried.push(`value:[${cats.value.join(',')}]`);
      log(`⏭️ No match. Tried: ${tried.join(' | ')} | Lead: "${leadData.title.substring(0,40)}" | cat: "${(leadData.category || leadData.detectedCategory || '—')}" | ${leadData.location?.city}`);
      return false;
    }

    // Record what matched for DB logging
    leadData.matchedKeywords = [categoryMatched, cityMatched, valueMatched].filter(Boolean);
    log(`✅ Auto-click triggered by: category="${categoryMatched || '—'}" city="${cityMatched || '—'}" value="${valueMatched || '—'}"`);
    return true;
  }

  // ==================== AUTO-CLICK EXECUTION ====================

  async function performAutoClick(card, leadData, leadId) {
    if (state.isProcessingClick) {
      let waited = 0;
      while (state.isProcessingClick && waited < 15000) { await sleep(500); waited += 500; }
      if (state.isProcessingClick) return false;
    }

    state.isProcessingClick = true;

    try {
      if (state.clickedLeadIds.has(leadId)) return false;

      // Wait up to 3s for button to appear (IndiaMART renders buttons dynamically)
      const contactBtn = await waitForContactButton(card, 3000);
      if (!contactBtn) {
        log('⚠️ Contact button NOT FOUND after waiting — will retry next cycle');
        return false;
      }
      log(`🔘 Button found: "${cleanText(contactBtn.textContent).substring(0, 30)}"`);

      // Random 3–5 seconds before clicking (human-like behaviour)
      const delay = randomDelay(3000, 5000);
      showClickCountdown(card, delay);

      contactBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await sleep(800);
      await sleep(delay);

      contactBtn.click();
      log('🖱️ ★ CLICKED "Contact Buyer Now"');

      await sleep(CONFIG.POPUP_WAIT);

      // Close popup with retries
      if (state.settings?.autoClick?.autoClosePopup !== false) {
        for (let attempt = 1; attempt <= CONFIG.POPUP_CLOSE_RETRIES; attempt++) {
          const closed = await closePopup();
          if (closed) break;
          if (attempt < CONFIG.POPUP_CLOSE_RETRIES) await sleep(CONFIG.POPUP_RETRY_DELAY);
        }
      }

      await markLeadClickedInDB(leadId, leadData);
      state.clickedLeadIds.add(leadId);
      state.stats.clicked++;
      saveStats();

      markCardVisual(card, 'clicked', 'CONTACTED');
      log(`✅ ★ CONTACTED: "${leadData.title.substring(0, 40)}"`);
      showNotification(`Contacted: ${leadData.title.substring(0, 30)}...`, 'success');

      chrome.runtime.sendMessage({ action: 'LEAD_CLICKED', leadData: { title: leadData.title, leadId } }).catch(() => {});

      // Random 0–10 seconds cooldown after click before next action
      const cooldown = randomDelay(0, 10000);
      log(`⏳ Post-click cooldown: ${(cooldown/1000).toFixed(1)}s`);
      await sleep(cooldown);

      return true;
    } catch (error) {
      log('❌ Auto-click error:', error.message);
      return false;
    } finally {
      state.isProcessingClick = false;
    }
  }

  // ==================== FIND CONTACT BUTTON ====================

  function findContactButton(card) {
    // ── EXACT IndiaMART selector (confirmed via console) ──────────
    // Structure: <div class="Slid_CTA">
    //              <div class="btnCBN btnCBN1" onclick="contactbuyernow(N,this.id,...)">
    //                <span>Contact Buyer Now</span>
    //              </div>
    //            </div>
    // The button is a DIV with class "btnCBN", NOT a <button> element.

    // 1. Direct: inside card
    const direct = card.querySelector('.btnCBN');
    if (direct) return direct;

    // 2. Inside Slid_CTA inside card
    const cta = card.querySelector('.Slid_CTA .btnCBN');
    if (cta) return cta;

    // 3. Walk up to 6 parent levels
    let parent = card.parentElement;
    for (let i = 0; i < 6 && parent; i++) {
      const btn = parent.querySelector('.btnCBN');
      if (btn) return btn;
      parent = parent.parentElement;
    }

    // 4. Full page — find btnCBN closest to this card by position
    const cardRect = card.getBoundingClientRect();
    let closest = null;
    let closestDist = Infinity;

    document.querySelectorAll('.btnCBN').forEach(btn => {
      if (btn.offsetParent === null) return;
      const r = btn.getBoundingClientRect();
      const dist = Math.abs(r.top - cardRect.top) + Math.abs(r.left - cardRect.left);
      if (dist < closestDist) { closestDist = dist; closest = btn; }
    });

    if (closest) {
      // BUG FIX #7: Only accept page-level match if close enough (< 200px)
      // Prevents clicking a completely different lead's button
      if (closestDist > 200) {
        log(`⚠️ btnCBN found but too far (${Math.round(closestDist)}px) — likely wrong lead, ignoring`);
        return null;
      }
      log(`🔍 btnCBN found via page search (${Math.round(closestDist)}px from card)`);
      return closest;
    }

    log('⚠️ btnCBN NOT FOUND — button missing on page');
    return null;
  }

  // Wait up to maxWait ms for btnCBN to appear (handles lazy render)
  async function waitForContactButton(card, maxWait = 3000) {
    const step = 300;
    let waited = 0;
    while (waited <= maxWait) {
      const btn = findContactButton(card);
      if (btn) return btn;
      await sleep(step);
      waited += step;
    }
    return null;
  }

  // ==================== POPUP CLOSE ====================

  async function closePopup() {
    await sleep(CONFIG.POPUP_CLOSE_DELAY);

    const closeSelectors = [
      '.modal .close', '.popup .close', '[aria-label="Close"]', 'button.close',
      '[class*="closeBtn"]', '[class*="modalClose"]', '[class*="popup"] [class*="close"]'
    ];
    for (const sel of closeSelectors) {
      try {
        const buttons = document.querySelectorAll(sel);
        for (const btn of buttons) {
          if (btn.offsetParent === null) continue;
          const text = cleanText(btn.textContent);
          if (text === '×' || text === 'X' || text === '' || text.toLowerCase() === 'close') {
            btn.click();
            await sleep(300);
            log('✅ Popup closed via button');
            return true;
          }
        }
      } catch (e) {}
    }

    // ✅ FIX: Try Escape key but don't assume it worked
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true }));
    await sleep(500);

    // Check if any modal/popup is still visible
    const modals = document.querySelectorAll('.modal, .popup, [class*="modal"], [class*="popup"], [class*="overlay"]');
    for (const m of modals) {
      if (m.offsetParent !== null && m.offsetHeight > 50) {
        log('⚠️ Popup still visible after Escape');
        return false;
      }
    }
    log('✅ Popup closed via Escape or already gone');
    return true;
  }

  // ==================== COUNTDOWN OVERLAY ====================

  function showClickCountdown(card, delay) {
    card.querySelectorAll('.leadmagnet-click-overlay').forEach(el => el.remove());
    const overlay = document.createElement('div');
    overlay.className = 'leadmagnet-click-overlay';
    overlay.innerHTML = `
      <div class="leadmagnet-countdown-box">
        <div class="leadmagnet-countdown-icon">🎯</div>
        <div class="leadmagnet-countdown-text">AUTO-CLICKING IN</div>
        <div class="leadmagnet-countdown-number">${Math.ceil(delay / 1000)}</div>
        <div class="leadmagnet-countdown-text">SECONDS</div>
      </div>
    `;
    if (window.getComputedStyle(card).position === 'static') card.style.position = 'relative';
    card.appendChild(overlay);

    let seconds = Math.ceil(delay / 1000);
    const numEl = overlay.querySelector('.leadmagnet-countdown-number');
    const interval = setInterval(() => {
      seconds--;
      if (numEl) numEl.textContent = Math.max(0, seconds);
      if (seconds <= 0) clearInterval(interval);
    }, 1000);
    setTimeout(() => { if (overlay.parentNode) overlay.remove(); clearInterval(interval); }, delay + 500);
  }

  // ==================== VISUAL BADGES ====================

  function markCardVisual(card, type, info) {
    card.querySelectorAll('.leadmagnet-badge').forEach(b => b.remove());
    const badge = document.createElement('div');
    badge.className = 'leadmagnet-badge leadmagnet-badge-' + type;
    const styles = {
      hot: '🔥 HOT', warm: '⭐ WARM', cool: '💧 COOL',
      clicked: '✅ CONTACTED', 'already-clicked': '✓ ALREADY CONTACTED', filtered: '⛔'
    };
    badge.textContent = type === 'filtered' ? `⛔ ${info}` :
                        type === 'clicked' || type === 'already-clicked' ? styles[type] :
                        `${styles[type]} (${info})`;
    if (window.getComputedStyle(card).position === 'static') card.style.position = 'relative';
    card.appendChild(badge);
  }

  // ==================== STATUS INDICATOR ====================

  function injectStatusIndicator() {
    // ── Inject CSS for badges + status bar ──
    if (!document.getElementById('leadmagnet-styles')) {
      const style = document.createElement('style');
      style.id = 'leadmagnet-styles';
      style.textContent = `
        /* ── BADGES — 30-60-10 Color System ── */
        .leadmagnet-badge {
          position: absolute; top: 8px; right: 8px; z-index: 9999;
          padding: 4px 10px; border-radius: 20px;
          font-size: 11px; font-weight: 700;
          letter-spacing: 0.3px; pointer-events: none;
          font-family: -apple-system, sans-serif;
        }
        /* 🔴 HOT — score >= 60 — top 30% */
        .leadmagnet-badge-hot {
          background: #FEF2F2; color: #DC2626;
          border: 1.5px solid #FECACA;
        }
        /* 🟡 WARM — score 25-59 — middle 60% */
        .leadmagnet-badge-warm {
          background: #FFFBEB; color: #D97706;
          border: 1.5px solid #FDE68A;
        }
        /* 🔵 COOL — score < 25 — bottom 10% */
        .leadmagnet-badge-cool {
          background: #EFF6FF; color: #2563EB;
          border: 1.5px solid #BFDBFE;
        }
        /* ✅ CONTACTED */
        .leadmagnet-badge-clicked {
          background: #F0FDF4; color: #16A34A;
          border: 1.5px solid #BBF7D0;
        }
        .leadmagnet-badge-already-clicked {
          background: #F0FDF4; color: #16A34A;
          border: 1.5px solid #BBF7D0; opacity: 0.7;
        }
        /* ⛔ FILTERED */
        .leadmagnet-badge-filtered {
          background: #F9FAFB; color: #9CA3AF;
          border: 1.5px solid #E5E7EB;
        }
        /* ── COUNTDOWN OVERLAY ── */
        .leadmagnet-click-overlay {
          position: absolute; inset: 0; z-index: 9998;
          background: rgba(37,99,235,0.08);
          border: 2px solid #2563EB;
          border-radius: 8px;
          display: flex; align-items: center; justify-content: center;
        }
        .leadmagnet-countdown-box {
          background: white;
          border-radius: 12px;
          padding: 14px 20px;
          text-align: center;
          box-shadow: 0 4px 20px rgba(0,0,0,0.15);
          border: 1px solid #E2E8F0;
        }
        .leadmagnet-countdown-icon   { font-size: 24px; margin-bottom: 4px; }
        .leadmagnet-countdown-text   { font-size: 10px; color: #94A3B8; font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px; }
        .leadmagnet-countdown-number { font-size: 36px; font-weight: 800; color: #2563EB; line-height: 1.1; }
        /* ── STATUS BAR ── */
        #leadmagnet-status {
          position: fixed; bottom: 16px; right: 16px; z-index: 99999;
          background: white;
          border: 1.5px solid #E2E8F0;
          border-radius: 12px;
          padding: 10px 14px;
          box-shadow: 0 4px 20px rgba(0,0,0,0.12);
          cursor: pointer;
          min-width: 200px;
          font-family: -apple-system, sans-serif;
          transition: all 0.2s;
        }
        #leadmagnet-status:hover { box-shadow: 0 6px 24px rgba(0,0,0,0.18); }
        #leadmagnet-status.minimized { min-width: unset; padding: 8px 12px; }
        #leadmagnet-status.minimized .leadmagnet-status-text,
        #leadmagnet-status.minimized .leadmagnet-status-count { display: none; }
        .leadmagnet-status-content { display: flex; align-items: center; gap: 8px; }
        .leadmagnet-status-dot {
          width: 9px; height: 9px; border-radius: 50%;
          background: #CBD5E1; flex-shrink: 0;
        }
        .leadmagnet-status-dot.active {
          background: #16A34A;
          box-shadow: 0 0 0 3px #DCFCE7;
          animation: lo-pulse 2s infinite;
        }
        .leadmagnet-status-dot.offline { background: #EF4444; }
        @keyframes lo-pulse { 0%,100%{opacity:1} 50%{opacity:0.5} }
        .leadmagnet-status-text  { font-size: 12px; font-weight: 600; color: #1E293B; flex: 1; }
        .leadmagnet-status-count { font-size: 11px; color: #64748B; }
        .leadmagnet-status-backend { font-size: 13px; }
        /* ── NOTIFICATION ── */
        .leadmagnet-notification {
          position: fixed; top: 16px; right: 16px; z-index: 999999;
          padding: 10px 16px;
          border-radius: 10px;
          font-size: 13px;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 8px;
          box-shadow: 0 4px 16px rgba(0,0,0,0.15);
          font-family: -apple-system, sans-serif;
          animation: lo-slide-in 0.3s ease;
        }
        @keyframes lo-slide-in { from{transform:translateX(20px);opacity:0} to{transform:translateX(0);opacity:1} }
        .leadmagnet-notification.success { background: #F0FDF4; color: #16A34A; border: 1px solid #BBF7D0; }
        .leadmagnet-notification.error   { background: #FEF2F2; color: #DC2626; border: 1px solid #FECACA; }
        .leadmagnet-notification.info    { background: #EFF6FF; color: #2563EB; border: 1px solid #BFDBFE; }
      `;
      document.head.appendChild(style);
    }

    const existing = document.getElementById('leadmagnet-status');
    if (existing) existing.remove();

    const indicator = document.createElement('div');
    indicator.id = 'leadmagnet-status';
    indicator.innerHTML = `
      <div class="leadmagnet-status-content">
        <div class="leadmagnet-status-dot"></div>
        <span class="leadmagnet-status-text">Ready</span>
        <span class="leadmagnet-status-count">0 leads</span>
        <span class="leadmagnet-status-backend" title="Backend">🔴</span>
      </div>
    `;
    document.body.appendChild(indicator);
    indicator.addEventListener('click', () => indicator.classList.toggle('minimized'));
    updateStatusIndicator();
  }

  function updateStatusIndicator() {
    const dot = document.querySelector('.leadmagnet-status-dot');
    const text = document.querySelector('.leadmagnet-status-text');
    const count = document.querySelector('.leadmagnet-status-count');
    const backend = document.querySelector('.leadmagnet-status-backend');

    if (dot) {
      dot.className = 'leadmagnet-status-dot';
      if (state.isActive) dot.classList.add('active');
      if (!state.backendOnline) dot.classList.add('offline');
    }
    if (text) {
      if (!state.isActive) text.textContent = 'Paused';
      else if (state.phase === 'initial') text.textContent = 'Capturing all leads...';
      else if (state.phase === 'continuous') text.textContent = 'Watching for new leads';
      else text.textContent = 'Ready';
    }
    if (count) count.textContent = `${state.stats.total} leads | ${state.stats.clicked} clicked`;
    if (backend) backend.textContent = state.backendOnline ? '🟢' : '🔴';
  }

  // ==================== NOTIFICATIONS ====================

  function showNotification(message, type = 'info') {
    document.querySelectorAll('.leadmagnet-notification').forEach(n => n.remove());
    const notification = document.createElement('div');
    notification.className = `leadmagnet-notification ${type}`;
    notification.innerHTML = `
      <span>${type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️'}</span>
      <span>${message}</span>
      <span class="leadmagnet-notification-close" style="cursor:pointer;margin-left:8px;">×</span>
    `;
    document.body.appendChild(notification);
    notification.querySelector('.leadmagnet-notification-close').addEventListener('click', () => notification.remove());
    setTimeout(() => { if (notification.parentNode) notification.remove(); }, 4000);
  }

  // ==================== BOOT ====================

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
