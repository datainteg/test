/**
 * Lead Magnet — Extension Config (PRODUCTION)
 * @version 7.0.0
 */
const LM_CONFIG = {
  API_URL: 'http://localhost:3000',
  VERSION: '7.0.0'
};
