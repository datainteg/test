# 🧲 Lead Magnet v7.0.0
### datainteg.io · leadmagnet.mlaics.com

Full-stack IndiaMART Buy Leads auto-capture and CRM system.

---

## Project Structure

```
leadmagnet-v7/
├── backend/                  Node.js + Express + MongoDB API
│   ├── src/
│   │   ├── config/           DB, CORS, seed admin
│   │   ├── middleware/       JWT auth
│   │   ├── models/           Lead, Seller, User, Heartbeat
│   │   ├── routes/           auth, sellers, leads, stats, heartbeat
│   │   └── utils/            helpers (CSV, regex)
│   ├── .env.local            LOCAL dev environment vars
│   ├── .env.example          PROD template — copy to .env
│   └── server.js
├── frontend/                 React + TypeScript + Tailwind (Vite)
│   └── src/
│       ├── screens/          6 pages
│       ├── components/       layout, ui
│       ├── context/          Auth, Seller
│       └── services/api.ts   all API calls
├── extension/                Chrome Extension (IndiaMART)
│   ├── config.js             PROD API URL
│   ├── config.local.js       LOCAL API URL
│   ├── content.js            main capture + autoclick logic
│   └── manifest.json
├── nginx/
│   ├── nginx.http-only.conf  Step 1 of deploy (before SSL)
│   ├── nginx.ssl.conf        Step 2 of deploy (after SSL)
│   └── nginx.conf            auto-replaced by deploy.sh
├── Dockerfile                PRODUCTION multi-stage build
├── Dockerfile.dev            LOCAL dev with nodemon
├── docker-compose.yml        PRODUCTION stack
├── docker-compose.local.yml  LOCAL stack (backend + mongo only)
└── deploy.sh                 One-command production deploy
```

---

## ─── LOCAL DEVELOPMENT ───────────────────────────────────────

### Prerequisites
- Docker Desktop installed and running
- Node.js 18+ installed (for frontend only)

---

### Step 1 — Start backend + MongoDB

```bash
cd leadmagnet-v7
docker compose -f docker-compose.local.yml up -d
```

This starts:
- MongoDB on `localhost:27017`
- Node.js backend on `leadmagnet.mlaics.com`
- Admin auto-created: `admin@test.com` / `admin123`

Check it's running:
```bash
curl http://leadmagnet.mlaics.com/api/health
```

View logs:
```bash
docker compose -f docker-compose.local.yml logs -f backend
```

---

### Step 2 — Start frontend (Vite dev server)

```bash
cd frontend
npm install
npm run dev
```

Open: **http://localhost:5173**

Login: `admin@test.com` / `admin123`

> Vite proxies all `/api/*` requests to `leadmagnet.mlaics.com` automatically.
> No CORS issues, no env changes needed.

---

### Step 3 — Load extension locally

1. Open Chrome → `chrome://extensions/`
2. Enable **Developer mode** (top right)
3. Click **Load unpacked** → select the `extension/` folder
4. The extension loads with `config.local.js` (points to `leadmagnet.mlaics.com`)

> **Switching between local and prod extension config:**
> - Local: rename `config.local.js` → `config.js`
> - Prod: restore original `config.js` (`leadmagnet.mlaics.com`)

---

### Step 4 — Stop local stack

```bash
docker compose -f docker-compose.local.yml down
```

---

### Local credentials summary

| Thing | Value |
|-------|-------|
| Dashboard URL | http://localhost:5173 |
| API URL | http://leadmagnet.mlaics.com |
| Admin email | admin@test.com |
| Admin password | admin123 |
| MongoDB | localhost:27017 |

---

## ─── PRODUCTION DEPLOY ───────────────────────────────────────

### Prerequisites on server
- Ubuntu 20.04+ VPS
- Docker + Docker Compose installed
- Domain `leadmagnet.mlaics.com` DNS A record pointing to your server IP
- Ports 80 and 443 open in firewall

---

### Step 1 — Upload code to server

```bash
# On your local machine
scp -r leadmagnet-v7/ user@YOUR_SERVER_IP:/opt/leadmagnet
```

Or via git:
```bash
git clone your-repo /opt/leadmagnet
```

---

### Step 2 — Create production .env

```bash
cd /opt/leadmagnet
cp backend/.env.example backend/.env
nano backend/.env
```

Fill in these values:

```env
MONGO_URI=mongodb://mongo:27017/leadmagnet
PORT=3000
NODE_ENV=production
API_DOMAIN=leadmagnet.mlaics.com

# Generate with: openssl rand -hex 64
JWT_SECRET=PASTE_YOUR_64_CHAR_RANDOM_STRING_HERE

JWT_EXPIRES_IN=30d

ADMIN_EMAIL=admin@mlaics.com
ADMIN_PASSWORD=YourStrongPassword123!
ADMIN_NAME=Admin

ALLOWED_ORIGINS=https://leadmagnet.mlaics.com
```

Generate JWT secret:
```bash
openssl rand -hex 64
```

---

### Step 3 — Run deploy script

```bash
bash deploy.sh
```

This does everything automatically:
1. Builds Docker images
2. Starts HTTP-only stack
3. Gets SSL cert from Let's Encrypt
4. Switches nginx to HTTPS
5. Runs health check

---

### Step 4 — Verify

```bash
curl https://leadmagnet.mlaics.com/api/health
```

Open: **https://leadmagnet.mlaics.com**

Login with your `ADMIN_EMAIL` / `ADMIN_PASSWORD` from `.env`

---

### Step 5 — Load extension with prod URL

The `extension/config.js` already points to `https://leadmagnet.mlaics.com`

Pack the extension for Chrome Web Store or load unpacked in Chrome.

---

### Production credentials summary

| Thing | Value |
|-------|-------|
| Dashboard URL | https://leadmagnet.mlaics.com |
| API URL | https://leadmagnet.mlaics.com/api |
| Admin email | admin@mlaics.com (from .env) |
| Admin password | from .env |

---

## ─── USEFUL COMMANDS ─────────────────────────────────────────

### Local
```bash
# Start
docker compose -f docker-compose.local.yml up -d

# Stop
docker compose -f docker-compose.local.yml down

# Logs
docker compose -f docker-compose.local.yml logs -f backend

# Restart backend only
docker compose -f docker-compose.local.yml restart backend

# Reset local DB (wipe all data)
docker compose -f docker-compose.local.yml down -v
```

### Production
```bash
# View logs
docker compose logs -f backend

# Restart backend
docker compose restart backend

# Pull latest + redeploy
git pull
docker compose build --no-cache
docker compose up -d

# Stop everything
docker compose down

# Check SSL cert expiry
docker compose run --rm certbot certificates
```

---

## ─── ENVIRONMENT FILES EXPLAINED ────────────────────────────

| File | Used for | Committed to git? |
|------|----------|-------------------|
| `backend/.env.local` | Local dev | ✅ Yes (safe, test values) |
| `backend/.env.example` | Prod template | ✅ Yes (no secrets) |
| `backend/.env` | Production | ❌ NO — add to .gitignore |

---

## ─── KEYWORD SCORING EXPLAINED ──────────────────────────────

| Bucket | Purpose | Example |
|--------|---------|---------|
| `category` | Match IndiaMART category field | `swings`, `indoor playground` |
| `city` | Match buyer location | `mumbai`, `pune` |
| `value` | Match order value keywords | `bulk`, `wholesale` |

Score thresholds: 🔥 Hot ≥ 60 · ⭐ Warm ≥ 25 · 💧 Cool < 25

