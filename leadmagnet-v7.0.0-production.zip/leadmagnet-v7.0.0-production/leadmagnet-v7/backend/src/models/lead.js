const mongoose = require('mongoose');

const leadSchema = new mongoose.Schema({
  leadId:   { type: String, required: true, index: true },
  sellerId: { type: String, required: true, index: true },

  // ── Core Info ──
  title:     { type: String, default: '' },
  timestamp: { type: String, default: '' },

  // ── Location ──
  location: {
    city:  { type: String, default: '' },
    state: { type: String, default: '' },
    full:  { type: String, default: '' }
  },

  // ── IndiaMART Category > Product ──
  category:         { type: String, default: '' },   // e.g. "Artificial Grass"
  productName:      { type: String, default: '' },   // e.g. "Artificial Turf"
  detectedCategory: { type: String, default: 'General' },

  // ── Order & Quantity ──
  orderValue: {
    min:     { type: Number, default: 0 },
    max:     { type: Number, default: 0 },
    display: { type: String, default: '' }
  },
  quantity:        { type: String, default: '' },
  material:        { type: String, default: '' },
  requirementType: { type: String, default: '' },

  // ── Structured Specifications ──
  // Stored as array of {key, value} objects (consistent with extension payload)
  specifications: { type: mongoose.Schema.Types.Mixed, default: [] },

  // ── Buyer Info ──
  buyer: {
    memberSince:  { type: String, default: '' },
    businessType: { type: String, default: '' },
    buys:         { type: String, default: '' },
    engagement: {
      requirements: { type: Number, default: 0 },
      calls:        { type: Number, default: 0 },
      replies:      { type: Number, default: 0 }
    }
  },

  // ── Score & Status ──
  score: { type: Number, default: 0 },
  status: {
    clicked:          { type: Boolean, default: false },
    clickedAt:        { type: String,  default: null },
    keywordMatched:   { type: String,  default: '' },
    // Y = click was attempted (button found + clicked)
    // N = keyword matched but click was NOT attempted (button not found / error)
    // ''= keyword never matched (lead not targeted)
    clickAttempted:   { type: String,  default: '', enum: ['Y', 'N', ''] }
  },

  capturedAt:   { type: Date, default: Date.now },
  capturePhase: { type: String, default: 'unknown' },
  lastSeenAt:   { type: Date, default: Date.now }
});

leadSchema.index({ leadId: 1, sellerId: 1 }, { unique: true });
leadSchema.index({ sellerId: 1, 'status.clicked': 1 });
leadSchema.index({ sellerId: 1, capturedAt: -1 });
leadSchema.index({ sellerId: 1, score: -1 });
leadSchema.index({ sellerId: 1, 'orderValue.max': -1 });
leadSchema.index({ sellerId: 1, category: 1 });

module.exports = mongoose.model('Lead', leadSchema);
