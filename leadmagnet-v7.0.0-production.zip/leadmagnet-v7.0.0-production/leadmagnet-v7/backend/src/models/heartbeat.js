const mongoose = require('mongoose');

const heartbeatSchema = new mongoose.Schema({
  sellerId:    { type: String, required: true, unique: true, index: true },
  extensionId: { type: String, default: '' },
  phase:       { type: String, default: 'unknown' },   // idle | initial | continuous
  stats:       { type: mongoose.Schema.Types.Mixed, default: {} },
  tabUrl:      { type: String, default: '' },
  chromeFlags: { type: String, default: '' },
  lastPing:    { type: Date, default: Date.now, index: true },
  isAlive:     { type: Boolean, default: true },
  pingCount:   { type: Number, default: 0 },
  createdAt:   { type: Date, default: Date.now }
});

module.exports = mongoose.model('Heartbeat', heartbeatSchema);
