const mongoose = require('mongoose');

const sellerSchema = new mongoose.Schema({
  sellerId:    { type: String, required: true, unique: true, index: true },
  userId:      { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },  // link to User
  extensionId: { type: String, default: '' },
  name:        { type: String, default: '' },
  active:      { type: Boolean, default: true },

  // Flat keyword list (used by extension for matching)
  keywords: { type: [String], default: [] },

  // Categorised keywords for dashboard display + extension matching
  keywordCategories: {
    category: { type: [String], default: [] }, // renamed from 'product' → matches IndiaMART category field
    city:     { type: [String], default: [] },
    value:    { type: [String], default: [] }
  },

  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

sellerSchema.pre('save', function(next) { this.updatedAt = new Date(); next(); });

module.exports = mongoose.model('Seller', sellerSchema);
