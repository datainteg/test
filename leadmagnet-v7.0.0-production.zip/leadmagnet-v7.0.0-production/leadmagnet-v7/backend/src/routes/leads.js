/**
 * Leads routes
 * /api/leads/*
 * BUG FIX #1:  /stats/:sellerId now uses requireOwnerOrAdmin
 * BUG FIX #14: CSV export includes UTF-8 BOM for Excel
 * BUG FIX #2:  Export no longer uses query-param token
 */
const express = require('express');
const router = express.Router();
const Lead = require('../models/lead');
const ActionLog = require('../models/actionLog');
const { requireAuth, requireOwnerOrAdmin } = require('../middleware/auth');
const { escapeRegex, csvEscape, CSV_BOM } = require('../utils/helpers');

// Save batch of leads (with duplicate prevention per seller)
router.post('/batch', requireAuth, async (req, res) => {
  try {
    const { leads } = req.body;
    if (!leads || !Array.isArray(leads)) return res.status(400).json({ error: 'leads array required' });

    let sellerId = req.body.sellerId;
    if (req.user.role !== 'admin') sellerId = req.user.sellerId;
    if (!sellerId) return res.status(400).json({ error: 'sellerId required' });

    let inserted = 0, skipped = 0, errors = 0;

    for (const lead of leads) {
      const leadId = lead.leadId;
      if (!leadId) { errors++; continue; }

      try {
        const result = await Lead.updateOne(
          { leadId, sellerId },
          {
            $setOnInsert: {
              leadId, sellerId,
              title: lead.title || '',
              timestamp: lead.timestamp || '',
              location: lead.location || {},
              category: lead.category || '',
              detectedCategory: lead.detectedCategory || 'General',
              quantity: lead.quantity || '',
              orderValue: lead.orderValue || null,
              requirementType: lead.requirementType || '',
              buyer: lead.buyer || {},
              specifications: lead.specifications || [],
              score: lead.score || 0,
              status: { clicked: false, clickedAt: null },
              capturedAt: lead.capturedAt ? new Date(lead.capturedAt) : new Date(),
              capturePhase: lead.capturePhase || 'unknown'
            },
            $set: { lastSeenAt: new Date() }
          },
          { upsert: true }
        );

        if (result.upsertedCount > 0) {
          inserted++;
          await ActionLog.create({ sellerId, leadId, action: 'captured', title: lead.title || '' });
        } else {
          skipped++;
        }
      } catch (err) {
        if (err.code === 11000) skipped++;
        else { console.error('Lead save error:', err.message); errors++; }
      }
    }

    const total = await Lead.countDocuments({ sellerId });
    console.log(`[Leads] Seller ${sellerId}: +${inserted} new | ${skipped} existing | ${errors} errors`);
    res.json({ success: true, inserted, skipped, errors, total });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Check if lead exists for seller
router.get('/check/:leadId', requireAuth, async (req, res) => {
  try {
    const { leadId } = req.params;
    let sellerId = req.query.sellerId;
    if (req.user.role !== 'admin') sellerId = req.user.sellerId;
    if (!sellerId) return res.status(400).json({ error: 'sellerId required' });

    const lead = await Lead.findOne({ leadId, sellerId }, { status: 1 });
    if (lead) {
      res.json({ success: true, exists: true, clicked: lead.status?.clicked || false, clickedAt: lead.status?.clickedAt });
    } else {
      res.json({ success: true, exists: false, clicked: false });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all clicked lead IDs for a seller
router.get('/clicked-ids', requireAuth, async (req, res) => {
  try {
    let sellerId = req.query.sellerId;
    if (req.user.role !== 'admin') sellerId = req.user.sellerId;
    if (!sellerId) return res.status(400).json({ error: 'sellerId required' });

    const leads = await Lead.find({ sellerId, 'status.clicked': true }, { leadId: 1 });
    const clickedIds = leads.map(l => l.leadId);
    res.json({ success: true, clickedIds, count: clickedIds.length });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Mark lead as clicked
router.post('/mark-clicked', requireAuth, async (req, res) => {
  try {
    const { leadId, clickedAt, title, location, keywordMatched } = req.body;
    let sellerId = req.body.sellerId;
    if (req.user.role !== 'admin') sellerId = req.user.sellerId;
    if (!leadId || !sellerId) return res.status(400).json({ error: 'leadId and sellerId required' });

    await Lead.updateOne(
      { leadId, sellerId },
      {
        $set: {
          'status.clicked': true,
          'status.clickedAt': clickedAt || new Date().toISOString(),
          'status.keywordMatched': keywordMatched || ''
        },
        $setOnInsert: {
          leadId, sellerId,
          title: title || '',
          location: location || {},
          capturedAt: new Date()
        }
      },
      { upsert: true }
    );

    await ActionLog.create({
      sellerId, leadId,
      action: 'contacted',
      title: title || '',
      keywordMatched: keywordMatched || ''
    });

    console.log(`[Leads] Contacted: ${leadId} (seller: ${sellerId})`);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Set clickAttempted flag
router.post('/click-attempted', requireAuth, async (req, res) => {
  try {
    const { leadId, clickAttempted } = req.body;
    let sellerId = req.body.sellerId;
    if (req.user.role !== 'admin') sellerId = req.user.sellerId;
    if (!leadId || !sellerId) return res.status(400).json({ error: 'leadId and sellerId required' });
    if (!['Y', 'N'].includes(clickAttempted)) return res.status(400).json({ error: 'clickAttempted must be Y or N' });

    await Lead.updateOne(
      { leadId, sellerId },
      { $set: { 'status.clickAttempted': clickAttempted } }
    );

    console.log(`[Leads] clickAttempted=${clickAttempted} for ${leadId} (seller: ${sellerId})`);
    res.json({ success: true, clickAttempted });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get distinct categories
router.get('/categories', requireAuth, async (req, res) => {
  try {
    let sellerId = req.query.sellerId;
    if (req.user.role !== 'admin') sellerId = req.user.sellerId;
    const query = sellerId ? { sellerId } : {};
    const cats = await Lead.distinct('category', { ...query, category: { $ne: '' } });
    const detCats = await Lead.distinct('detectedCategory', { ...query, detectedCategory: { $ne: '' } });
    const all = [...new Set([...cats, ...detCats])].filter(Boolean).sort();
    res.json({ success: true, categories: all });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all leads for a seller (with filters)
router.get('/', requireAuth, async (req, res) => {
  try {
    const {
      page = 1, limit = 25,
      sort = 'capturedAt', order = 'desc',
      clicked, city, minScore, maxScore, minOrderValue, category
    } = req.query;

    let sellerId = req.query.sellerId;
    const query = {};
    if (req.user.role !== 'admin') {
      if (sellerId) {
        query.sellerId = sellerId;
      } else {
        const Seller = require('../models/seller');
        const ownSellers = await Seller.find({ userId: req.user._id }, { sellerId: 1 }).lean();
        const ownIds = ownSellers.map(s => s.sellerId);
        if (req.user.sellerId && !ownIds.includes(req.user.sellerId)) ownIds.push(req.user.sellerId);
        query.sellerId = { $in: ownIds };
      }
    } else if (sellerId) {
      query.sellerId = sellerId;
    }

    if (clicked === 'true') query['status.clicked'] = true;
    else if (clicked === 'false') query['status.clicked'] = { $ne: true };
    if (city) query['location.city'] = new RegExp(escapeRegex(city), 'i');
    if (minScore || maxScore) {
      query.score = {};
      if (minScore) query.score.$gte = parseInt(minScore);
      if (maxScore) query.score.$lte = parseInt(maxScore);
    }
    if (minOrderValue) query['orderValue.max'] = { $gte: parseInt(minOrderValue) };
    if (category) query.$or = [
      { category: new RegExp(escapeRegex(category), 'i') },
      { detectedCategory: new RegExp(escapeRegex(category), 'i') }
    ];

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const sortObj = { [sort]: order === 'desc' ? -1 : 1 };

    const [leads, total] = await Promise.all([
      Lead.find(query).sort(sortObj).skip(skip).limit(parseInt(limit)).lean(),
      Lead.countDocuments(query)
    ]);

    res.json({
      success: true, data: leads, total,
      page: parseInt(page), limit: parseInt(limit),
      pages: Math.ceil(total / parseInt(limit))
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// BUG FIX #2 & #14: Export leads as CSV with proper auth header (not query param) + UTF-8 BOM
router.get('/export', requireAuth, async (req, res) => {
  try {
    let sellerId = req.query.sellerId;
    if (req.user.role !== 'admin') sellerId = req.user.sellerId;
    const query = sellerId ? { sellerId } : {};
    const leads = await Lead.find(query).sort({ score: -1 }).lean();

    const headers = [
      'Lead ID', 'Seller ID', 'Title', 'City', 'State', 'Score', 'Timestamp', 'Category',
      'Quantity', 'Order Min', 'Order Max', 'Member Since', 'Business Type',
      'Clicked', 'Clicked At', 'Keyword Matched', 'Captured At'
    ];
    const rows = [headers.map(h => csvEscape(h)).join(',')];

    for (const lead of leads) {
      rows.push([
        csvEscape(lead.leadId),
        csvEscape(lead.sellerId),
        csvEscape(lead.title || ''),
        csvEscape(lead.location?.city || ''),
        csvEscape(lead.location?.state || ''),
        csvEscape(lead.score || 0),
        csvEscape(lead.timestamp || ''),
        csvEscape(lead.detectedCategory || lead.category || ''),
        csvEscape(lead.quantity || ''),
        csvEscape(lead.orderValue?.min || ''),
        csvEscape(lead.orderValue?.max || ''),
        csvEscape(lead.buyer?.memberSince || ''),
        csvEscape(lead.buyer?.businessType || ''),
        csvEscape(lead.status?.clicked ? 'Yes' : 'No'),
        csvEscape(lead.status?.clickedAt || ''),
        csvEscape(lead.status?.keywordMatched || ''),
        csvEscape(lead.capturedAt ? new Date(lead.capturedAt).toISOString() : '')
      ].join(','));
    }

    const filename = `leadmagnet_export_${Date.now()}.csv`;
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
    // BUG FIX #14: UTF-8 BOM so Excel renders ₹ and Hindi text correctly
    res.send(CSV_BOM + rows.join('\n'));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// BUG FIX #1: Stats for a seller — now requires ownership check
router.get('/stats/:sellerId', requireAuth, requireOwnerOrAdmin, async (req, res) => {
  try {
    const { sellerId } = req.params;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [total, clicked, todayCount, categories, cities] = await Promise.all([
      Lead.countDocuments({ sellerId }),
      Lead.countDocuments({ sellerId, 'status.clicked': true }),
      Lead.countDocuments({ sellerId, capturedAt: { $gte: today } }),
      Lead.aggregate([
        { $match: { sellerId } },
        { $group: { _id: '$detectedCategory', count: { $sum: 1 } } },
        { $sort: { count: -1 } }, { $limit: 10 }
      ]),
      Lead.aggregate([
        { $match: { sellerId } },
        { $group: { _id: '$location.city', count: { $sum: 1 } } },
        { $sort: { count: -1 } }, { $limit: 10 }
      ])
    ]);

    res.json({ success: true, stats: { total, clicked, today: todayCount, categories, topCities: cities } });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
