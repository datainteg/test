/**
 * Stats & Data routes
 * /api/stats, /api/data/*
 */
const express = require('express');
const router = express.Router();
const Lead = require('../models/lead');
const ActionLog = require('../models/actionLog');
const Seller = require('../models/seller');
const { requireAuth } = require('../middleware/auth');

// GET /api/stats
router.get('/stats', requireAuth, async (req, res) => {
  try {
    let q = {};
    if (req.user.role !== 'admin') {
      const sellerDocs = await Seller.find({ userId: req.user._id }, { sellerId: 1 }).lean();
      const ownIds = sellerDocs.map(s => s.sellerId);
      if (req.user.sellerId && !ownIds.includes(req.user.sellerId)) ownIds.push(req.user.sellerId);
      q.sellerId = req.query.sellerId && ownIds.includes(req.query.sellerId)
        ? req.query.sellerId
        : { $in: ownIds };
    } else if (req.query.sellerId) {
      q.sellerId = req.query.sellerId;
    }
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const [total, clicked, todayCount, hot, warm, cool] = await Promise.all([
      Lead.countDocuments(q),
      Lead.countDocuments({ ...q, 'status.clicked': true }),
      Lead.countDocuments({ ...q, capturedAt: { $gte: today } }),
      Lead.countDocuments({ ...q, score: { $gte: 60 } }),
      Lead.countDocuments({ ...q, score: { $gte: 25, $lt: 60 } }),
      Lead.countDocuments({ ...q, score: { $lt: 25 } }),
    ]);
    res.json({ success: true, stats: { total, clicked, today: todayCount, hot, warm, cool } });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/data/clear
router.post('/data/clear', requireAuth, async (req, res) => {
  try {
    let sellerId = req.body.sellerId;
    if (req.user.role !== 'admin') sellerId = req.user.sellerId;

    if (sellerId) {
      await Lead.deleteMany({ sellerId });
      await ActionLog.deleteMany({ sellerId });
    } else if (req.user.role === 'admin') {
      await Lead.deleteMany({});
      await ActionLog.deleteMany({});
    }
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
