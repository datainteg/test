/**
 * Express App — component-based route mounting
 * @version 7.0.0
 */
'use strict';

const express = require('express');
const path = require('path');
const cors = require('cors');
const mongoose = require('mongoose');

const { corsOptions, ALLOWED_ORIGINS } = require('./config/cors');

const app = express();

// ── CORS ──────────────────────────────────────────
app.use(cors(corsOptions));
app.options('*', cors(corsOptions));

// ── BODY PARSING ──────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ── ROUTES (component-based) ──────────────────────
app.use('/api/auth',      require('./routes/auth'));
app.use('/api/sellers',   require('./routes/sellers'));
app.use('/api/leads',     require('./routes/leads'));
app.use('/api/heartbeat', require('./routes/heartbeat'));
app.use('/api',           require('./routes/stats'));

// ── HEALTH (public — no auth) ─────────────────────
app.get('/api/health', async (req, res) => {
  const states = { 0: 'disconnected', 1: 'connected', 2: 'connecting', 3: 'disconnecting' };
  res.json({
    success: true,
    service: 'Lead Magnet API',
    domain: process.env.API_DOMAIN || 'localhost',
    mongodb: states[mongoose.connection.readyState] || 'unknown',
    version: '7.0.0',
    timestamp: new Date().toISOString()
  });
});

// ── STATIC + DASHBOARD ────────────────────────────
// Serves the React build output (frontend/dist → backend/public)
app.use(express.static(path.join(__dirname, '..', 'public')));

// ── 404 for unmatched API routes ──────────────────
app.all('/api/*', (req, res) => res.status(404).json({ error: 'API route not found' }));

// SPA fallback: any non-API route serves index.html for React client-side routing
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

module.exports = app;
