/**
 * Lead Magnet — Backend Server
 * @author datainteg.io
 * @version 7.0.0
 */
'use strict';
require('dotenv').config();

const app = require('./src/app');
const { connectDB } = require('./src/config/database');
const { seedAdmin } = require('./src/config/seed');

const PORT = process.env.PORT || 3000;
const ENV  = process.env.NODE_ENV || 'development';

(async () => {
  await connectDB();
  await seedAdmin();

  app.listen(PORT, () => {
    const proto  = ENV === 'production' ? 'https' : 'http';
    const domain = process.env.API_DOMAIN || `localhost:${PORT}`;
    console.log('');
    console.log(`🧲 Lead Magnet v7.0.0  [${ENV.toUpperCase()}]`);
    console.log(`   Dashboard : ${proto}://${domain}/`);
    console.log(`   Health    : ${proto}://${domain}/api/health`);
    console.log(`   Port      : ${PORT}`);
    console.log('');
  });
})();
