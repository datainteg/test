#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# Lead Magnet v6.0 — Local Test
# Run: chmod +x test-local.sh && ./test-local.sh
# ═══════════════════════════════════════════════════════════════

set -e

echo ""
echo "🧲 Lead Magnet v6.0 — Local Dev Setup"
echo "═══════════════════════════════════════"
echo ""

# Step 1: Switch extension config to localhost
echo "▶ Step 1: Setting extension config to localhost..."
cp extension/config.local.js extension/config.js
echo "   ✅ config.js → http://leadmagnet.mlaics.com"

# Step 2: Start Docker
echo ""
echo "▶ Step 2: Starting Docker containers..."
docker compose -f docker-compose.local.yml down 2>/dev/null || true
docker compose -f docker-compose.local.yml up -d --build
echo "   ✅ MongoDB + Backend running"

# Step 3: Wait for backend
echo ""
echo "▶ Step 3: Waiting for backend..."
for i in $(seq 1 15); do
  if curl -s http://leadmagnet.mlaics.com/api/health | grep -q "success"; then
    echo "   ✅ Backend is UP"
    break
  fi
  if [ $i -eq 15 ]; then
    echo "   ❌ Backend failed to start. Check: docker compose -f docker-compose.local.yml logs backend"
    exit 1
  fi
  sleep 2
done

# Step 4: Show info
echo ""
echo "═══════════════════════════════════════════════════════"
echo ""
echo "  🎉 LOCAL DEV READY!"
echo ""
echo "  Dashboard:  http://leadmagnet.mlaics.com/dashboard"
echo "  Health:     http://leadmagnet.mlaics.com/api/health"
echo "  MongoDB:    mongodb://localhost:27017/leadmagnet"
echo ""
echo "  Admin Login:"
echo "    Email:    admin@test.com"
echo "    Password: admin123"
echo ""
echo "  Extension Setup:"
echo "    1. Open chrome://extensions"
echo "    2. Enable Developer Mode"
echo "    3. Load unpacked → select 'extension/' folder"
echo "    4. Click extension icon → login with admin creds"
echo "       OR create a seller user in dashboard first"
echo ""
echo "  Test Flow:"
echo "    1. Login to dashboard → create seller user"
echo "    2. Login to extension with seller creds"
echo "    3. Open seller.indiamart.com → Start scraping"
echo "    4. Check dashboard → leads + heartbeat"
echo ""
echo "  Stop:  docker compose -f docker-compose.local.yml down"
echo "  Logs:  docker compose -f docker-compose.local.yml logs -f backend"
echo ""
echo "═══════════════════════════════════════════════════════"
echo ""

# Quick API test
echo "▶ Quick API test..."
echo ""

# Login as admin
TOKEN=$(curl -s -X POST http://leadmagnet.mlaics.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@test.com","password":"admin123"}' | grep -o '"token":"[^"]*"' | cut -d'"' -f4)

if [ -n "$TOKEN" ]; then
  echo "  ✅ Admin login: SUCCESS"
  echo "  Token: ${TOKEN:0:20}..."

  # Create a test seller
  RESULT=$(curl -s -X POST http://leadmagnet.mlaics.com/api/auth/users \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer $TOKEN" \
    -d '{"email":"seller1@test.com","password":"seller123","name":"Test Seller","role":"seller"}')
  
  if echo "$RESULT" | grep -q "success"; then
    echo "  ✅ Test seller created: seller1@test.com / seller123"
  else
    echo "  ℹ️  Seller may already exist (ok for re-runs)"
  fi

  # Test seller login
  STOKEN=$(curl -s -X POST http://leadmagnet.mlaics.com/api/auth/login \
    -H "Content-Type: application/json" \
    -d '{"email":"seller1@test.com","password":"seller123"}' | grep -o '"token":"[^"]*"' | cut -d'"' -f4)
  
  if [ -n "$STOKEN" ]; then
    echo "  ✅ Seller login: SUCCESS"
  fi

  echo ""
  echo "  Ready to test! Open http://leadmagnet.mlaics.com/dashboard"
else
  echo "  ❌ Admin login failed — check logs"
fi

echo ""
