@echo off
REM ═══════════════════════════════════════════════════════════════════
REM  Lead Magnet — RDP Setup for AWS EC2 Windows
REM  Run this ONCE as Administrator to configure the machine
REM  @author datainteg.io
REM  @version 5.4.0
REM ═══════════════════════════════════════════════════════════════════

echo.
echo  ╔═══════════════════════════════════════════════════╗
echo  ║   Lead Magnet — EC2 RDP Setup                    ║
echo  ║   Prevents Chrome from freezing on disconnect    ║
echo  ╚═══════════════════════════════════════════════════╝
echo.

REM ── 1. Disable screen saver & lock screen ──────────────────────
echo [1/6] Disabling screen saver and lock screen...
reg add "HKCU\Control Panel\Desktop" /v ScreenSaveActive /t REG_SZ /d 0 /f >nul 2>&1
reg add "HKCU\Control Panel\Desktop" /v ScreenSaverIsSecure /t REG_SZ /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Personalization" /v NoLockScreen /t REG_DWORD /d 1 /f >nul 2>&1
echo    Done.

REM ── 2. Keep RDP session alive on disconnect ────────────────────
echo [2/6] Configuring RDP to keep session alive...
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v fDisableAutoReconnect /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v MaxIdleTime /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v MaxDisconnectionTime /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v RemoteAppLogoffTimeLimit /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v MaxIdleTime /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v MaxDisconnectionTime /t REG_DWORD /d 0 /f >nul 2>&1
echo    Done.

REM ── 3. Disable power management / sleep ────────────────────────
echo [3/6] Disabling sleep and power saving...
powercfg /change monitor-timeout-ac 0
powercfg /change monitor-timeout-dc 0
powercfg /change standby-timeout-ac 0
powercfg /change standby-timeout-dc 0
powercfg /change hibernate-timeout-ac 0
powercfg /change hibernate-timeout-dc 0
powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c >nul 2>&1
echo    Done.

REM ── 4. Create Chrome launcher with anti-throttle flags ─────────
echo [4/6] Creating Chrome launcher...
(
echo @echo off
echo REM Lead Magnet — Chrome Launcher with Anti-Throttle
echo REM Start Chrome with flags that prevent tab freezing on RDP
echo.
echo taskkill /f /im chrome.exe >nul 2^>^&1
echo timeout /t 2 /nobreak >nul
echo.
echo start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" ^
echo   --disable-background-timer-throttling ^
echo   --disable-backgrounding-occluded-windows ^
echo   --disable-renderer-backgrounding ^
echo   --disable-hang-monitor ^
echo   --disable-ipc-flooding-protection ^
echo   --disable-component-update ^
echo   --no-first-run ^
echo   --disable-features=TabFreezing,IntensiveWakeUpThrottling ^
echo   --enable-features=WebRTC-H264WithOpenH264FFmpeg ^
echo   https://seller.indiamart.com/buyercentral/
echo.
echo echo Chrome started with anti-throttle flags!
) > "%USERPROFILE%\Desktop\Start-Chrome-LeadMagnet.bat"
echo    Created: %USERPROFILE%\Desktop\Start-Chrome-LeadMagnet.bat

REM ── 5. Create keepalive VBS script ─────────────────────────────
echo [5/6] Creating session keepalive script...
(
echo ' Lead Magnet — Session KeepAlive
echo ' Prevents Windows from marking RDP session as idle
echo ' Runs in background, press Ctrl+C to stop
echo Set WshShell = CreateObject^("WScript.Shell"^)
echo Do
echo   WshShell.SendKeys "{SCROLLLOCK}"
echo   WScript.Sleep 30000
echo   WshShell.SendKeys "{SCROLLLOCK}"
echo   WScript.Sleep 30000
echo Loop
) > "%USERPROFILE%\Desktop\KeepAlive.vbs"
echo    Created: %USERPROFILE%\Desktop\KeepAlive.vbs

REM ── 6. Create auto-start task scheduler entry ──────────────────
echo [6/6] Creating auto-start scheduled task...
schtasks /create /tn "LeadMagnet-KeepAlive" /tr "wscript.exe \"%USERPROFILE%\Desktop\KeepAlive.vbs\"" /sc onlogon /rl highest /f >nul 2>&1
echo    Done.

echo.
echo  ╔═══════════════════════════════════════════════════╗
echo  ║   SETUP COMPLETE!                                ║
echo  ╠═══════════════════════════════════════════════════╣
echo  ║                                                   ║
echo  ║   Next steps:                                     ║
echo  ║   1. Restart the EC2 instance (or reboot)         ║
echo  ║   2. RDP back in                                  ║
echo  ║   3. Double-click "Start-Chrome-LeadMagnet.bat"   ║
echo  ║      on Desktop to launch Chrome                  ║
echo  ║   4. Double-click "KeepAlive.vbs" on Desktop      ║
echo  ║      (runs automatically next login)              ║
echo  ║   5. Install/update Lead Magnet extension         ║
echo  ║   6. Start scraping — it won't freeze anymore!    ║
echo  ║                                                   ║
echo  ║   Chrome flags applied:                           ║
echo  ║   --disable-background-timer-throttling            ║
echo  ║   --disable-backgrounding-occluded-windows         ║
echo  ║   --disable-renderer-backgrounding                 ║
echo  ║   --disable-hang-monitor                           ║
echo  ║   --disable-features=TabFreezing                   ║
echo  ║                                                   ║
echo  ╚═══════════════════════════════════════════════════╝
echo.
pause
